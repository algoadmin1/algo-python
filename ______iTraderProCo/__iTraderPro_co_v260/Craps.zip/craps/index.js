// index.js
 

// var c 			 = document.getElementById("myCanvas");
const canvas 	 = document.querySelector("canvas");
const c 		 = canvas.getContext("2d");

canvas.width        = innerWidth
canvas.height       = innerHeight


var gDebugMode=0;

var gTimerBarMultiplierStart = 0.080; // .25
var gTimerBarMultiplier = gTimerBarMultiplierStart; //0.125; // .25


var gButtonNumClicked=-1;
var gRound= 14;
var n; //event listener # times
var gPlayerUserIDstr="jb";
var gPlayerUserIDNumstr="13";

// pixel offset across to the right, down from 0,0 upper left Canvas
var gGameLogStr="";
var gLastEvent="0[Init],"
var gCrapsTableX = 0;					//  x,y  off for table pos
var gCrapsTableY = 100;

var gCrapsButtonX =70;
var gCrapsButtonY =150; 
var gCrapsButtonRad =29 ; //40; 

var gFirstTime=0;
var gPlayerChips =1500; //000;
var gHouseChips =0; //000;

var gButColOff= "#6933cc";//"#33ff8a"; //"#d4f5f5"; //"#aa3322";
var gButColOn = "#22aa33";

var bOff = 4;
var bOffStr="";//"[Off]";
var gTableXOff = 890;

// INIT'd VARs
var thepointIs="OFF";
var longestStreak=0;
var longestTo7Streak=0;
var thisStreak=0;
var to7Streak=0;
var gPointsMade=0;
var gSevenOuts=0;
var gDiceThrown=0;
var gSecondsElapsed=0;

var dice1X = 680;
var dice1Y = 104;
var dice2X = 798;
var dice2Y = dice1Y;
var dicescale = 0.385;              //  SCALE

//
//

var ThePointLocationXAdder=450;
var ThePointLocations = [
                      0,0, 
                      0,0, 
                      0,0, 
                      0,0, 

                      177,122,   // 4
                      221,122, 
                      266,122,   // 6

                       0,0,    // 7

                      312,122,   // 8
                      358,122, 
                      402,122,    // 10

                       0,0,     //  11  & 12
                       0,0

            ];

// BUG HERE
var gPointPcts = [
//                 ie  5.5%(2)
                      0.00, 0.00,  
                      0.0277, 0.0555, 0.08333,0.1111,
                      0.1388, 
                      0.1666,   // 7 %
                      0.1388,
                      0.1111, 0.08333,0.0555,0.0277


                ];

// buttons on top
var bRects = [
                      10,10, 190,60,
                     220,10, 190,60, 

                     420,10, 130,60,        //  denom button

                     640,10, 350,60,
                     // 760,10, 240,60,
                     150,120, 200,50,


                     556,10, 60,60,        //  speed up AUX button
                     //  780,12, 60,60,
                     // 850, 12, 60,60
                ];

var bClickStatus = [
                       0,0,0,0,0 ,0 //, 0,0
                ];

var gChipDenominations = [
                       1,5,10,25,100
                        ,500
                       //,1000,5000,10000,100000   
                ];
var gChipDenominationsColors = [
//                  white $1     red $5    orng$10   green$25  blk $100
                   //  "#efefef","#dc122a","#fc8519","#19fc41","#0f1210"
                     "#efefef","#dc122a","#1936fc","#22fe34","#0f1210"
//                  purple 500  violet 1k  blue 5k  pink 10k  aqua 100k 
                      , "#ce19fc"
                     //,"#590995","#1936fc","#d789d7","#f2fc3d"   //"#23ee93"
                ];

var gChipIndex =0;
var gChipIndexLen = gChipDenominations.length;


var bTexts= [
                    "SHAKE DICE",
                    "SHOOT DICE",
                     "       $",  //$ must be in this poisiotn [2] in 0... array
                    "6",
                    "6",

                    "Aux",
                    // "3"

                ];

var numButtons = bTexts.length;


// needs to be array
var    mySound;
var    mySound_chips1  ;
var    mySound_chips2 ;
var    mySound_chips3 ;

var    mySound_chips4 ;
var    mySound_chips5 ;

var    mySound_crowd ;
var    mySound_dice0 ;


var      sfx_2 ; // = new sound("mp3/sfx_2.mp3");
var      sfx_2a; // = new sound("mp3/sfx_2a.mp3");
var      sfx_3 ; // = new sound("mp3/sfx_3.mp3");
var      sfx_3a; // = new sound("mp3/sfx_3.mp3");
var      sfx_4;//   = new sound("mp3/numbers/sfx_4.mp3");
var     sfx_4a ;//  = new sound("mp3/numbers/sfx_4hard.mp3");

var     sfx_5 ; // = new sound("mp3/sfx_5.mp3");
var      sfx_5a; //= new sound("mp3/sfx_5a.mp3");

var      sfx_6 ; // = new sound("mp3/sfx_6.mp3");
var      sfx_6a; // = new sound("mp3/sfx_6a.mp3");

var      sfx_7 ; // = new sound("mp3/sfx_7.mp3");
var      sfx_7a; // = new sound("mp3/sfx_7a.mp3");
    
var      sfx_8  ; //= new sound("mp3/sfx_8.mp3");
var      sfx_8a ; //= new sound("mp3/sfx_8a.mp3");

var      sfx_9  ; //= new sound("mp3/sfx_9.mp3");
var      sfx_9a ; //= new sound("mp3/sfx_9.mp3");

var      sfx_10 ; //= new sound("mp3/sfx_10.mp3");
var      sfx_10a; //= new sound("mp3/sfx_10a.mp3");

var      sfx_11 ; //= new sound("mp3/sfx_11.mp3");
var      sfx_11a; //= new sound("mp3/sfx_11a.mp3");
var      sfx_12 ; //= new sound("mp3/sfx_12.mp3");
var      sfx_12a; //= new sound("mp3/sfx_12a.mp3");
var      sfx_13;
var      sfx_13a;
var      sfx_14;
var      sfx_14a;
var     sfx_15;
var     sfx_15a;

const imgdice1 = new Image();
imgdice1.src = "imgcraps/dice1.png";

const imgdice2 = new Image();
imgdice2.src = "imgcraps/dice2.png";

const imgdice3 = new Image();
imgdice3.src = "imgcraps/dice3.png";

const imgdice4 = new Image();
imgdice4.src = "imgcraps/dice4.png";

const imgdice5 = new Image();
imgdice5.src = "imgcraps/dice5.png";

const imgdice6 = new Image();
imgdice6.src = "imgcraps/dice6.png";

// 180x144 patch.jpg

const imgpatch = new Image();
imgpatch.src = "imgcraps/patch.jpg";


const imgcleanpoints = new Image();
imgcleanpoints.src = "imgcraps/cleanpoints.jpg";



 var countdownStart=1000;
 var countdown =1000;
 var countdownH=400;

 
var countDownDate = new Date("Oct 23, 2020 01:00:00").getTime();



const img = new Image()
img.src = "crapstable.jpg"
// img.src = "crapstable2.jpg"

img.onload = () => {
//  (image, sx, sy, sWidth, sHeight,  dx, dy, dWidth, dHeight, )
    ;// c.draw Image(img, 0, 0, 2044,941,   100,100, 1022,470)

     // c.drawImage(img, 0, 0,  2044,941,  gCrapsTableX, gCrapsTableY, 1024,512)
     c.drawImage(img, 0, 0,  2044,941,  gCrapsTableX,gCrapsTableY, 1024,512)

     var crapsbutton1 = new CrapsButton( gCrapsTableX+ 20 + 50, gCrapsTableY + 50,gCrapsButtonRad,'black',1 );
     crapsbutton1.draw();
     var crapsbutton1a = new CrapsButton( gCrapsTableX+20 + 50+gTableXOff, gCrapsTableY  + 50,gCrapsButtonRad,'black',1 );
     crapsbutton1a.draw();

     initTableBets(0);
     DrawDenomButton();
}
 

class CrapsButton{
    constructor(x,y, radius, color, velocity){
        this.x =x
        this.y =y
        this.radius=radius
        this.color= color 
        this.velocity=velocity 
     }
    draw(){


        c.beginPath()
        c.arc(this.x, this.y, this.radius+3, 0, Math.PI*2, false) 
        c.fillStyle='black';
        c.fill()

        c.beginPath()
        c.arc(this.x, this.y, this.radius, 0, Math.PI*2, false) 
        c.fillStyle='white';//RandomColor(); //this.color
        c.fill()

        c.beginPath()
        c.arc(this.x, this.y, this.radius*0.90, 
            0, Math.PI*2, false) 
        c.fillStyle=this.color
        c.fill()


        if(this.color=='white'){
             c.font = "28px Arial";
             c.fillStyle='black';

             c.fillText( "ON", this.x-(this.radius*0.720) , this.y+9  );

// dra in point smaller

             // c.font = "18px Arial";
             // c.fillStyle='blue';
             // if(thepointIs=="10")  c.fillText( thepointIs, this.x+(this.radius*0.200) , this.y+24);
             //    else   c.fillText( thepointIs, this.x+(this.radius*0.200) , this.y+24  );

          // c.fillText( thepointIs, this.x-(this.radius*0.330) , this.y+14  );

         }else{  //black
             c.font = "20px Arial";
             c.fillStyle='white';
             // if(thepointIs=="10")  c.fillText( thepointIs, this.x-(this.radius*0.70) , this.y+7  );
             //    else   c.fillText( thepointIs, this.x-(this.radius*0.60) , this.y+7  );
            c.fillText( thepointIs, this.x-(this.radius*0.660) , this.y+7  );


         }

        // c.fillText( thepointIs, this.x-(this.radius*0.50) , this.y+7  );
   

    }

}


//  move up top
//
var gTableBetNames = [
                          "DONT PASS",      // 0
                          "DONT COME",
                          "2 Snakeeyes",
                          "3 Craps",
                          "4 Placed",

                          "5 Placed",               // 5
                          "6 Placed",
                          "Come",
                          "8 Placed",
                          "Field",

                          "10 Placed",                 // 10
                          "11 Yo 11",
                          "12 Midnight",
                          "Pass Line",
                          "Behind Pass Line",

                          "SEVEN",               //15
                          "ANY CRAPS",
                          "E-C",
                          "ALL SMALL",
                          "NOTHING AT ALL",

                          "ALL TALL",                 //20
                          "HOP BET TOP",
                          "HOP BET BOTTOM",
                          "BIG 6-8",              // 23
                          "Hard 4",                 //24 ,26 28 30 == hardways


                          "na",             //25
                          "Hard 6",
                          "na",
                          "Hard 8",
                          "na",

                          "Hard 10",        // 30
                          "na",
                          "na",
                          "na",
                          "na",

];
 var gTableBetNamesLen = gTableBetNames.length;

var gTableBetXYWHoffset = 8;

var gTableBetXYWH = [
// come
                      104,206, 276,50,   50,  7, 1.0, 0.0 ,
// field
                      100,262, 280,50,   50,  9, 1.0, 0.0 ,
//dont pass
                      154,315, 226,30,   50,  0, 1.0, 0.0 ,

// leftllHOriz lower PASSLINE
                      80,350, 300,35,   50,  13, 1.0, 0.0 ,
// leftllHOriz lower BEHIND-PASSLINE
                      90,386, 290,70,   50,  14, 1.0, 0.0 ,

// LEFT BIG 6-8 
                      90,315, 50,30,   50,  23, 1.0, 0.0 ,


// leftlVertical PASSLINE
                       45,120, 34,260,   50,  13, 1.0, 0.0 ,
// leftlVertical BEHIND-PASSLINE
                       11,120, 34,260,   50,  14, 1.0, 0.0 ,

// leftlVertical  DONT PASS 
                       84,120, 18,130,   50,  0, 1.0, 0.0 ,


// LEFT DONT COME BAR                       
                      106,118, 40,84,   50,  1, 2.0, 0.0, 

// 4..10 points LEFT SIDE TABLE  est X pos, change...
                      149,118, 44,84,   50,   4, 2.0, 0.0 ,
                      194,118, 44,84,   50,   5, 1.5, 0.0 ,
                      244,118, 44,84,   50,   6, 1.2, 0.0 ,

                      290,118, 44,84,   50,   8, 1.2, 0.0 ,
                      334,118, 44,84,   50,   9, 1.5, 0.0 ,
                      380,118, 44,84,   50,  10, 2.0, 0.0 ,


// HOP BET TOP
                       430 ,118, 165,38,   50,  21, 31.0, 0.0, 

// HOP BET BOTTOM
                       430 ,118+38, 165,26,   50,  22, 16.0, 0.0, 

// ALL SMALL, 
                        376,20, 80,90,   50,  18, 35.0, 0.0, 
// NOTHING AT ALL
                    82+376,20, 110,90,   50,  19, 176.0, 0.0, 
// ALL TALL
                    194+ 376,20, 80,90,   50,  20, 35.0, 0.0, 


//  LEFT E-C                      
                      384,224, 44,170,   50,  17, 2.0, 0.0 ,
 

// SEVEN 5-1
                       430 ,190, 165,15,   50,  15, 5.0, 0.0, 

// hard 6,10,8,4
                      432,210, 80,40-4,   50,   26, 10.0, 1 ,
                      515,210, 80,40-4,   50,   30,  8.0, 1 ,
                      432,250, 80,40-4,   50,   28, 10.0, 1 ,
                      515,250, 80,40-4,   50,   24,  8.0, 1 ,


// HORN HI YO: CW ORDER:  3, 2, 12, 11, 11
					           432,290-2, 54,40-4,   50,   3, 16.0, 0.0 ,
			         	 	   488,290-2, 54,40-4,   50,   2, 31.0, 0.0 ,
             	       545,290-2, 54,40-4,   50,  12, 31.0, 0.0 ,

                   	  432,330-2, 80,40-4,   50,   11, 16.0, 0.0 ,
                      515,330-2, 80,40-4,   50,   11, 16.0, 0.0 ,

// ANY CRAP 8-1
                       430 ,370, 165,15,   50,  16, 8.0, 0.0, 



// + 450
// tablecoll
// 4..10 points right SIDE TABLE  est X pos, change...
                      460 +144,118, 44,84,   50,   4, 2.0, 0.0 ,
                      460 +189,118, 44,84,   50,   5, 1.5, 0.0 ,
                      460 +239,118, 44,84,   50,   6, 1.2, 0.0 ,

                       454+289,118, 44,84,   50,   8, 1.2, 0.0 ,
                       450+339,118, 40,84,   50,   9, 1.5, 0.0 ,
                       450+385,118, 40,84,   50,  10, 2.0, 0.0, 


// RIGHT DONT COME BAR                       
                     44+450+385,118, 40,84,   50,  1, 2.0, 0.0, 

// RIGHT E-C
                       450+150,224, 44,170,      50,  17, 2.0, 0.0 ,

/// RIGHT SIDE
// come
                    92+460+100,204, 270,56,   50,  7, 1.0, 0.0 ,
// field
                    92+460+100,262, 270,50,   50,  9, 1.0, 0.0 ,
//dont pass
                     460+192 ,315, 230,30,   50,  0, 1.0, 0.0 ,

// RIGHTlOWERHOriz lower PASSLINE
                    100+  450+100,350, 300,35,   50,  13, 1.0, 0.0 ,
// RIGHTlOWERHOriz lower BEHIND-PASSLINE
                       100+  450+100,386, 290,70,   50,  14, 1.0, 0.0 ,

// LEFT BIG 6-8 
                      90+796,315, 50,30,   50,  23, 1.0, 0.0 ,


// RIGHT Vertical PASSLINE
                          940+10,120, 34,260,   50,  13, 1.0, 0.0 ,
// RIGHT Vertical BEHIND-PASSLINE
                          940+48,120, 28,260,   50,  14, 1.0, 0.0 ,

// RIGHT Vertical  DONT PASS 
                      846+ 84,120, 18,130,   50,  0, 1.0, 0.0 ,


                      ];
                      
var gTableBetXYWHlen = gTableBetXYWH.length;

// 
function CheckForTableBet(x3,y3){

var tableBetNum=-1;

    var s;
    var x2,y2,w2,h2;

    for(s=0;s<gTableBetXYWHlen;s+=gTableBetXYWHoffset){
        x2 = gTableBetXYWH[ s + 0 ] + gCrapsTableX;
        y2 = gTableBetXYWH[ s + 1 ] + gCrapsTableY;
        w2 = gTableBetXYWH[ s + 2 ];
        h2 = gTableBetXYWH[ s + 3 ];

        if(x3 > x2  &&  x3<(x2+w2) &&
        	 y3 > y2  &&  y3<(y2+h2)
           ){
        	// inside  box hit
        	tableBetNum = s/gTableBetXYWHoffset;
        	return(tableBetNum);

        }//if


	}//for

	return(tableBetNum);

}//fn


function initTableBets(debugOnOff){

    var s;
    var x2,y2,w2,h2;
    var colstr0='red';

    for(s=0;s<gTableBetXYWHlen;s+=gTableBetXYWHoffset){
        x2 = gTableBetXYWH[ s + 0 ] + gCrapsTableX;
        y2 = gTableBetXYWH[ s + 1 ] + gCrapsTableY;
        w2 = gTableBetXYWH[ s + 2 ];
        h2 = gTableBetXYWH[ s + 3 ];

//     constructor(x,y,radius, w,h, colorOn , colorOff,colorText, jText ,
//						 jAlpha, rndCorner, pxStr){
if(colstr0=='red') colstr0='orange';
	else colstr0='red';

 var jbBut1 = new jButtonRound(      x2 ,
                                     y2 ,
                                      2,
                                      w2 ,
                                      h2 ,
                                  //    'green',  'red',  'white',
                                      'green', colstr0,  'white',
                                      "(*)",
                                      0.38, 2.0, "20"

            );
 
  if(   gDebugMode==1  || debugOnOff==1 )   jbBut1.draw()
    // if(   gDebugMode==1    )   jbBut1.draw()

     // c.fillStyle = "#ff9911";         
     // c.globalAlpha = 0.450; 
     // c.fillRect( x2,y2,w2,h2 );
     // c.globalAlpha = 1.0; 

    }//for


}




class TableBet{
    constructor( x,y, w,h,   radius, betValue, payOn,payOff,

                 color, betIdstr,  masterId,
                
                 playerIdstr, chipx, chipy, chipvalue, hrdwy){

        this.x =x
        this.y =y
        this.w =w
        this.h =h
        this.radius=radius

        this.betValue=betValue
        this.payOn=payOn
        this.payOff=payOff

        this.color= color 
        this.betIdstr=betIdstr
        this.masterId=masterId

        this.playerIdstr=playerIdstr
        this.chipx=chipx
        this.chipy=chipy
        this.chipvalue=chipvalue
        this.hrdwy=hrdwy

     }
    draw(){


        c.beginPath()
        c.arc(this.x, this.y, this.radius+3, 0, Math.PI*2, false) 
        c.fillStyle='black';
        c.fill()

        c.beginPath()
        c.arc(this.x, this.y, this.radius, 0, Math.PI*2, false) 
        c.fillStyle='white';//RandomColor(); //this.color
        c.fill()

        c.beginPath()
        c.arc(this.x, this.y, this.radius*0.90, 
            0, Math.PI*2, false) 
         c.fillStyle=this.color
        c.fill()

 
         c.fillStyle='red'
        c.font = "24px Arial";
        c.fillText( this.betIdstr, this.x-(this.radius*0.50) , this.y+7  );
   

    }

}



class Chip{
    constructor(x,y, radius, color, velocity){
        this.x =x
        this.y =y
        this.radius=radius
        this.color= color 
        this.velocity=velocity 
    }
    draw(){


        c.beginPath()
        c.arc(this.x, this.y, this.radius+2, 0, Math.PI*2, false) 
        c.fillStyle='black';
        c.fill()

        c.beginPath()
        c.arc(this.x, this.y, this.radius, 0, Math.PI*2, false) 
        // c.fillStyle=RandomColor();  
        c.fillStyle=this.color
 
        c.fill()

        c.beginPath()
        // c.arc(this.x, this.y, this.radius*.38, 
        c.arc(this.x, this.y, this.radius*.33, 
            0, Math.PI*2, false) 
        // c.fillStyle= RandomColor(); 
        c.fillStyle='grey' //this.color

        c.fill()

    }

}


class Projectile{
    constructor(x,y, radius, color, velocity){
        this.x =x
        this.y =y
        this.radius=radius
        this.color= color 
        this.velocity=velocity 
    }
    draw(){


        // c.beginPath()
        // c.arc(this.x, this.y, this.radius+2, 0, Math.PI*2, false) 
        // c.fillStyle='black';
        // c.fill()

        c.beginPath()
        c.arc(this.x, this.y, this.radius, 0, Math.PI*2, false) 
        c.fillStyle=RandomColor(); //this.color
        c.fill()

        c.beginPath()
        c.arc(this.x, this.y, this.radius*.12, 
            0, Math.PI*2, false) 
        // c.fillStyle= RandomColor(); 
        c.fillStyle=this.color

        c.fill()


// ************************************************************
// ************************************************************
// ************************************************************

     var offx = -30;
     var offy = -20;
// rect and yellow xy text
     c.fillStyle = "#223399";         
        c.globalAlpha = 0.350; 

     c.fillRect(this.x+2+offx, this.y-36+offy   ,    112, 32 );
     c.globalAlpha = 1.0; 

         c.fillStyle='yellow'
     c.font = "24px Arial";
     // c.fillText( (this.x).toString() , this.x, this.y );
     c.fillText( ""+(this.x).toString()+","+ (this.y).toString(), this.x+7+offx, this.y-14+offy );
   

    }

}



class ThePoint{
	constructor(x,y, radius, color){
		this.x =x
		this.y =y
		this.radius=radius
		this.color=color 
 	}
    draw(){

    	c.beginPath()
    	c.arc(this.x, this.y, this.radius, 
    		0, Math.PI*2, false) 
    	c.fillStyle=this.color
    	c.fill()

    	c.beginPath()
    	c.arc(this.x, this.y, this.radius*.85, 
    		0, Math.PI*2, false) 
    	c.fillStyle='orange'
    	c.fill()

    }
}

var n=0;
var buttonNumClicked = -1;

const x= canvas.width/2
const y= canvas.height/2

const thepoint = new ThePoint(x, 20 ,35,'white' )
//const thepoint = new ThePoint(x, y*1.5 ,44,'white' )

// init
//
// old 
// c.drawImage(img, 300, 300);
 
///thepoint.draw()


function DiceShake(){

        var jdice1,  jdice2;
        var bOff4=4;
        jdice1 = RandomNum(6)+1; 
        jdice2 = RandomNum(6)+1; 
        PlayRandomSFX('diceshake');

        var i=3;
        var jbBut = new jButtonRound(     bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                       gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  'red',  'white',
                                      jdice1.toString()+" "+ jdice2.toString(),     
                                    1.0, 1.0 , "24"
            );

    jbBut.draw();

}

function PlayRandomSFX(type){
    var jrnd=RandomNum( 3 );

    switch(type){
            case 'diceshake':
               if(jrnd<2) mySound_dice1.play();
                 else if(jrnd<1)  mySound_dice0.play();
                        else  mySound_dice2.play();
            break;
            case 'diceland':
                if(jrnd<2) mySound_diceland1.play();
                    else  mySound_diceland0.play();
               
            break;

    }

}
//
//  returns random # 0..num
//
function RandomNum( num ){
   return(   Math.floor(Math.random()*num)   ) ; 
}
function RandomColor(){
    var rstr = "#";
    var rrnd=0;

//  ie  #  + #0a   build color str
    rrnd = RandomNum(256);
    rstr = rstr + rrnd.toString(16);
//  #0af3
    rrnd = RandomNum(256);
    rstr = rstr + rrnd.toString(16);
//  #0af343
    rrnd = RandomNum(256);
    rstr = rstr + rrnd.toString(16);
    
    return( rstr );
}

var jcnt0=0;

var gdice1=1;
var gdice2=1;
var DiceTotal=1;


function drawDice(xx , yy, sc, diceval ){

	xx+=gCrapsTableX;
	yy+=gCrapsTableY - 100;

    switch(diceval){

        case 1: c.drawImage(imgdice1, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
        case 2: c.drawImage(imgdice2, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
        case 3: c.drawImage(imgdice3, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
        case 4: c.drawImage(imgdice4, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
        case 5: c.drawImage(imgdice5, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
        case 6: c.drawImage(imgdice6, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
         

    }

}

function  PlayNewTurnSFX(dice1,dice2){

    var dicetotal = dice1+dice2;
    var hardway = 0;

 
    if(dice1==dice2) hardway = dicetotal;  
        else hardway = 0;

    switch(dicetotal){
        case 2:
            sfx_2.play();
        break;

        case  3:
            sfx_3.play();
         break;
        case  4:
         if(hardway==0){ sfx_4.play(); }else{ sfx_4a.play(); }
         break;

        case  5:
            sfx_5.play();

         break;
        case  6:
         if(hardway==0){ sfx_6.play(); }else{ sfx_6a.play(); }
         break;

        case  7:
            sfx_7.play();        
         break;
        case  8:
         if(hardway==0){ sfx_8.play(); }else{ sfx_8a.play(); }
         break;

        case  9:
         sfx_9.play();    // 7 on the comeout pay the line

         break;
        case  10:
         if(hardway==0){ sfx_10.play(); }else{ sfx_10a.play(); }
         break;

        case  11:
            sfx_11.play();    // 7 on the comeout pay the line

         break;
        case  12:
         if( RandomNum(2) >= 1) sfx_12.play();
           else sfx_12a.play();
         break; 
         case  13:
         if( RandomNum(1) == 0) sfx_13.play();
           else sfx_13a.play();
         break;


        case  14:
             sfx_7a.play();    // 7 on the comeout pay the line
         break;

        case  15:
             sfx_15.play();  // made the point
         break;

        case  17:
             sfx_15a.play();  // the pointis
         break;

    }    

}//fn

function PayTable(tstr){
          LogGameEvent(tstr,0,( (gdice1+gdice2).toString()+"["+gdice1.toString()+","+ gdice2.toString()+"]" ) ) ;

    console.log("] PAY TABLE on Event: {" +tstr+"}");
}


function LogGameEvent(evstr, amt, betIdstr){
     gLastEvent ="{"+gPlayerUserIDNumstr+"_"+gPlayerUserIDstr+"}#"+gDiceThrown.toString()+"|"+ evstr+"_"+betIdstr+"$"+amt.toString()+",";
     gGameLogStr =gGameLogStr+gLastEvent ;

 console.log("] GAMELOG: {"+gGameLogStr +"}");
}


function PointIsOff(){

                thepointIs="OFF";
                LogGameEvent('ptOFF',0,thepointIs);

              thisStreak=0;

                to7Streak=0;  // unused depricate...

                 var crapsbutton1 = new CrapsButton(gCrapsTableX+ 20 + 50,gCrapsTableY + 50,gCrapsButtonRad,'black',1 );
                 crapsbutton1.draw();

                 var crapsbutton2 = new CrapsButton(gCrapsTableX+20 + 50+ gTableXOff,gCrapsTableY + 50,gCrapsButtonRad,'black',1 );
                 crapsbutton2.draw();

}

function DrawPatchOver(){
            //     var crapsbutton1 = new CrapsButton(20 + 50,100 + 50,gCrapsButtonRad,'black',1 );

        c.drawImage(imgpatch, 0, 0, 180,144, 70            -(gCrapsButtonRad*1.1)+gCrapsTableX, 50+gCrapsTableY-(gCrapsButtonRad*1.1), (180*0.50), (144* 0.50) );  
        c.drawImage(imgpatch, 0, 0, 180,144, 70+ gTableXOff-(gCrapsButtonRad*1.1)+gCrapsTableX, 50+gCrapsTableY-(gCrapsButtonRad*1.1), (180*0.50), (144* 0.50) );  

        // c.drawImage(imgcleanpoints, 0, 0, 1175,510, 70+ gTableXOff-(gCrapsButtonRad*1.1), 50+gCrapsTableY-(gCrapsButtonRad*1.1), (180*0.50), (144* 0.50) );  
// 
}

// ***************************
// ***************************
// ********         **********
// ********   main  **********
// ********   game  **********
// ********         **********
// ***************************
// ***************************
function DiceLand(){
    var bOff4 =4; 
    var hardway1= 0;
    var tmppct="";

    countdown+= countdownStart*0.25;
    if(countdown > countdownStart) countdown= countdownStart ;


    gDiceThrown++;

     gdice1= 1+ RandomNum(6);
     gdice2= 1+ RandomNum(6);
     DiceTotal   = gdice1+gdice2;

     if(gdice1==gdice2 && gdice1!=1 && gdice1!=6) hardway1= DiceTotal;

       LogGameEvent("di=",0,( (gdice1+gdice2).toString()+"["+gdice1.toString()+","+ gdice2.toString()+"]" ) ) ;
 

     // drawDice(670,100,0.435, gdice1   );
     // drawDice(798,100,0.435, gdice2   );

     PlayRandomSFX('diceland');


     if (thepointIs=="OFF") {
        // coming out ! sfx

             PlayNewTurnSFX(6,7 );  // 13== comin out/ new shooter

             if(DiceTotal==7){
                PlayNewTurnSFX(7,7 );    // pay comeout line
                PayTable("7comeout");
      // LogGameEvent("7payLine",0,( (gdice1+gdice2).toString()+"["+gdice1.toString()+","+ gdice2.toString()+"]" ) ) ;

             }else if(DiceTotal==11){
                PlayNewTurnSFX(6,5 );    // pay comeout line
                PayTable("11comeout");

             }else if(DiceTotal==12){
                PlayNewTurnSFX(6,6 );    // pay comeout line

             }else if( DiceTotal!=2  &&  DiceTotal!=3 ){
                thepointIs= DiceTotal.toString();
               // PlayNewTurnSFX(9,8);    // 17== the pointIS
        
                 PlayNewTurnSFX(gdice1,gdice2);
       LogGameEvent("PtON=",0,( (gdice1+gdice2).toString()+"["+gdice1.toString()+","+ gdice2.toString()+"]" ) ) ;

                 //  crapsbutton placement here*

                 var trX = ThePointLocations[  2 * DiceTotal ]  + gCrapsTableX ;
                 var trY = ThePointLocations[ (2 * DiceTotal )+1 ] + gCrapsTableY;

                 var crapsbutton1 = new CrapsButton(trX, trY, gCrapsButtonRad,'white',1 )
                 crapsbutton1.draw()
                 var crapsbutton2 = new CrapsButton(trX + ThePointLocationXAdder , trY, gCrapsButtonRad,'white',1 )
                 crapsbutton2.draw()

                 DrawPatchOver();
                 // var crapsbutton1 = new CrapsButton(20 + 50,100 + 50,gCrapsButtonRad,'white',1 )
                 // crapsbutton1.draw()
                 // var crapsbutton2 = new CrapsButton(20 + 50+gTableXOff,100 + 50,gCrapsButtonRad,'white',1 )
                 // crapsbutton2.draw()


             }

//***************************** POINT ON
     // point_IS ON       
     }else{

//***************************** 7 is  ROLLED
         if(DiceTotal==7){
            // if(longestTo7Streak<to7Streak)  longestTo7Streak = to7Streak ;
            if(thisStreak > longestTo7Streak) { 
                longestTo7Streak= thisStreak;
                LogGameEvent("To7StreakBroken",0,( (gdice1+gdice2).toString()+"["+gdice1.toString()+","+ gdice2.toString()+"]" ) ) ;

            }
            c.drawImage(img, 0, 0,  2044,941,  gCrapsTableX,gCrapsTableY, 1024,512);
 
            RenderDice();

             PointIsOff();
             PayTable("7out");
             PlayNewTurnSFX(gdice1,gdice2);
  //           thisStreak=0;
             gSevenOuts++;


            }else thisStreak++;


//***************************** THE POINT_IS MADE / ROLLED
        if( DiceTotal.toString()==thepointIs ){
            if(thisStreak > longestStreak){
               longestStreak= thisStreak;
                LogGameEvent("PtStreakBroken",0,( (gdice1+gdice2).toString()+"["+gdice1.toString()+","+ gdice2.toString()+"]" ) ) ;
            }

          LogGameEvent("Pt"+thepointIs+"Made",0,( thepointIs ) ) ;

          c.drawImage(imgcleanpoints, 0, 0, 1175,510, 32+70+ gCrapsTableX, 2+ 50+gCrapsTableY, (1175*0.6650), (510* 0.6650) );  

            PayTable("point");
             PointIsOff();

            PlayNewTurnSFX(7,8);    // made the point
             gPointsMade++;
//thisStreak=0;

            }else {
                PlayNewTurnSFX(gdice1,gdice2);

            }
            

        }

// 
//     gdice1  gdice2 
    var i=3;
    var jbBut = new jButtonRound(     bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                       gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  'blue',  'white',
                                      gdice1.toString()+" "+ gdice2.toString()+" "+gLastEvent,     
                                    1.0, 1.0 , "24"
            );

    jbBut.draw();


    tmppct=" ";

if(thepointIs!="OFF") tmppct= ", "+(100*gPointPcts[DiceTotal]).toFixed(1)+"%";

     var i=4;
    var jbBut = new jButtonRound(     bRects[  (i*bOff4) + 0 ] +gCrapsTableX,
                                      bRects[  (i*bOff4) + 1 ] +gCrapsTableY-100,
                                       gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  'white',  'black',
                                     // ( "Poi nt is "+ thepointIs+"  "+(100*gPointPcts[DiceTotal]).toFixed(1)+"%"),     
                                     ( "Point: "+ thepointIs+tmppct ), //"  "+(100*gPointPcts[DiceTotal]).toFixed(1)+"%"),     
                                    1.0, 1.0, "26"
            );

    jbBut.draw();
 
     RenderDice();


}//fn

function RenderDice(){

     drawDice(dice1X,dice1Y,dicescale, gdice1   );
     drawDice(dice2X,dice2Y,dicescale, gdice2   );

     // drawDice(670,100,0.435, gdice1   );
     // drawDice(798,100,0.435, gdice2   );
}

function IncDenomination1() {
     gChipIndex++;
    if(gChipIndex >= gChipIndexLen) gChipIndex=0;  // clamp to max
 
      const chip1 = new Chip(gTableXOff*0.54 ,38,18,gChipDenominationsColors[ gChipIndex ],1 )
       chip1.draw()

switch(gChipIndex){
    case 0:
    case 2:
        mySound_chips5.play();
    break;

    case 1:
    case 3:
        mySound_chips4.play();
    break;

    case 4:
    case 6:
        mySound_chips3.play();
    break;

    case 5:
    case 7:
        mySound_chips1.play();
    break;

    case 8:
    case 9:
        mySound_chips2.play();
    break;


  }//sw

}     


function ShowDenomination() {
  var xxx = bRects[2 * 4 + 0] +30;    // ie idx 2 * 4 off  
        // const chip1 = new Chip(gTableXOff*0.54 ,38,18,gChipDenominationsColors[ gChipIndex ],1 )
        const chip1 = new Chip(xxx ,38,18,gChipDenominationsColors[ gChipIndex ],1 )
        chip1.draw()
           

}
function PlayChipsSFX(jnum){

        switch(jnum){
           case 0: mySound_chips1.play();  break;
           case 1: mySound_chips2.play();  break;
           case 2: mySound_chips3.play();  break;
           case 3: mySound_chips4.play();  break;
           case 4: mySound_chips5.play();  break;
        }
}


addEventListener('click', (event) => {
	console.log(event)
	var xx = event.clientX
	var yy = event.clientY

    // global
  n++; 

  

    var bclicked = GetButtonNumClicked(xx,yy);
//gButtonNumClicked
//var jrnd= RandomNum( 3 );
    if(bclicked==-1 && yy > gCrapsTableY){
       

//PLACE CHIPS HERE
         PlacePlayerBet(xx,yy);
         
           
    }else{
        switch(bclicked){
           // case 0: mySound_dice0.play();  break;
           // case 1: mySound_diceland1.play();  break;
           // case 0: PlayRandomSFX('diceshake'); break;   // shake dice
           case 0: DiceShake(); break;
           case 1:  DiceLand();  break;   // throw dice
            case 2: ShowDenomination(); break;
           // case 2: if(countdown<(countdownStart-25)) countdown+=25;  break;
           case 3:
           	;// if ( gDebugMode==0 ) gDebugMode=1;  else gDebugMode=0;
            break;
           case 4:  break;
           case 5:
             if (gTimerBarMultiplier == gTimerBarMultiplierStart)  gTimerBarMultiplier = 0.025;
              else gTimerBarMultiplier = 0.125;
            break;
            }
        }
     

  }

)// addEventListener



function ProcessBets(ptRolled, buttonOnOff ){
  // loop through array here

}


function UpdateBetButton(argstr) {

    var i=3; var bOff4=4;

    var jbBut = new jButtonRound(     bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                       gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  'orange',  'black',
                                     // gdice1.toString()+" "+ gdice2.toString()+" "+argstr,     
                                        argstr,     
                                    1.0, 1.0 , "20"
            );

    jbBut.draw();

}//fn


function PlacePlayerBet(xx1,yy1){

// // clamp here for 0 chips blowout...  or < chipSize
//         const playerchip = new Chip(xx1,yy1,13, gChipDenominationsColors[ gChipIndex ],1 )
//         playerchip.draw()
	
	var tstr="";
	var tablebetNo=-1;
	var s=0; 
  var betidx=20;
  var betodds=1.0;
  var hardstr="";
  var betstr0="Nil"; 
  var jrnd=0;

	tablebetNo = CheckForTableBet(xx1,yy1);
	if( tablebetNo>=0){

// clamp here for 0 chips blowout...  or < chipSize
        var playerchip = new Chip(xx1,yy1,13, gChipDenominationsColors[ gChipIndex ],1 )
        playerchip.draw()

        jcnt0++;
        jrnd= jcnt0 %5;
        PlayChipsSFX(jrnd);

		s = tablebetNo* gTableBetXYWHoffset;

    betidx = gTableBetXYWH[ s + 5 ];
    betodds =  gTableBetXYWH[ s + 6 ];

    if( betidx< gTableBetNamesLen && betidx>=0  ) {
      betstr0= gTableBetNames[betidx] +", pays "+ betodds.toString()+":1" ;
    }

    if(gTableBetXYWH[ s + 7] == 1.0 ) hardstr="Hard"; 
    tstr ="betID_" +gTableBetXYWH[ s + 5].toString()+"_" +betstr0;
		// tstr1 = gTableBetNames[ s + 0];
//gDebugMode
         // LogGameEvent(tstr,gChipDenominations[ gChipIndex ],( (gdice1+gdice2).toString()+"Rolled_("+xx1.toString()+","+ yy1.toString()+")," ) ) ;
          LogGameEvent(tstr,gChipDenominations[ gChipIndex ],"betplaced") ;
          UpdateBetButton("$"+ gChipDenominations[ gChipIndex ].toString()+" "+ betstr0 );

	}else  UpdateStatButton( gdice1.toString()+","+ gdice2.toString());
// if table bet VALID

           gPlayerChips -= gChipDenominations[ gChipIndex ];
           gHouseChips +=gChipDenominations[ gChipIndex ];
  

}



class jButtonRound {
    constructor(x,y,radius, w,h, colorOn , colorOff,colorText, jText , jAlpha, rndCorner, pxStr){
        this.x =x
        this.y =y 
        this.radius =radius
        this.w =w
        this.h =h 
        this.colorOn =colorOn 
        this.colorOff=colorOff
        this.colorText=colorText
        this.jText   =jText

        this.jAlpha   =jAlpha
        this.rndCorner   =rndCorner
        this.pxStr = pxStr
    }

    draw(){ 

    var rect = [20, 20, 300, 300],
    cr = 25;            // corner radius

    cr     = this.radius;
    rect[0]= this.x;
    rect[1]= this.y;
    rect[2]= this.w;
    rect[3]= this.h;

// if(this.rndCorner){}
//
//

    var pi = Math.PI,       // cache it here to make code more readable
    x1 = rect[0],       // cache points
    y1 = rect[1],
    x2 = rect[2] + x1,
    y2 = rect[3] + y1;

// create a rounded rectangle path
    c.beginPath();

    c.arc(x1 + cr, y1 + cr, cr, pi, 1.5 * pi);  // upper left corner
    c.arc(x2 - cr, y1 + cr, cr, 1.5 * pi, 0);   // upper right corner
    c.arc(x2 - cr, y2 - cr, cr, 0, 0.5 * pi);   // lower right corner
    c.arc(x1 + cr, y2 - cr, cr, 0.5 * pi, pi);  // lower left corner

    c.closePath();
    c.globalAlpha =this.jAlpha; // 0.50; 

    c.fillStyle=this.colorOff;
    c.fill()

    c.stroke();
    c.globalAlpha = 1.0; 


        c.beginPath()
        c.arc(this.x-25, this.y-25, this.radius/4, 0, Math.PI*2, false) 
        c.fillStyle=this.colorOn ; //Off
        c.fill()

         // c.Rect(  (this.x-this.radius), (this.-(0.5625*this.radius)), 192    , 108);
        // c.strokeRect(  (this.x-this.radius), (this.-(0.5625*this.radius)), 192   , 108);

        // c.fillStyle =this.colorOff ; // colorOn; //"#fa00a0";
        // c.strokeRect(this.x+2, this.y-28   ,    192/2       , 108/2); //this.x-25, this.y-25   ,    500 ,500 );
      
        // c.fillStyle = "#8899aa"; 
        // c.globalAlpha = 0.50; 
        // c.fillRect(this.x+2, this.y-28   ,    192/2     , 108/2 );
        // c.globalAlpha = 1.0; 

        //c.fillRect(this.x+2, this.y-28   ,    192/.8      , 108/2 );
    
// ctx.strokeRect(20, 20, 150, 100);
 
     //     c.fillStyle='orange'
        // c.font = "42px Arial";
        // c.fillText( "jButton active."+"..",  7,  14 );
   

        c.fillStyle=this.colorText ; //'yellow'
        c.font = this.pxStr +"px Arial";   //"24px
        if(this.pxStr=="")  c.font ="24px Arial";
        // c.fillText( (this.x).toString() , this.x, this.y );
        c.fillText( this.jText, this.x+this.radius*0.8, this.y+(0.65* this.h ) );
   

 



    }

}


 


function DrawDenomButton( ){
 var i, bOff4=4;
 
 var tmpstr=" ";
 var tmpcol=gButColOn;
 var tmpcoloff = gButColOff;
 var txtcol = 'white';
 
                   txtcol='white';
                    i=2; 
                   // IncDenomination1();
                     tmpstr =      gChipDenominations[ gChipIndex ].toString();
                    tmpcol = 'white'; 
                    tmpcoloff = "#dcdcdc";
                    txtcol = 'black';
                 

 
           
                var jbBut = new jButtonRound(        bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                       gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  tmpcol, txtcol,
                                       bTexts[ i ]+ tmpstr,             
                                    1.0, 1.0, "24"
            );
                jbBut.draw();
                ShowDenomination();

}// fn


function GetButtonNumClicked(xu,yu){
var i, bOff4=4;

gButtonNumClicked=-1;   // indicate not clicked within button # 0..n

 var tmpstr=" ";
 var tmpcol=gButColOn;
 var tmpcoloff = gButColOff;
 var txtcol = 'white';

//  var bRects = [   10,10, 180,60,

     for(i=0;i<numButtons;i++){
      
        if(  ( xu >=    bRects[ (i*bOff4) + 0 ] )                              &&
             ( xu <=    bRects[ (i*bOff4) + 0 ] + bRects[ (i*bOff4) + 2 ]   )  &&

             ( yu >=    bRects[ (i*bOff4) + 1 ] )                              &&
             ( yu <=    bRects[ (i*bOff4) + 1 ] + bRects[ (i*bOff4) + 3 ]   )) {

            gButtonNumClicked=i;

            txtcol='white';
                                    // check for denom button =[2]
                if (i==2) { 
                    IncDenomination1();
                    //tmpstr ="         $"+      gChipDenominations[ gChipIndex ].toString();
                    tmpstr =      gChipDenominations[ gChipIndex ].toString();
                    tmpcol = 'white';//    gChipDenominationsColors[ gChipIndex ];
                    tmpcoloff = "#fefefe";
                    txtcol = 'black';
                  //  tmpcoloff = gChipDenominationsColors[ gChipIndex ];
                }



            if(bClickStatus[i]==0){
                bClickStatus[i]=1;

           
                var jbBut = new jButtonRound(        bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                       gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  tmpcol, txtcol,
                                      // 'green',  gButColOn,  'white',
                                      bTexts[ i ]+ tmpstr,           // "but#"+gButtonNumClicked.toString() 
                                    1.0, 1.0, "24"
            );

        }else{
            bClickStatus[i]=0;
                var jbBut = new jButtonRound(        bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                      gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                    //  'green', gButColOff,  'white',
                                      'green', tmpcoloff,  txtcol,
                                          bTexts[ i ]+ tmpstr,           // "but#"+gButtonNumClicked.toString() 

                                      // bTexts[ i ]+bOffStr ,
                                      1.0, 1.0, "24"
          

            );

        }
 
        jbBut.draw()
         
        return(i);
        }//if


    }//for

    return(gButtonNumClicked);

}//fn



function drawTopButtons(){
var i=2,bOff4=4;  
    
var x0= 12, y0=24, w0=170, h0=50;

 

     for(i=0;i<numButtons;i++){
        var jbBut = new jButtonRound( bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                      gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  gButColOff,  'white',
                                      bTexts[ i ]+bOffStr,
                                       1.0, 1.0, "24"

            );
 
        jbBut.draw()
 
        }//for

 

}// fn

function MainGame(){
    drawTopButtons();
    startSound();
    gameLoop(1000);
}



//*****************************
//*****************************
//*****************************
//
//
         MainGame();
//
//
//*****************************
//*****************************


    // Run myfunc every second
var myfunc = setInterval( function() {

    var now = new Date().getTime();
    var timeleft = countDownDate - now;
    countdown-=4;

    if (countdown>25) gameLoop(countdown);
        else {
            DiceLand();
            countdown=countdownStart;
                }
// }, (1000 * 0.05) );   // 0.25 1000= 1 sec
  }, (1000 *gTimerBarMultiplier) );   // 0.25 1000= 1 sec
//


function gameLoop(barlen) {
 
 if(barlen<26){
    
  return;
 }  


   var p;
   var colstr; 
   var tstr = gdice1.toString()+ "  "+ gdice2.toString();
   var streakstr=" [CurStreak/Max="+thisStreak.toString()+ "/"+longestStreak.toString()+ 
                 "], [To7Streak="+longestTo7Streak.toString()+ "], [PtsMade="+gPointsMade+
                   "], [7-Outs="+gSevenOuts+"] [7s/Pts="+(( gSevenOuts/gPointsMade ).toFixed(1).toString())+"], [DiThrown="+gDiceThrown+"], House= +/-:$"+gHouseChips +", UR Chips: "+gPlayerChips.toString() ;

  var barLong  = new jButtonRound(4,74,10, 1000,   24,  'green',  'cyan',  'white', " " , 1.0, 1.0, "24"  ); 
  var barShort = new jButtonRound(4,74,10, barlen ,24,  'green',  'yellow',  'black', streakstr , 1.0, 1.0 , "16" );
 
    barLong.draw();
    barShort.draw();
 
    if(gFirstTime==0){
         mySound_crowd.play();
         gFirstTime=1;
    }

}




function startSound() {

    mySound_chips1 = new sound("mp3/chips0.mp3");
    mySound_chips2 = new sound("mp3/chips1.mp3");
    mySound_chips3 = new sound("mp3/chips2.mp3");
    mySound_chips4 = new sound("mp3/chips3.mp3");
    mySound_chips5 = new sound("mp3/chips4.mp3");

    mySound_crowd = new sound("mp3/crowd.mp3");

    mySound_dice0 = new sound("mp3/dice.mp3");
    mySound_dice1 = new sound("mp3/dicelong0.mp3");
    mySound_dice2 = new sound("mp3/dicelong1.mp3");

    mySound_diceland0 = new sound("mp3/diceland0.mp3");
    mySound_diceland1 = new sound("mp3/diceland1.mp3");


     sfx_2  = new sound("mp3/numbers/sfx_2.mp3");
    // sfx_2a = new sound("mp3/sfx_2a.mp3");
    sfx_3  = new sound("mp3/numbers/sfx_3.mp3");
    // sfx_3a = new sound("mp3/sfx_3.mp3");

    sfx_4   = new sound("mp3/numbers/sfx_4.mp3");
    sfx_4a  = new sound("mp3/numbers/sfx_4hard.mp3");

     sfx_5  = new sound("mp3/numbers/sfx_5.mp3");
    // sfx_5a = new sound("mp3/sfx_5a.mp3");
     sfx_6  = new sound("mp3/numbers/sfx_6.mp3");
     sfx_6a = new sound("mp3/numbers/sfx_6hard.mp3");

   sfx_7     = new sound("mp3/numbers/sfx_7out.mp3");
   sfx_7a    = new sound("mp3/numbers/sfx_7payline.mp3");

      sfx_8  = new sound("mp3/numbers/sfx_8.mp3");
      sfx_8a = new sound("mp3/numbers/sfx_8hard.mp3");

    sfx_9  = new sound("mp3/numbers/sfx_9.mp3");
 
      sfx_10 = new sound("mp3/numbers/sfx_10.mp3");
      sfx_10a= new sound("mp3/numbers/sfx_10hard.mp3");

      sfx_11 = new sound("mp3/numbers/sfx_11.mp3");

     sfx_12a = new sound("mp3/numbers/sfx_12.mp3");
    sfx_12= new sound("mp3/numbers/sfx_12mid.mp3");

    sfx_13 = new sound("mp3/numbers/sfx_comingout.mp3");
    sfx_13a = new sound("mp3/numbers/sfx_newshooter.mp3");

    // sfx_14 = new sound("mp3/numbers/sfx_madepoint.mp3");
    // sfx_14a = new sound("mp3/numbers/sfx_thepointis.mp3");

    sfx_15 = new sound("mp3/numbers/sfx_madepoint.mp3");
    sfx_15a = new sound("mp3/numbers/sfx_thepointis.mp3");


}

function sound(src) {
    this.sound = document.createElement("audio");
    this.sound.src = src;
    this.sound.setAttribute("preload", "auto");
    this.sound.setAttribute("controls", "none");
    this.sound.style.display = "none";
    document.body.appendChild(this.sound);
    this.play = function(){
        this.sound.play();
    }
    this.stop = function(){
        this.sound.pause();
    }    
}




/*


var mySound;

function startGame() {
    mySound = new sound("bounce.mp3");
//    myGameArea.start();
}

function sound(src) {
    this.sound = document.createElement("audio");
    this.sound.src = src;
    this.sound.setAttribute("preload", "auto");
    this.sound.setAttribute("controls", "none");
    this.sound.style.display = "none";
    document.body.appendChild(this.sound);
    this.play = function(){
        this.sound.play();
    }
    this.stop = function(){
        this.sound.pause();
    }    
}








<audio id="myAudio" controls>
  <source src="horse.ogg" type="audio/ogg">
  <source src="horse.mp3" type="audio/mpeg">
  Your browser does not support the audio element.
</audio><br>

<button onclick="enableLoop()" type="button">Enable loop</button>
<button onclick="disableLoop()" type="button">Disable loop</button>
<button onclick="checkLoop()" type="button">Check loop status</button>

<script>
var x = document.getElementById("myAudio");

function enableLoop() { 
  x.loop = true;
  x.load();
} 

function disableLoop() { 
  x.loop = false;
  x.load();
} 

function checkLoop() { 
  alert(x.loop);
} 
</script> 




/// old button

class jButton {
    constructor(xCenter,yCenter,radius, w,h, colorOn , colorOff, jText ){//, jAlpha, rndCorner){
        this.x =xCenter
        this.y =yCenter 
        this.radius =radius
        this.w =w
        this.h =h 
        this.colorOn =colorOn 
        this.colorOff=colorOff
        this.jText   =jText
    }

    draw(){

        c.beginPath()
        c.arc(this.x-25, this.y-25, this.radius/4, 0, Math.PI*2, false) 
        c.fillStyle=this.colorOff
        c.fill()

         // c.Rect(  (this.x-this.radius), (this.-(0.5625*this.radius)), 192    , 108);
        // c.strokeRect(  (this.x-this.radius), (this.-(0.5625*this.radius)), 192   , 108);

        c.fillStyle =this.colorOff ; // colorOn; //"#fa00a0";
        c.strokeRect(this.x+2, this.y-28   ,    192/2       , 108/2); //this.x-25, this.y-25   ,    500 ,500 );
      
        c.fillStyle = "#8899aa"; 
        c.globalAlpha = 0.50; 
        c.fillRect(this.x+2, this.y-28   ,    192/2     , 108/2 );
        c.globalAlpha = 1.0; 

        //c.fillRect(this.x+2, this.y-28   ,    192/.8      , 108/2 );
    
// ctx.strokeRect(20, 20, 150, 100);
 
     //     c.fillStyle='orange'
        // c.font = "42px Arial";
        // c.fillText( "jButton active."+"..",  7,  14 );
   

        c.fillStyle=this.colorOn ; //'yellow'
        c.font = "16px Arial";
        // c.fillText( (this.x).toString() , this.x, this.y );
        c.fillText( this.jText  , this.x+this.radius, this.y-0 );
   

 



    }

}


<p id="demo"></p>

<script>
// Set the date we're counting down to
var countDownDate = new Date("Jan 5, 2021 15:37:25").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>



var countDownDate = new Date("Jul 25, 2021 16:37:52").getTime();

    // Run myfunc every second
    var myfunc = setInterval(function() {

    var now = new Date().getTime();
    var timeleft = countDownDate - now;
        
}, 1000);




<script>
var fruits = ["Banana", "Orange", "Apple", "Mango"];
document.getElementById("demo").innerHTML = fruits;

function myFunction() {
  fruits.push("Kiwi");
  document.getElementById("demo").innerHTML = fruits;
}
</script>

*/
 

