// index.js
 

// var c 			 = document.getElementById("myCanvas");
const canvas 	 = document.querySelector("canvas");
const c 		 = canvas.getContext("2d");

canvas.width        = innerWidth
canvas.height       = innerHeight

var gButtonNumClicked=-1;
var gRound= 14;
var n; //event listener # times

var gFirstTime=0;
var gPlayerChips =2000;

var gButColOff= "#6933cc";//"#33ff8a"; //"#d4f5f5"; //"#aa3322";
var gButColOn = "#22aa33";

var bOff = 4;
var bOffStr="";//"[Off]";

// INIT'd VARs
var thepointIs="OFF";
var longestStreak=0;
var thisStreak=0;
var gPointsMade=0;
var gSevenOuts=0;
var gDiceThrown=0;
var gSecondsElapsed=0;
//
//

var gPointPcts = [
//                 ie  5.5%(2)
                      0.00, 0.00,  
                      0.0277, 0.0555, 0.08333,0.1111,
                      0.1388, 0.1666, 0.1388,
                      0.1111, 0.08333,0.0555,0.0277


                ];

var bRects = [
                      10,10, 190,60,
                     220,10, 190,60, 
                     440,10, 190,60,
                     680,10, 60,60,
                     760,10, 240,60,

                     //  780,12, 60,60,
                     // 850, 12, 60,60
                ];

var bClickStatus = [
                       0,0,0,0,0  //, 0,0
                ];

var bTexts= [
                    "SHAKE DICE",
                    "SHOOT DICE",
                    "INC TIME",
                    "6",
                    "6" //,

                    // "3",
                    // "3"

                ];

var numButtons = bTexts.length;


// needs to be array
var    mySound;
var    mySound_chips1  ;
var    mySound_chips2 ;
var    mySound_chips3 ;

var    mySound_chips4 ;
var    mySound_chips5 ;

var    mySound_crowd ;
var    mySound_dice0 ;


var      sfx_2 ; // = new sound("mp3/sfx_2.mp3");
var      sfx_2a; // = new sound("mp3/sfx_2a.mp3");
var      sfx_3 ; // = new sound("mp3/sfx_3.mp3");
var      sfx_3a; // = new sound("mp3/sfx_3.mp3");
var      sfx_4;//   = new sound("mp3/numbers/sfx_4.mp3");
var     sfx_4a ;//  = new sound("mp3/numbers/sfx_4hard.mp3");

var     sfx_5 ; // = new sound("mp3/sfx_5.mp3");
var      sfx_5a; //= new sound("mp3/sfx_5a.mp3");

var      sfx_6 ; // = new sound("mp3/sfx_6.mp3");
var      sfx_6a; // = new sound("mp3/sfx_6a.mp3");

var      sfx_7 ; // = new sound("mp3/sfx_7.mp3");
var      sfx_7a; // = new sound("mp3/sfx_7a.mp3");
    
var      sfx_8  ; //= new sound("mp3/sfx_8.mp3");
var      sfx_8a ; //= new sound("mp3/sfx_8a.mp3");

var      sfx_9  ; //= new sound("mp3/sfx_9.mp3");
var      sfx_9a ; //= new sound("mp3/sfx_9.mp3");

var      sfx_10 ; //= new sound("mp3/sfx_10.mp3");
var      sfx_10a; //= new sound("mp3/sfx_10a.mp3");

var      sfx_11 ; //= new sound("mp3/sfx_11.mp3");
var      sfx_11a; //= new sound("mp3/sfx_11a.mp3");
var      sfx_12 ; //= new sound("mp3/sfx_12.mp3");
var      sfx_12a; //= new sound("mp3/sfx_12a.mp3");
var      sfx_13;
var      sfx_13a;
var      sfx_14;
var      sfx_14a;
var     sfx_15;
var     sfx_15a;

const imgdice1 = new Image();
imgdice1.src = "imgcraps/dice1.png";

const imgdice2 = new Image();
imgdice2.src = "imgcraps/dice2.png";

const imgdice3 = new Image();
imgdice3.src = "imgcraps/dice3.png";

const imgdice4 = new Image();
imgdice4.src = "imgcraps/dice4.png";

const imgdice5 = new Image();
imgdice5.src = "imgcraps/dice5.png";

const imgdice6 = new Image();
imgdice6.src = "imgcraps/dice6.png";




 var countdownStart=1000;
 var countdown =1000;
 var countdownH=400;

 
var countDownDate = new Date("Oct 23, 2020 01:00:00").getTime();



//
//
// IMAGE STUFF
//
// var img = document.getElementById("crapstable");
var gCrapsTableY = 100;
const img = new Image()
img.src = "crapstable.jpg"

img.onload = () => {
//  (image, sx, sy, sWidth, sHeight,  dx, dy, dWidth, dHeight, )
    ;// c.drawImage(img, 0, 0, 2044,941,   100,100, 1022,470)

      c.drawImage(img, 0, 0,  2044,941,  4,gCrapsTableY, 1024,512)

                 var projectile1 = new CrapsButton(100 + 50,100 + 50,40,'black',1 );
                 projectile1.draw();
}

/*
  (image, sx, sy, sWidth, sHeight,  dx, dy, dWidth, dHeight, )

 ERROR: The provided value is not of type 
 '(CSSImageValue or HTMLImageElement or SVGImageElement or 
   HTMLVideoElement or HTMLCanvasElement or ImageBitmap or OffscreenCanvas)
 SOLN:
 const img = new Image()
img.src = "./cat.jpg"
img.onload = () => {
  context.drawImage(img, 0, 0)
}
*/


class CrapsButton{
    constructor(x,y, radius, color, velocity){
        this.x =x
        this.y =y
        this.radius=radius
        this.color= color 
        this.velocity=velocity 
     }
    draw(){


        c.beginPath()
        c.arc(this.x, this.y, this.radius+3, 0, Math.PI*2, false) 
        c.fillStyle='black';
        c.fill()

        c.beginPath()
        c.arc(this.x, this.y, this.radius, 0, Math.PI*2, false) 
        c.fillStyle='white';//RandomColor(); //this.color
        c.fill()

        c.beginPath()
        c.arc(this.x, this.y, this.radius*0.90, 
            0, Math.PI*2, false) 
         c.fillStyle=this.color
        c.fill()


        if(this.color=='white'){
             c.font = "48px Arial";
             c.fillStyle='black';
          c.fillText( thepointIs, this.x-(this.radius*0.330) , this.y+14  );

         }else{  //black
             c.font = "24px Arial";
             c.fillStyle='white';
             if(thepointIs=="10")  c.fillText( thepointIs, this.x-(this.radius*0.70) , this.y+7  );
                else   c.fillText( thepointIs, this.x-(this.radius*0.60) , this.y+7  );


         }

        // c.fillText( thepointIs, this.x-(this.radius*0.50) , this.y+7  );
   

    }

}



class Projectile{
    constructor(x,y, radius, color, velocity){
        this.x =x
        this.y =y
        this.radius=radius
        this.color= color 
        this.velocity=velocity 
    }
    draw(){


        c.beginPath()
        c.arc(this.x, this.y, this.radius+2, 0, Math.PI*2, false) 
        c.fillStyle='black';
        c.fill()

        c.beginPath()
        c.arc(this.x, this.y, this.radius, 0, Math.PI*2, false) 
        c.fillStyle=RandomColor(); //this.color
        c.fill()

        c.beginPath()
        c.arc(this.x, this.y, this.radius*.38, 
            0, Math.PI*2, false) 
        // c.fillStyle= RandomColor(); 
        c.fillStyle=this.color

        c.fill()


//************************************************************
//************************************************************
//************************************************************

//      var offx = -30;
//      var offy = -20;
// // rect and yellow xy text
//      c.fillStyle = "#223399";         
//         c.globalAlpha = 0.350; 

//      c.fillRect(this.x+2+offx, this.y-36+offy   ,    112, 32 );
//      c.globalAlpha = 1.0; 

//          c.fillStyle='yellow'
//      c.font = "24px Arial";
//      // c.fillText( (this.x).toString() , this.x, this.y );
//      c.fillText( ""+(this.x).toString()+","+ (this.y).toString(), this.x+7+offx, this.y-14+offy );
   

    }

}



class ThePoint{
	constructor(x,y, radius, color){
		this.x =x
		this.y =y
		this.radius=radius
		this.color=color 
 	}
    draw(){

    	c.beginPath()
    	c.arc(this.x, this.y, this.radius, 
    		0, Math.PI*2, false) 
    	c.fillStyle=this.color
    	c.fill()

    	c.beginPath()
    	c.arc(this.x, this.y, this.radius*.85, 
    		0, Math.PI*2, false) 
    	c.fillStyle='orange'
    	c.fill()

    }
}

var n=0;
var buttonNumClicked = -1;

const x= canvas.width/2
const y= canvas.height/2

const thepoint = new ThePoint(x, 20 ,35,'white' )
//const thepoint = new ThePoint(x, y*1.5 ,44,'white' )

// init
//

c.drawImage(img, 300, 300);
 
///thepoint.draw()


function DiceShake(){

        var jdice1,  jdice2;
        var bOff4=4;
        jdice1 = RandomNum(6)+1; 
        jdice2 = RandomNum(6)+1; 
        PlayRandomSFX('diceshake');

        var i=3;
        var jbBut = new jButtonRound(     bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                       gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  'red',  'white',
                                      jdice1.toString()+" "+ jdice2.toString(),     
                                    1.0, 1.0 , "24"
            );

    jbBut.draw();

}

function PlayRandomSFX(type){
    var jrnd=RandomNum( 3 );

    switch(type){
            case 'diceshake':
               if(jrnd<2) mySound_dice1.play();
                 else if(jrnd<1)  mySound_dice0.play();
                        else  mySound_dice2.play();
            break;
            case 'diceland':
                if(jrnd<2) mySound_diceland1.play();
                    else  mySound_diceland0.play();
               
            break;

    }

}
//
//  returns random # 0..num
//
function RandomNum( num ){
   return(   Math.floor(Math.random()*num)   ) ; 
}
function RandomColor(){
    var rstr = "#";
    var rrnd=0;

//  ie  #  + #0a   build color str
    rrnd = RandomNum(256);
    rstr = rstr + rrnd.toString(16);
//  #0af3
    rrnd = RandomNum(256);
    rstr = rstr + rrnd.toString(16);
//  #0af343
    rrnd = RandomNum(256);
    rstr = rstr + rrnd.toString(16);
    
    return( rstr );
}

var jcnt0=0;

var gdice1=1;
var gdice2=1;
var DiceTotal=1;


function drawDice(xx , yy, sc, diceval ){

    switch(diceval){

        case 1: c.drawImage(imgdice1, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
        case 2: c.drawImage(imgdice2, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
        case 3: c.drawImage(imgdice3, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
        case 4: c.drawImage(imgdice4, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
        case 5: c.drawImage(imgdice5, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
        case 6: c.drawImage(imgdice6, 0, 0, 256,256, xx,yy, (256*sc), (256*sc) );  break;
         

    }

}

function  PlayNewTurnSFX(dice1,dice2){

    var dicetotal = dice1+dice2;
    var hardway = 0;

 
    if(dice1==dice2) hardway = dicetotal;  
        else hardway = 0;

    switch(dicetotal){
        case 2:
            sfx_2.play();
        break;

        case  3:
            sfx_3.play();
         break;
        case  4:
         if(hardway==0){ sfx_4.play(); }else{ sfx_4a.play(); }
         break;

        case  5:
            sfx_5.play();

         break;
        case  6:
         if(hardway==0){ sfx_6.play(); }else{ sfx_6a.play(); }
         break;

        case  7:
            sfx_7.play();        
         break;
        case  8:
         if(hardway==0){ sfx_8.play(); }else{ sfx_8a.play(); }
         break;

        case  9:
         sfx_9.play();    // 7 on the comeout pay the line

         break;
        case  10:
         if(hardway==0){ sfx_10.play(); }else{ sfx_10a.play(); }
         break;

        case  11:
            sfx_11.play();    // 7 on the comeout pay the line

         break;
        case  12:
         if( RandomNum(2) >= 1) sfx_12.play();
           else sfx_12a.play();
         break; 
         case  13:
         if( RandomNum(1) == 0) sfx_13.play();
           else sfx_13a.play();
         break;


        case  14:
             sfx_7a.play();    // 7 on the comeout pay the line
         break;

        case  15:
             sfx_15.play();  // made the point
         break;

        case  17:
             sfx_15a.play();  // the point is
         break;

    }    

}//fn

function PayTable(tstr){
    console.log("] PAY TABLE on Event: {" +tstr+"}");

}

function PointIsOff(){

                thepointIs="OFF";

                 var projectile1 = new CrapsButton(100 + 50,100 + 50,40,'black',1 );
                 projectile1.draw();

}

// ***************************
// ***************************
// ********         **********
// ********   main  **********
// ********   game  **********
// ********         **********
// ***************************
// ***************************
function DiceLand(){
    var bOff4 =4; 
    var hardway1= 0;

    gDiceThrown++;

     gdice1= 1+ RandomNum(6);
     gdice2= 1+ RandomNum(6);
     DiceTotal   = gdice1+gdice2;

     if(gdice1==gdice2 && gdice1!=1 && gdice1!=6) hardway1= DiceTotal;


     drawDice(670,100,0.435, gdice1   );
     drawDice(798,100,0.435, gdice2   );
    // drawDice(100,100,0.5, gdice2);

     PlayRandomSFX('diceland');


     if (thepointIs=="OFF") {
        // coming out ! sfx

             PlayNewTurnSFX(6,7 );  // 13== comin out/ new shooter

             if(DiceTotal==7){
                PlayNewTurnSFX(7,7 );    // pay comeout line
                PayTable("sevencomeout");

             }else if(DiceTotal==11){
                PlayNewTurnSFX(6,5 );    // pay comeout line
                PayTable("elevencomeout");

             }else if(DiceTotal==12){
                PlayNewTurnSFX(6,6 );    // pay comeout line

             }else if( DiceTotal!=2  &&  DiceTotal!=3 ){
                thepointIs= DiceTotal.toString();
               // PlayNewTurnSFX(9,8);    // 17== the pointIS
        
                 PlayNewTurnSFX(gdice1,gdice2);

                 var projectile1 = new CrapsButton(100 + 50,100 + 50,40,'white',1 )
                 projectile1.draw()

             }

//***************************** POINT ON
     // point IS ON       
     }else{


         if(DiceTotal==7){
             PointIsOff();
               
             PayTable("sevenout_neg");
             PlayNewTurnSFX(gdice1,gdice2);
             thisStreak=0;
             gSevenOuts++;
            }else thisStreak++;

        if( DiceTotal.toString()==thepointIs ){
            // 
            PayTable("point");
            //thepointIs="OFF";
            PointIsOff();

            PlayNewTurnSFX(7,8);    // made the point

                if(thisStreak > longestStreak) longestStreak= thisStreak;
                gPointsMade++;
                thisStreak=0;

            }else {
                PlayNewTurnSFX(gdice1,gdice2);
            }
            

        }

// 
//     gdice1  gdice2 
    var i=3;
    var jbBut = new jButtonRound(     bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                       gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  'blue',  'white',
                                      gdice1.toString()+" "+ gdice2.toString(),     
                                    1.0, 1.0 , "24"
            );

    jbBut.draw();


    var i=4;
    var jbBut = new jButtonRound(     bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                       gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  'purple',  'white',
                                     ( "Point is "+ thepointIs+" ["+(100*gPointPcts[DiceTotal]).toFixed(1)+"%]"),     
                                    1.0, 1.0, "24"
            );

    jbBut.draw();

// dices


}//fn



addEventListener('click', (event) => {
	console.log(event)
	var xx = event.clientX
	var yy = event.clientY

    // global
  n++; 

  

    var bclicked = GetButtonNumClicked(xx,yy);
//gButtonNumClicked
//var jrnd= RandomNum( 3 );
    if(bclicked==-1 && yy > gCrapsTableY){
        jcnt0++;
        jrnd= jcnt0 %5;
        switch(jrnd){
           case 0: mySound_chips1.play();  break;
           case 1: mySound_chips2.play();  break;
           case 2: mySound_chips3.play();  break;
           case 3: mySound_chips4.play();  break;
           case 4: mySound_chips5.play();  break;
        }

//PLACE CHIPS HERE
        const projectile = new Projectile(xx,yy,13,'yellow',1 )
        projectile.draw()
           
    }else{
        switch(bclicked){
           // case 0: mySound_dice0.play();  break;
           // case 1: mySound_diceland1.play();  break;
           // case 0: PlayRandomSFX('diceshake'); break;   // shake dice
           case 0: DiceShake(); break;
           case 1:  DiceLand();  break;   // throw dice
           case 2: if(countdown<(countdownStart-25)) countdown+=25;  break;
           case 3: case 4:  break;
            }
        }
    

 	  //  var projectile1 = new Projectile(xx + 50,yy + 50,12,'white',1 )
	   // projectile1.draw()

  }

)// addEventListener





class jButtonRound {
    constructor(x,y,radius, w,h, colorOn , colorOff,colorText, jText , jAlpha, rndCorner, pxStr){
        this.x =x
        this.y =y 
        this.radius =radius
        this.w =w
        this.h =h 
        this.colorOn =colorOn 
        this.colorOff=colorOff
        this.colorText=colorText
        this.jText   =jText

        this.jAlpha   =jAlpha
        this.rndCorner   =rndCorner
        this.pxStr = pxStr
    }

    draw(){ 

    var rect = [20, 20, 300, 300],
    cr = 25;            // corner radius

    cr     = this.radius;
    rect[0]= this.x;
    rect[1]= this.y;
    rect[2]= this.w;
    rect[3]= this.h;

// if(this.rndCorner){}
//
//

    var pi = Math.PI,       // cache it here to make code more readable
    x1 = rect[0],       // cache points
    y1 = rect[1],
    x2 = rect[2] + x1,
    y2 = rect[3] + y1;

// create a rounded rectangle path
    c.beginPath();

    c.arc(x1 + cr, y1 + cr, cr, pi, 1.5 * pi);  // upper left corner
    c.arc(x2 - cr, y1 + cr, cr, 1.5 * pi, 0);   // upper right corner
    c.arc(x2 - cr, y2 - cr, cr, 0, 0.5 * pi);   // lower right corner
    c.arc(x1 + cr, y2 - cr, cr, 0.5 * pi, pi);  // lower left corner

    c.closePath();
    c.globalAlpha =this.jAlpha; // 0.50; 

    c.fillStyle=this.colorOff;
    c.fill()

    c.stroke();
    c.globalAlpha = 1.0; 


        c.beginPath()
        c.arc(this.x-25, this.y-25, this.radius/4, 0, Math.PI*2, false) 
        c.fillStyle=this.colorOn ; //Off
        c.fill()

         // c.Rect(  (this.x-this.radius), (this.-(0.5625*this.radius)), 192    , 108);
        // c.strokeRect(  (this.x-this.radius), (this.-(0.5625*this.radius)), 192   , 108);

        // c.fillStyle =this.colorOff ; // colorOn; //"#fa00a0";
        // c.strokeRect(this.x+2, this.y-28   ,    192/2       , 108/2); //this.x-25, this.y-25   ,    500 ,500 );
      
        // c.fillStyle = "#8899aa"; 
        // c.globalAlpha = 0.50; 
        // c.fillRect(this.x+2, this.y-28   ,    192/2     , 108/2 );
        // c.globalAlpha = 1.0; 

        //c.fillRect(this.x+2, this.y-28   ,    192/.8      , 108/2 );
    
// ctx.strokeRect(20, 20, 150, 100);
 
     //     c.fillStyle='orange'
        // c.font = "42px Arial";
        // c.fillText( "jButton active."+"..",  7,  14 );
   

        c.fillStyle=this.colorText ; //'yellow'
        c.font = this.pxStr +"px Arial";   //"24px
        if(this.pxStr=="")  c.font ="24px Arial";
        // c.fillText( (this.x).toString() , this.x, this.y );
        c.fillText( this.jText, this.x+this.radius*0.8, this.y+(0.65* this.h ) );
   

 



    }

}


 


function GetButtonNumClicked(xu,yu){
var i, bOff4=4;

gButtonNumClicked=-1;   // indicate not clicked within button # 0..n

 
//  var bRects = [   10,10, 180,60,

     for(i=0;i<numButtons;i++){
      
        if(  ( xu >=    bRects[ (i*bOff4) + 0 ] )                              &&
             ( xu <=    bRects[ (i*bOff4) + 0 ] + bRects[ (i*bOff4) + 2 ]   )  &&

             ( yu >=    bRects[ (i*bOff4) + 1 ] )                              &&
             ( yu <=    bRects[ (i*bOff4) + 1 ] + bRects[ (i*bOff4) + 3 ]   )) {

            gButtonNumClicked=i;

            if(bClickStatus[i]==0){
                bClickStatus[i]=1;
                var jbBut = new jButtonRound(        bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                       gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  gButColOn,  'white',
                                      bTexts[ i ],           // "but#"+gButtonNumClicked.toString() 
                                    1.0, 1.0, "24"
            );

        }else{
            bClickStatus[i]=0;
                var jbBut = new jButtonRound(        bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                      gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green', gButColOff,  'white',
                                      bTexts[ i ]+bOffStr ,
                                      1.0, 1.0, "24"
          

            );

        }
 
        jbBut.draw()
         
        return(i);
        }//if


    }//for

    return(gButtonNumClicked);

}//fn



function drawTopButtons(){
var i=2,bOff4=4;  
    
var x0= 12, y0=24, w0=170, h0=50;

 

     for(i=0;i<numButtons;i++){
        var jbBut = new jButtonRound( bRects[  (i*bOff4) + 0 ] ,
                                      bRects[  (i*bOff4) + 1 ] ,
                                      gRound,
                                      bRects[  (i*bOff4) + 2 ] ,
                                      bRects[  (i*bOff4) + 3 ] ,
                                      'green',  gButColOff,  'white',
                                      bTexts[ i ]+bOffStr,
                                       1.0, 1.0, "24"

            );
 
        jbBut.draw()
 
        }//for


 
 

}// fn

function MainGame(){
    drawTopButtons();
    startSound();
    gameLoop(1000);
}



//*****************************
//*****************************
//*****************************
//
//
         MainGame();
//
//
//*****************************
//*****************************


    // Run myfunc every second
var myfunc = setInterval(function() {

    var now = new Date().getTime();
    var timeleft = countDownDate - now;
    countdown-=4;

    if (countdown>25) gameLoop(countdown);
        else {
            DiceLand();
            countdown=countdownStart;
                }
//}, (1000 * 0.005125) );   // 0.25 1000= 1 sec
}, (1000 * 0.35) );   // 0.25 1000= 1 sec



function gameLoop(barlen) {
 
 if(barlen<26){
    
  return;
 }  


   var p;
   var colstr; 
   var tstr = gdice1.toString()+ "  "+ gdice2.toString();
   var streakstr="This Streak/Longest: "+thisStreak.toString()+ "/"+longestStreak.toString()+ ", Points Made=["+gPointsMade+"], SevenOUTs=["+gSevenOuts+"], DiceThrown=["+gDiceThrown+"] " ;

  var barLong  = new jButtonRound(4,74,10, 1000,   24,  'green',  'cyan',  'white', " " , 1.0, 1.0, "24"  ); 
  var barShort = new jButtonRound(4,74,10, barlen ,24,  'green',  'yellow',  'black', streakstr , 1.0, 1.0 , "18" );
 
    barLong.draw();
    barShort.draw();
 
    if(gFirstTime==0){
         mySound_crowd.play();
         gFirstTime=1;
    }

}




function startSound() {

    mySound_chips1 = new sound("mp3/chips0.mp3");
    mySound_chips2 = new sound("mp3/chips1.mp3");
    mySound_chips3 = new sound("mp3/chips2.mp3");
    mySound_chips4 = new sound("mp3/chips3.mp3");
    mySound_chips5 = new sound("mp3/chips4.mp3");

    mySound_crowd = new sound("mp3/crowd.mp3");

    mySound_dice0 = new sound("mp3/dice.mp3");
    mySound_dice1 = new sound("mp3/dicelong0.mp3");
    mySound_dice2 = new sound("mp3/dicelong1.mp3");

    mySound_diceland0 = new sound("mp3/diceland0.mp3");
    mySound_diceland1 = new sound("mp3/diceland1.mp3");


     sfx_2  = new sound("mp3/numbers/sfx_2.mp3");
    // sfx_2a = new sound("mp3/sfx_2a.mp3");
    sfx_3  = new sound("mp3/numbers/sfx_3.mp3");
    // sfx_3a = new sound("mp3/sfx_3.mp3");

    sfx_4   = new sound("mp3/numbers/sfx_4.mp3");
    sfx_4a  = new sound("mp3/numbers/sfx_4hard.mp3");

     sfx_5  = new sound("mp3/numbers/sfx_5.mp3");
    // sfx_5a = new sound("mp3/sfx_5a.mp3");
     sfx_6  = new sound("mp3/numbers/sfx_6.mp3");
     sfx_6a = new sound("mp3/numbers/sfx_6hard.mp3");

   sfx_7     = new sound("mp3/numbers/sfx_7out.mp3");
   sfx_7a    = new sound("mp3/numbers/sfx_7payline.mp3");

      sfx_8  = new sound("mp3/numbers/sfx_8.mp3");
      sfx_8a = new sound("mp3/numbers/sfx_8hard.mp3");

    sfx_9  = new sound("mp3/numbers/sfx_9.mp3");
 
      sfx_10 = new sound("mp3/numbers/sfx_10.mp3");
      sfx_10a= new sound("mp3/numbers/sfx_10hard.mp3");

      sfx_11 = new sound("mp3/numbers/sfx_11.mp3");

     sfx_12a = new sound("mp3/numbers/sfx_12.mp3");
    sfx_12= new sound("mp3/numbers/sfx_12mid.mp3");

    sfx_13 = new sound("mp3/numbers/sfx_comingout.mp3");
    sfx_13a = new sound("mp3/numbers/sfx_newshooter.mp3");

    // sfx_14 = new sound("mp3/numbers/sfx_madepoint.mp3");
    // sfx_14a = new sound("mp3/numbers/sfx_thepointis.mp3");

    sfx_15 = new sound("mp3/numbers/sfx_madepoint.mp3");
    sfx_15a = new sound("mp3/numbers/sfx_thepointis.mp3");


}

function sound(src) {
    this.sound = document.createElement("audio");
    this.sound.src = src;
    this.sound.setAttribute("preload", "auto");
    this.sound.setAttribute("controls", "none");
    this.sound.style.display = "none";
    document.body.appendChild(this.sound);
    this.play = function(){
        this.sound.play();
    }
    this.stop = function(){
        this.sound.pause();
    }    
}




/*


var mySound;

function startGame() {
    mySound = new sound("bounce.mp3");
//    myGameArea.start();
}

function sound(src) {
    this.sound = document.createElement("audio");
    this.sound.src = src;
    this.sound.setAttribute("preload", "auto");
    this.sound.setAttribute("controls", "none");
    this.sound.style.display = "none";
    document.body.appendChild(this.sound);
    this.play = function(){
        this.sound.play();
    }
    this.stop = function(){
        this.sound.pause();
    }    
}








<audio id="myAudio" controls>
  <source src="horse.ogg" type="audio/ogg">
  <source src="horse.mp3" type="audio/mpeg">
  Your browser does not support the audio element.
</audio><br>

<button onclick="enableLoop()" type="button">Enable loop</button>
<button onclick="disableLoop()" type="button">Disable loop</button>
<button onclick="checkLoop()" type="button">Check loop status</button>

<script>
var x = document.getElementById("myAudio");

function enableLoop() { 
  x.loop = true;
  x.load();
} 

function disableLoop() { 
  x.loop = false;
  x.load();
} 

function checkLoop() { 
  alert(x.loop);
} 
</script> 




/// old button

class jButton {
    constructor(xCenter,yCenter,radius, w,h, colorOn , colorOff, jText ){//, jAlpha, rndCorner){
        this.x =xCenter
        this.y =yCenter 
        this.radius =radius
        this.w =w
        this.h =h 
        this.colorOn =colorOn 
        this.colorOff=colorOff
        this.jText   =jText
    }

    draw(){

        c.beginPath()
        c.arc(this.x-25, this.y-25, this.radius/4, 0, Math.PI*2, false) 
        c.fillStyle=this.colorOff
        c.fill()

         // c.Rect(  (this.x-this.radius), (this.-(0.5625*this.radius)), 192    , 108);
        // c.strokeRect(  (this.x-this.radius), (this.-(0.5625*this.radius)), 192   , 108);

        c.fillStyle =this.colorOff ; // colorOn; //"#fa00a0";
        c.strokeRect(this.x+2, this.y-28   ,    192/2       , 108/2); //this.x-25, this.y-25   ,    500 ,500 );
      
        c.fillStyle = "#8899aa"; 
        c.globalAlpha = 0.50; 
        c.fillRect(this.x+2, this.y-28   ,    192/2     , 108/2 );
        c.globalAlpha = 1.0; 

        //c.fillRect(this.x+2, this.y-28   ,    192/.8      , 108/2 );
    
// ctx.strokeRect(20, 20, 150, 100);
 
     //     c.fillStyle='orange'
        // c.font = "42px Arial";
        // c.fillText( "jButton active."+"..",  7,  14 );
   

        c.fillStyle=this.colorOn ; //'yellow'
        c.font = "16px Arial";
        // c.fillText( (this.x).toString() , this.x, this.y );
        c.fillText( this.jText  , this.x+this.radius, this.y-0 );
   

 



    }

}


<p id="demo"></p>

<script>
// Set the date we're counting down to
var countDownDate = new Date("Jan 5, 2021 15:37:25").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>



var countDownDate = new Date("Jul 25, 2021 16:37:52").getTime();

    // Run myfunc every second
    var myfunc = setInterval(function() {

    var now = new Date().getTime();
    var timeleft = countDownDate - now;
        
}, 1000);


*/
 

