snhb.modules.machineLearning.mlSettings = {
	ts: 20200608204543,
	sidebar_sticky: {
		mean: 0.007066,
		dev: 0.020000
	},
	main_leaderboard: {
		mean: 0.050000,
		dev: 0.055000
	},
	wide_skyscraper: {
		mean: 0.050000,
		dev: 0.055000
	},
	mid_content: {
		mean: 0.050000,
		dev: 0.055000
	},
	bottom_medium_rectangle: {
		mean: 0.009959,
		dev: 0.015000
	},
	right_bottom_medium_rectangle: {
		mean: 0.050000,
		dev: 0.055000
	},
	try_it_leaderboard: {
		mean: 0.036367,
		dev: 0.035000
	},
	try_it_bottom_leaderboard: {
		mean: 0.050000,
		dev: 0.055000
	},
};