BAP.copyJSON({
  "data": {
    "icon_position": "top-right",
    "default_icon": "_us",
    "mobile_in_app_url": "",
    "default_footer": "Privacy Controls by Evidon, Inc.",
    "icon_display": "normal",
    "icon_grayscale": 30,
    "container_opacity": 70,
    "offset_x": 0,
    "offset_y": 0,
    "generic_icon": false,
    "icon_delay": 0,
    "nid": 18029,
    "nwid": null,
    "aid": 334,
    "icid": null,
    "skip_L2": false,
    "behavioral": "custom",
    "generic_text": "This ad was delivered on behalf of Unilever.  Information may be collected about your online browsing behavior to present ads which may be of interest to you. Unilever is committed to providing you with transparency and choice.",
    "adv_name": "Unilever",
    "adv_msg": "Unilever Privacy Policy",
    "adv_logo": "http://c.betrad.com/a/l/n/334/15680/us/784d0d73-9671-4b1e-b8b6-83f6f9c4d3e6.png",
    "adv_link": "http://www.unileverprivacypolicy.com/en_us/policy.aspx",
    "mobile_message": "Tap to edit advertising preferences",
    "display_mobile_overlay": false,
    "mobile_advertiser_logo_url": "",
    "default_icon_text": "AdChoices",
    "default_generic1": "This ad has been matched to your interests. It was selected for you based on your browsing activity.",
    "default_generic2": "This ad may have been matched to your interests based on your browsing activity.",
    "default_generic3": "helped",
    "default_generic4": "determine that you might be interested in an ad like this.",
    "default_generic5": "select this ad for you.",
    "default_generic6": "selected this ad for you.",
    "default_link1": "More information & opt-out options",
    "default_link2": "What is interest based advertising",
    "default_link3": "Learn about your choices",
    "ecid": null,
    "hide_wi": false,
    "hide_cl": false,
    "server": [
      {
        "name": "Turn Inc."
      }
    ],
    "message_properties": {}
  }
});