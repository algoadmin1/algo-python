<?php

/** 
                    by John Botti 08.20.2020,   10/14/13, 02.07.15
       aiDTregister.php - adapted from: userNewsignup.php    Version __________    - w/ NEW geobytes.com ___                   ver 5.4
//                                                                                 - with returning unique user ID #
* .php - Unity to SQL Database Connection
**/

//date_default_timezone_set("America/New_York");
//$nyTime == date("h:i:sa"). " on ".  date("Y-m-d") ;

//date_default_timezone_set("America/LosAngeles");

//Setting up Error Reporting Level
ini_set('display_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set("America/New_York");
$nyTime = date("h:i:sa"). " on ".  date("Y-m-d") ;
date_default_timezone_set("America/Los_Angeles");
ob_implicit_flush(1);

set_time_limit(0);

 if(isset( $_GET['sym'] )){
        $sym = $_GET['sym'] ;
    }else{
        $sym = "QQQ";
    }
   $sym = strtoupper($sym);

   // echo "] sym = ". $sym ;


$verNo="4.1";
$last_id ="";
$MIN_CANDLE_COUNT = 5;

// ########################################################################################
// 1 == go do Mysql SELECT to see if it exists IFnot THEN INSERT
// 0 == no insert
                     //   $MASTER_INSERT_FLAG = 0;
                        $MASTER_INSERT_FLAG = 1;
//
//
// ########################################################################################

  
    echo "] Reached Server... vers. $verNo <br />] The Time in New York is $nyTime, this system is running on PST. <br />";

    echo "<br />] ticker == $sym ...";
    echo "<br />] Connecting...";




// JMB's
$stocksListWATCHLIST = array('CCL','LVS','YUM','FCX' );    
$stocksListZX  = array( 'mcd', 'alb', 'CCL','LVS','YUM','FCX' , 'TSLA' );    
$stocksListDOW30 = array('CCL','LVS','YUM','FCX' );    
$stocksListNDX100 = array('CCL','LVS','YUM','FCX' );   
$stocksListSPY100 = array('GLD','VXX','JWN','AMZN', 'HAL', 'TSLA', 'FCX'  );
$stocksListTEST = array('GLD','VXX','JWN','AMZN', 'HAL', 'TSLA', 'FCX', 'ZNGA'  );

// NAME the array $stocksList to execute those tickers
$stocksList009 =array('VXY','NDX','AAPL','AMZN','FB','TSLA','ROKU','NVDA','SHOP','GOOGL','NFLX','M', 'GLD','GBTC','SLV','JWN','SNAP','ZM','AMD','INTC','V','BA','SPCE','SBUX','LULU','AAL','DAL','JBLU','MSFT', 'JOHNBOTTI','KODK','ETSY','LYFT','NFLX', 'QQQ' ,'TTWO' );

$stocksList007 = array('SPY','QQQ','DIA','VXX','VXY','NDX','AAPL','AMZN','FB','TSLA','ROKU','NVDA','SHOP','GOOGL','NFLX','M','JWN','GS','NVAX','SRNE', 'IMMU', 'MRNS','GLD','GBTC','SLV','JWN','SNAP','ZM','AMD','INTC','V','BA','SPCE','SBUX','LULU','AAL','DAL','JBLU','MSFT','KODK','ETSY','LYFT','UBER','SQ','WYNN','TLT','ALB','BABA','C','TCEHY','BIIB','UPS','ILMN','PINS','MGM','LVS','OSTK','TBT','TLT','BIDU','F','X','L','KO','MCD','WMT','DIS','NKE','GOOGL','BAC','AXP','JPM','CANN', 'CCL','LVS','YUM','FCX');
//JMB's




$stocksList_watShort = array(
   // $stocksList = array(
'SPY','DIA','QQQ','VXX','GLD','SLV','USO','TBT','TLT','GBTC','AAPL','AMZN','BYND','F', 'SPOT','ADT','NVDA','AMD','NKE','MRNS','IMMU',
'UBER','LYFT','L','K','KO','MCD','YUM','GS','BAC','C','WFC','JPM','AXP','V','T','HAL','PBR','XOM','U','SNAP',
'DUMMYSTOCK' );

$stocksList_wat = array(
 //$stocksList = array(
'SPY','DIA','QQQ','VXX','GLD','SLV','USO','TBT','TLT','GBTC','AAPL','AMZN','BYND','F','X','ROKU','FB','BA','M','MSFT',
'TSLA','PTON','SHOP','NVAX','NFLX','SRNE','AAL','NKLA','SBUX','LULU','RCL','SPCE','MRNA','SPOT','ADT','NVDA','AMD','NKE','MRNS','IMMU',
'UBER','LYFT','L','K','KO','MCD','YUM','GS','BAC','C','WFC','JPM','AXP','V','T','HAL','PBR','XOM','U','SNAP',

'DUMMYSTOCK' );


// running at 2020-09-28 4:24am PDT
$stocksList_dow = array(
'MMM','AXP','AAPL','BA','CAT','CVX','CSCO','KO','DOW','XOM','GS','HD','INTC','IBM','JNJ','JPM','MCD','MRK','MSFT','NKE',
'PFE','PG','TRV','UTX','UNH','VZ','V','WBA','WMT','DIS',
'DUMMYSTOCK' );



$stocksList_snp = array(
'MMM','AOS','ABT','ABBV','ABMD','ACN','ATVI','ADBE','AAP','AMD','AES','AFL','A','APD','AKAM','ALK','ALB','ARE','ALXN','ALGN',
'ALLE','LNT','ALL','GOOGL','GOOG','MO','AMZN','AMCR','AEE','AAL','AEP','AXP','AIG','AMT','AWK','AMP','ABC','AME','AMGN','APH',
'ADI','ANSS','ANTM','AON','APA','AIV','AAPL','AMAT','APTV','ADM','ANET','AJG','AIZ','T','ATO','ADSK','ADP','AZO','AVB','AVY',
'BKR','BLL','BAC','BAX','BDX','BRK.B','BBY','BIO','BIIB','BLK','BA','BKNG','BWA','BXP','BSX','BMY','AVGO','BR','BF.B','CHRW',
'COG','CDNS','CPB','COF','CAH','KMX','CCL','CARR','CAT','CBOE','CBRE','CDW','CE','CNC','CNP','CTL','CERN','CF','SCHW','CHTR',
'CVX','CMG','CB','CHD','CI','CINF','CTAS','CSCO','C','CFG','CTXS','CME','CMS','KO','CTSH','CL','CMCSA','CMA','CAG','CXO',
'COP','ED','STZ','CPRT','GLW','CTVA','COST','COTY','CCI','CSX','CMI','CVS','DHI','DHR','DRI','DVA','DE','DAL','XRAY','DVN',
'DXCM','FANG','DLR','DFS','DISCA','DISCK','DISH','DG','DLTR','D','DPZ','DOV','DOW','DTE','DUK','DRE','DD','DXC','ETFC','EMN',
'ETN','EBAY','ECL','EIX','EW','EA','EMR','ETR','EOG','EFX','EQIX','EQR','ESS','EL','RE','EVRG','ES','EXC','EXPE','EXPD',
'EXR','XOM','FFIV','FB','FAST','FRT','FDX','FIS','FITB','FRC','FE','FISV','FLT','FLIR','FLS','FMC','F','FTNT','FTV','FBHS',
'FOXA','FOX','BEN','FCX','GPS','GRMN','IT','GD','GE','GIS','GM','GPC','GILD','GPN','GL','GS','GWW','HRB','HAL','HBI',
'HIG','HAS','HCA','PEAK','HSIC','HES','HPE','HLT','HFC','HOLX','HD','HON','HRL','HST','HWM','HPQ','HUM','HBAN','HII','IEX',
'IDXX','INFO','ITW','ILMN','INCY','IR','INTC','ICE','IBM','IFF','IP','IPG','INTU','ISRG','IVZ','IPGP','IQV','IRM','JBHT','JKHY',
'J','SJM','JNJ','JCI','JPM','JNPR','KSU','K','KEY','KEYS','KMB','KIM','KMI','KLAC','KSS','KHC','KR','LB','LHX','LH',
'LRCX','LW','LVS','LEG','LDOS','LEN','LLY','LNC','LIN','LYV','LKQ','LMT','L','LOW','LYB','MTB','MRO','MPC','MKTX','MAR',
'MMC','MLM','MAS','MA','MXIM','MKC','MCD','MCK','MDT','MRK','MET','MTD','MGM','MCHP','MU','MSFT','MAA','MHK','TAP','MDLZ',
'MNST','MCO','MS','MSI','MSCI','MYL','NDAQ','NOV','NTAP','NFLX','NWL','NEM','NWSA','NWS','NEE','NLSN','NKE','NI','NBL','NSC',
'NTRS','NOC','NLOK','NCLH','NRG','NUE','NVDA','NVR','ORLY','OXY','ODFL','OMC','OKE','ORCL','OTIS','PCAR','PKG','PH','PAYX','PAYC',
'PYPL','PNR','PBCT','PEP','PKI','PRGO','PFE','PM','PSX','PNW','PXD','PNC','PPG','PPL','PFG','PG','PGR','PLD','PRU','PEG',
'PSA','PHM','PVH','QRVO','QCOM','PWR','DGX','RL','RJF','RTX','O','REG','REGN','RF','RSG','RMD','RHI','ROK','ROL','ROP',
'ROST','RCL','SPGI','CRM','SBAC','SLB','STX','SEE','SRE','NOW','SHW','SPG','SWKS','SLG','SNA','SO','LUV','SWK','SBUX','STT',
'STE','SYK','SIVB','SYF','SNPS','SYY','TMUS','TROW','TTWO','TPR','TGT','TEL','FTI','TDY','TFX','TXN','TXT','BK','CLX','COO',
'HSY','MOS','TRV','DIS','TMO','TIF','TJX','TSCO','TT','TDG','TFC','TWTR','TYL','TSN','USB','UDR','ULTA','UAA','UA','UNP',
'UAL','UNH','UPS','URI','UHS','UNM','VLO','VAR','VTR','VRSN','VRSK','VZ','VRTX','VFC','VIAC','V','VNO','VMC','WRB','WAB',
'WBA','WMT','WM','WAT','WEC','WFC','WELL','WST','WDC','WU','WRK','WY','WHR','WMB','WLTW','WYNN','XEL','XRX','XLNX','XYL',
'YUM','ZBRA','ZBH','ZION','ZTS',
'DUMMYSTOCK' );

$stocksList = array(
//$stocksList_nas = array(
  /*
'AAIT','AAL','AAME','AAOI','AAON','AAPL','AAVL','AAWW','AAXJ','ABAC','ABAX','ABCB','ABCD','ABCO','ABCW','ABDC','ABGB','ABIO','ABMD','ABTL',
'ABY','ACAD','ACAS','ACAT','ACET','ACFC','ACFN','ACGL','ACHC','ACHN','ACIW','ACLS','ACNB','ACOR','ACPW','ACRX','ACSF','ACST','ACTA','ACTG',
'ACTS','ACUR','ACWI','ACWX','ACXM','ADAT','ADBE','ADEP','ADES','ADHD','ADI','ADMA','ADMP','ADMS','ADNC','ADP','ADRA','ADRD','ADRE','ADRU',
'ADSK','ADTN','ADUS','ADVS','ADXS','ADXSW','AEGN','AEGR','AEHR','AEIS','AEPI','AERI','AETI','AEY','AEZS','AFAM','AFCB','AFFX','AFH','AFMD',
'AFOP','AFSI','AGEN','AGII','AGIIL','AGIO','AGNC','AGNCB','AGNCP','AGND','AGRX','AGTC','AGYS','AGZD','AHGP','AHPI','AIMC','AINV','AIQ','AIRM',
'AIRR','AIRT','AIXG','AKAM','AKAO','AKBA','AKER','AKRX','ALCO','ALDR','ALDX','ALGN','ALGT','ALIM','ALKS','ALLB','ALLT','ALNY','ALOG','ALOT',
'ALQA','ALSK','ALTR','ALXA','ALXN','AMAG','AMAT','AMBA','AMBC','AMBCW','AMCC','AMCF','AMCN','AMCX','AMD','AMDA','AMED','AMGN','AMIC','AMKR',
'AMNB','AMOT','AMOV','AMPH','AMRB','AMRI','AMRK','AMRN','AMRS','AMSC','AMSF','AMSG','AMSGP','AMSWA','AMTX','AMWD','AMZN','ANAC','ANAD','ANAT',
'ANCB','ANCI','ANCX','ANDE','ANGI','ANGO','ANIK','ANIP','ANSS','ANTH','ANY','AOSL','APAGF','APDN','APDNW','APEI','APOG','APOL','APPY','APRI',
'APSA','APTO','APWC','AQXP','ARAY','ARCB','ARCC','ARCI','ARCP','ARCPP','ARCW','ARDM','ARDX','AREX','ARGS','ARIA','ARII','ARIS','ARKR','ARLP',
'ARMH','ARNA','AROW','ARQL','ARRS','ARRY','ARTNA','ARTW','ARTX','ARUN','ARWR','ASBB','ASBI','ASCMA','ASEI','ASFI','ASMB','ASMI','ASML','ASNA',
'ASPS','ASPX','ASRV','ASRVP','ASTC','ASTE','ASTI','ASUR','ASYS','ATAI','ATAX','ATEA','ATEC','ATHN','ATHX','ATLC','ATLO','ATML','ATNI','ATNY',
'ATOS','ATRA','ATRC','ATRI','ATRM','ATRO','ATRS','ATSG','ATTU','ATVI','AUBN','AUDC','AUMA','AUMAU','AUMAW','AUPH','AUXL','AVAV','AVEO','AVGO',
'AVHI','AVID','AVNR','AVNW','AWAY','AWRE','AXAS','AXDX','AXGN','AXJS','AXPW','AXPWW','AXTI','AZPN','BABY','BAGR','BAMM','BANF','BANFP','BANR',
'BANX','BASI','BBBY','BBC','BBCN','BBEP','BBEPP','BBGI','BBLU','BBNK','BBOX','BBP','BBRG','BBRY','BBSI','BCBP','BCLI','BCOM','BCOR','BCOV',
'BCPC','BCRX','BDBD','BDCV','BDE','BDGE','BDMS','BDSI','BEAT','BEAV','BEBE','BECN','BELFA','BELFB','BFIN','BGCP','BGFV','BGMD','BHBK','BIB',
'BICK','BIDU','BIIB','BIND','BIOC','BIOD','BIOL','BIOS','BIRT','BIS','BJRI','BKCC','BKEP','BKEPP','BKMU','BKSC','BKYF','BLCM','BLDP','BLDR',
'BLFS','BLIN','BLKB','BLMN','BLMT','BLRX','BLUE','BLVD','BLVDU','BLVDW','BMRC','BMRN','BMTC','BNCL','BNCN','BNDX','BNFT','BNSO','BOBE','BOCH',
'BOFI','BOKF','BONA','BONT','BOOM','BOSC','BOTA','BOTJ','BPFH','BPFHP','BPFHW','BPOP','BPOPM','BPOPN','BPTH','BRCD','BRCM','BRDR','BREW','BRID',
'BRKL','BRKR','BRKS','BRLI','BSDM','BSET','BSF','BSFT','BSPM','BSQR','BSRR','BSTC','BTUI','BUR','BUSE','BV','BVA','BVSN','BWEN','BWFG',
'BWINA','BWINB','BWLD','BYBK','BYFC','BYLK','CA','CAAS','CAC','CACB','CACC','CACG','CACGU','CACGW','CACH','CACQ','CADC','CADT','CADTR','CADTU',
'CADTW','CAKE','CALA','CALD','CALI','CALL','CALM','CAMB','CAMBU','CAMBW','CAMP','CAMT','CAPN','CAPNW','CAR','CARA','CARB','CARO','CART','CARV',
'CARZ','CASH','CASI','CASM','CASS','CASY','CATM','CATY','CATYW','CAVM','CBAK','CBAN','CBAY','CBDE','CBF','CBFV','CBIN','CBLI','CBMG','CBMX',
'CBNJ','CBNK','CBOE','CBPO','CBRL','CBRX','CBSH','CBSHP','CBST','CBSTZ','CCBG','CCCL','CCCR','CCIH','CCLP','CCMP','CCNE','CCOI','CCRN','CCUR',
'CCXI','CDC','CDK','CDNA','CDNS','CDTI','CDW','CDXS','CDZI','CECE','CECO','CELG','CELGZ','CEMI','CEMP','CENT','CENTA','CENX','CERE','CERN',
'CERS','CERU','CETV','CEVA','CFA','CFBK','CFFI','CFFN','CFGE','CFNB','CFNL','CFO','CFRX','CFRXW','CFRXZ','CG','CGEN','CGIX','CGNX','CGO',
'CHCI','CHCO','CHDN','CHEF','CHEV','CHFC','CHFN','CHI','CHKE','CHKP','CHLN','CHMG','CHNR','CHOP','CHRS','CHRW','CHSCM','CHSCN','CHSCO','CHSCP',
'CHTR','CHUY','CHW','CHXF','CHY','CHYR','CIDM','CIFC','CIMT','CINF','CISAW','CISG','CIZ','CIZN','CJJD','CKEC','CKSW','CLAC','CLACU','CLACW',
'CLBH','CLCT','CLDN','CLDX','CLFD','CLIR','CLMS','CLMT','CLNE','CLNT','CLRB','CLRBW','CLRO','CLRX','CLSN','CLTX','CLUB','CLVS','CLWT','CMCO',
'CMCSA','CMCSK','CMCT','CME','CMFN','CMGE','CMLS','CMPR','CMRX','CMSB','CMTL','CNAT','CNBKA','CNCE','CNDO','CNET','CNIT','CNLM','CNLMR','CNLMU',
'CNLMW','CNMD','CNOB','CNSI','CNSL','CNTF','CNTY','CNV','CNXR','CNYD','COB','COBK','COBZ','COCO','COHR','COHU','COKE','COLB','COLM','COMM',
'COMT','CONE','CONN','COOL','CORE','CORI','CORT','COSI','COST','COVS','COWN','COWNL','CPAH','CPGI','CPHC','CPHD','CPHR','CPIX','CPLA','CPLP',
'CPRT','CPRX','CPSI','CPSS','CPST','CPTA','CPXX','CRAI','CRAY','CRDC','CRDS','CRDT','CREE','CREG','CRESW','CRESY','CRIS','CRME','CRMT','CRNT',
'CROX','CRRC','CRRS','CRTN','CRTO','CRUS','CRVL','CRWN','CRWS','CRZO','CSBK','CSCD','CSCO','CSF','CSFL','CSGP','CSGS','CSII','CSIQ','CSOD',
'CSPI','CSQ','CSRE','CSTE','CSUN','CSWC','CTAS','CTBI','CTCM','CTCT','CTG','CTHR','CTIB','CTIC','CTRE','CTRL','CTRN','CTRP','CTRX','CTSH',
'CTSO','CTWS','CTXS','CU','CUBA','CUI','CUNB','CUTR','CVBF','CVCO','CVCY','CVGI','CVGW','CVLT','CVLY','CVTI','CVV','CWAY','CWBC','CWCO',
'CWST','CXDC','CY','CYAN','CYBE','CYBR','CYBX','CYCC','CYCCP','CYHHZ','CYNO','CYOU','CYRN','CYTK','CYTR','CYTX','CZFC','CZNC','CZR','CZWI',
'DAEG','DAIO','DAKT','DARA','DATE','DAVE','DAX','DBVT','DCIX','DCOM','DCTH','DENN','DEPO','DERM','DEST','DFRG','DFVL','DFVS','DGAS','DGICA',
'DGICB','DGII','DGLD','DGLY','DGRE','DGRS','DGRW','DHIL','DHRM','DIOD','DISCA','DISCB','DISCK','DISH','DJCO','DLBL','DLBS','DLHC','DLTR','DMLP',
'DMND','DMRC','DNBF','DNKN','DORM','DOVR','DOX','DPRX','DRAD','DRAM','DRIV','DRNA','DRRX','DRWI','DRWIW','DRYS','DSCI','DSCO','DSGX','DSKX',
'DSKY','DSLV','DSPG','DSWL','DTLK','DTSI','DTUL','DTUS','DTV','DTYL','DTYS','DVAX','DVCR','DWA','DWAT','DWCH','DWSN','DXCM','DXGE','DXJS',
'DXKW','DXLG','DXM','DXPE','DXPS','DXYN','DYAX','DYNT','DYSL','EA','EAC','EARS','EBAY','EBIO','EBIX','EBMT','EBSB','EBTC','ECHO','ECOL',
'ECPG','ECTE','ECYT','EDAP','EDGW','EDS','EDUC','EEFT','EEI','EEMA','EEME','EEML','EFII','EFOI','EFSC','EFUT','EGAN','EGBN','EGHT','EGLE',
'EGLT','EGOV','EGRW','EGRX','EGT','EHTH','EIGI','ELGX','ELNK','ELON','ELOS','ELRC','ELSE','ELTK','EMCB','EMCF','EMCG','EMCI','EMDI','EMEY',
'EMIF','EMITF','EMKR','EML','EMMS','EMMSP','ENDP','ENFC','ENG','ENOC','ENPH','ENSG','ENT','ENTA','ENTG','ENTR','ENVI','ENZN',


'ENZY','EOPN',
'EPAX','EPAY','EPIQ','EPRS','EPZM','EQIX','ERI','ERIC','ERIE','ERII','EROC','ERS','ERW','ESBF','ESBK','ESCA','ESCR','ESCRP','ESEA','ESGR',
'ESIO','ESLT','ESMC','ESPR','ESRX','ESSA','ESSX','ESXB','ESYS','ETFC','ETRM','EUFN','EVAL','EVAR','EVBS','EVEP','EVK','EVLV','EVOK','EVOL',
'EVRY','EWBC','EXA','EXAC','EXAS','EXEL','EXFO','EXLP','EXLS','EXPD','EXPE','EXPO','EXTR','EXXI','EYES','EZCH','EZPW','FALC','FANG','FARM',
'FARO','FAST','FATE','FB','FBIZ','FBMS','FBNC','FBNK','FBRC','FBSS','FCAP','FCBC','FCCO','FCCY','FCEL','FCFS','FCHI','FCLF','FCNCA','FCS',
'FCSC','FCTY','FCVA','FCZA','FCZAP','FDEF','FDIV','FDML','FDUS','FEIC','FEIM','FELE','FEMB','FES','FEUZ','FEYE','FFBC','FFBCW','FFHL','FFIC',
'FFIN','FFIV','FFKT','FFNM','FFNW','FFWM','FGEN','FHCO','FIBK','FINL','FISH','FISI','FISV','FITB','FITBI','FIVE','FIVN','FIZZ','FLAT','FLDM',
'FLEX','FLIC','FLIR','FLL','FLML','FLWS','FLXN','FLXS','FMB','FMBH','FMBI','FMER','FMI','FMNB','FNBC','FNFG','FNGN','FNHC','FNJN','FNLC',
'FNRG','FNSR','FOLD','FOMX','FONE','FONR','FORD','FORM','FORR','FORTY','FOSL','FOX','FOXA','FOXF','FPRX','FPXI','FRAN','FRBA','FRBK','FRED',
'FREE','FRGI','FRME','FRP','FRPH','FRPHV','FRPT','FRSH','FSAM','FSBK','FSBW','FSC','FSCFL','FSFG','FSFR','FSGI','FSLR','FSNN','FSRV','FSTR',
'FSYS','FTCS','FTD','FTEK','FTGC','FTHI','FTLB','FTNT','FTR','FTSL','FTSM','FUEL','FULL','FULLL','FULT','FUNC','FUND','FV','FWM','FWP',
'FWRD','FXCB','FXEN','FXENP','GABC','GAI','GAIA','GAIN','GAINO','GAINP','GALE','GALT','GALTU','GALTW','GAME','GARS','GASS','GBCI','GBDC','GBIM',
'GBLI','GBNK','GBSN','GCBC','GCVRZ','GDEF','GENC','GENE','GEOS','GERN','GEVA','GEVO','GFED','GFN','GFNCP','GFNSL','GGAC','GGACR','GGACU','GGACW',

'GGAL','GHDX','GIFI','GIGA','GIGM','GIII','GILD','GILT','GK','GKNT','GLAD','GLADO','GLBS','GLBZ','GLDC','GLDD','GLDI','GLMD','GLNG','GLPI',
'GLRE','GLRI','GLUU','GLYC','GMAN','GMCR','GMLP','GNBC','GNCA','GNCMA','GNMA','GNMK','GNTX','GNVC','GOGO','GOLD','GOMO','GOOD','GOODN','GOODO',
'GOODP','GOOG','GOOGL','GPIC','GPOR','GPRE','GPRO','GRBK','GRFS','GRID','GRIF','GRMN','GROW','GRPN','GRVY','GSBC','GSIG','GSIT','GSM','GSOL',
'GSVC','GT','GTIM','GTIV','GTLS','GTWN','GTXI','GUID','GULF','GULTU','GURE','GWGH','GWPH','GYRO','HA','HABT','HAFC','HAIN','HALL','HALO',
'HART','HAS','HAWK','HAWKB','HAYN','HBAN','HBANP','HBCP','HBHC','HBIO','HBK','HBMD','HBNC','HBNK','HBOS','HBP','HCAC','HCACU','HCACW','HCAP',
'HCBK','HCCI','HCKT','HCOM','HCSG','HCT','HDNG','HDP','HDRA','HDRAR','HDRAU','HDRAW','HDS','HDSN','HEAR','HEES','HELE','HEOP','HERO','HFBC',
'HFBL','HFFC','HFWA','HGSH','HIBB','HIFS','HIHO','HIIQ','HILL','HIMX','HKTV','HLIT','HLSS','HMHC','HMIN','HMNF','HMNY','HMPR','HMST','HMSY',
'HMTV','HNH','HNNA','HNRG','HNSN','HOFT','HOLI','HOLX','HOMB','HOTR','HOTRW','HOVNP','HPJ','HPTX','HQY','HRTX','HRZN','HSGX','HSIC','HSII',
'HSKA','HSNI','HSOL','HSON','HSTM','HTBI','HTBK','HTBX','HTCH','HTHT','HTLD','HTLF','HTWO','HTWR','HUBG','HURC','HURN','HWAY','HWBK','HWCC',
'HWKN','HYGS','HYLS','HYND','HYZD','HZNP','IACI','IART','IBB','IBCA','IBCP','IBKC','IBKR','IBOC','IBTX','ICAD','ICCC','ICEL','ICFI','ICLD',
'ICLDW','ICLN','ICLR','ICON','ICPT','ICUI','IDCC','IDRA','IDSA','IDSY','IDTI','IDXX','IEP','IESC','IEUS','IFAS','IFEU','IFGL','IFNA','IFON',
'IFV','IGLD','IGOV','IGTE','III','IIIN','IIJI','IILG','IIN','IIVI','IKAN','IKGH','IKNX','ILMN','IMDZ','IMGN','IMI','IMKTA','IMMR','IMMU',
'IMMY','IMNP','IMOS','IMRS','INAP','INBK','INCR','INCY','INDB','INDY','INFA','INFI','INFN','INGN','ININ','INNL','INO','INOD','INPH','INSM',
'INSY','INTC','INTG','INTL','INTLL','INTU','INTX','INVE','INVT','INWK','IOSP','IPAR','IPAS','IPCC','IPCI','IPCM','IPDN','IPGP','IPHS','IPKW',
'IPWR','IPXL','IQNT','IRBT','IRDM','IRDMB','IRDMZ','IRG','IRIX','IRMD','IROQ','IRWD','ISBC','ISCA','ISHG','ISIG','ISIL','ISIS','ISLE','ISM',
'ISNS','ISRG','ISRL','ISSC','ISSI','ISTR','ITCI','ITIC','ITRI','ITRN','IVAC','IVAN','IXYS','JACK','JACQ','JACQU','JACQW','JAKK','JASN','JASNW',
'JASO','JAXB','JAZZ','JBHT','JBLU','JBSS','JCOM','JCS','JCTCF','JD','JDSU','JGBB','JIVE','JJSF','JKHY','JMBA','JOBS','JOEZ','JOUT','JRJC',
'JRVR','JSM','JST','JTPY','JUNO','JVA','JXSB','JYNT','KALU','KANG','KBAL','KBIO','KBSF','KCAP','KCLI','KE','KELYA','KELYB','KEQU','KERX',
'KEYW','KFFB','KFRC','KFX','KGJI','KIN','KINS','KIRK','KITE','KLAC','KLIC','KLXI','KMDA','KNDI','KONA','KONE','KOOL','KOPN','KOSS','KPTI',
'KRFT','KRNY','KTCC','KTEC','KTOS','KTWO','KUTV','KVHI','KWEB','KYTH','KZ','LABC','LABL','LACO','LAKE','LALT','LAMR','LANC','LAND','LARK',
'LAWS','LAYN','LBAI','LBIX','LBRDA','LBRDK','LBRKR','LBTYA','LBTYB','LBTYK','LCNB','LCUT','LDRH','LDRI','LE','LECO','LEDS','LEVY','LEVYU','LEVYW',
'LFUS','LFVN','LGCY','LGCYO','LGCYP','LGIH','LGND','LHCG','LIME','LINC','LINE','LION','LIOX','LIQD','LIVE','LJPC','LKFN','LKQ','LLEX','LLNW',
'LLTC','LMAT','LMBS','LMCA','LMCB','LMCK','LMIA','LMNR','LMNS','LMNX','LMOS','LMRK','LNBB','LNCE','LNCO','LNDC','LOAN','LOCM','LOCO','LOGI',
'LOGM','LOJN','LONG','LOOK','LOPE','LORL','LOXO','LPCN','LPHI','LPLA','LPNT','LPSB','LPSN','LPTH','LPTN','LQDT','LRAD','LRCX','LSBK','LSCC',
'LSTR','LTBR','LTRE','LTRPA','LTRPB','LTRX','LTXB','LULU','LUNA','LVNTA','LVNTB','LWAY','LXRX','LYTS',


'MACK','MAG','MAGS','MAMS','MANH','MANT',
'MAR','MARA','MARK','MARPS','MASI','MAT','MATR','MATW','MAYS','MBCN','MBFI','MBFIP','MBII','MBLX','MBRG','MBSD','MBTF','MBUU','MBVT','MBWM',
'MCBC','MCBK','MCEP','MCGC','MCHP','MCHX','MCOX','MCRI','MCRL','MCUR','MDAS','MDCA','MDCO','MDIV','MDLZ','MDM','MDRX','MDSO','MDSY','MDVN',
'MDVXU','MDWD','MDXG','MEET','MEIL','MEILW','MEILZ','MEIP','MELA','MELI','MELR','MEMP','MENT','MEOH','MERC','MERU','METR','MFI','MFLX','MFNC',
'MFRI','MFRM','MFSF','MGCD','MGEE','MGI','MGIC','MGLN','MGNX','MGPI','MGRC','MGYR','MHGC','MHLD','MHLDO','MICT','MICTW','MIDD','MIFI','MIK',
'MIND','MINI','MITK','MITL','MKSI','MKTO','MKTX','MLAB','MLHR','MLNK','MLNX','MLVF','MMAC','MMLP','MMSI','MMYT','MNDL','MNDO','MNGA','MNKD',
'MNOV','MNRK','MNRO','MNST','MNTA','MNTX','MOBI','MOBL','MOCO','MOFG','MOKO','MOLG','MOMO','MORN','MOSY','MPAA','MPB','MPEL','MPET','MPWR',
'MRCC','MRCY','MRD','MRGE','MRKT','MRLN','MRNS','MRTN','MRTX','MRVC','MRVL','MSBF','MSCC','MSEX','MSFG','MSFT','MSG','MSLI','MSON','MSTR',
'MTBC','MTEX','MTGE','MTGEP','MTLS','MTRX','MTSC','MTSI','MTSL','MTSN','MU','MULT','MVIS','MWIV','MXIM','MXWL','MYGN','MYL','MYOS','MYRG',
'MZOR','NAII','NAME','NANO','NATH','NATI','NATL','NATR','NAUH','NAVG','NAVI','NBBC','NBIX','NBN','NBS','NBTB','NBTF','NCIT','NCLH','NCMI',
'NCTY','NDAQ','NDLS','NDRM','NDSN','NECB','NEO','NEOG','NEON','NEOT','NEPT','NERV','NETE','NEWP','NEWS','NEWT','NFBK','NFEC','NFLX','NGHC',
'NGHCP','NHTB','NICE','NICK','NILE','NKSH','NKTR','NLNK','NLST','NMIH','NMRX','NNBR','NPBC','NPSP','NRCIA','NRCIB','NRIM','NRX','NSEC','NSIT',
'NSPH','NSSC','NSTG','NSYS','NTAP','NTCT','NTES','NTGR','NTIC','NTK','NTLS','NTRI','NTRS','NTRSP','NTWK','NUAN','NURO','NUTR','NUVA','NVAX',
'NVCN','NVDA','NVDQ','NVEC','NVEE','NVEEW','NVFY','NVGN','NVMI','NVSL','NWBI','NWBO','NWBOW','NWFL','NWLI','NWPX','NWS','NWSA','NXPI','NXST',
'NXTD','NXTDW','NXTM','NYMT','NYMTP','NYMX','NYNY','OBAS','OBCI','OCC','OCFC','OCLR','OCLS','OCRX','OCUL','ODFL','ODP','OFED','OFIX','OFLX',
'OFS','OGXI','OHAI','OHGI','OHRP','OIIM','OKSB','OLBK','OLED','OMAB','OMCL','OMED','OMER','OMEX','ONB','ONCY','ONEQ','ONFC','ONNN','ONTX',
'ONTY','ONVI','OPB','OPHC','OPHT','OPOF','OPTT','OPXA','ORBC','ORBK','OREX','ORIG','ORIT','ORLY','ORMP','ORPN','ORRF','OSBC','OSBCP','OSHC',
'OSIR','OSIS','OSM','OSN','OSTK','OSUR','OTEL','OTEX','OTIC','OTIV','OTTR','OUTR','OVAS','OVBC','OVLY','OVTI','OXBR','OXBRW','OXFD','OXGN',
'OXLC','OXLCN','OXLCO','OXLCP','OZRK',
*/
'PAAS','PACB','PACW','PAGG','PAHC','PANL','PARN','PATIV','PATK','PAYX','PBCP','PBCT','PBHC','PBIB','PBIP',
'PBMD','PBPB','PBSK','PCAR','PCBK','PCCC','PCH','PCLN','PCMI','PCO','PCOM','PCRX','PCTI','PCTY','PCYC','PCYG','PCYO','PDBC','PDCE','PDCO',
'PDEX','PDFS','PDII','PDLI','PEBK','PEBO','PEGA','PEGI','PEIX','PENN','PENX','PEOP','PERF','PERI','PERY','PESI','PETM','PETS','PETX','PFBC',
'PFBI','PFBX','PFIE','PFIN','PFIS','PFLT','PFMT','PFPT','PFSW','PGC','PGNX','PGTI','PHII','PHIIK','PHMD','PICO','PIH','PINC','PKBK','PKOH',
'PKT','PLAB','PLAY','PLBC','PLCE','PLCM','PLKI','PLMT','PLNR','PLPC','PLPM','PLTM','PLUG','PLUS','PLXS','PMBC','PMCS','PMD','PME','PMFG',
'PNBK','PNFP','PNNT','PNQI','PNRA','PNRG','PNTR','PODD','POOL','POPE','POWI','POWL','POZN','PPBI','PPC','PPHM','PPHMP','PPSI','PRAA','PRAH',
'PRAN','PRCP','PRFT','PRFZ','PRGN','PRGNL','PRGS','PRGX','PRIM','PRKR','PRLS','PRMW','PROV','PRPH','PRQR','PRSC','PRSS','PRTA','PRTK','PRTO',
'PRTS','PRXI','PRXL','PSAU','PSBH','PSCC','PSCD','PSCE','PSCF','PSCH','PSCI','PSCM','PSCT','PSCU','PSDV','PSEC','PSEM','PSIX','PSMT','PSTB',
'PSTI','PSTR','PSUN','PTBI','PTBIW','PTC','PTCT','PTEN','PTIE','PTLA','PTNR','PTNT','PTRY','PTSI','PTX','PULB','PVTB','PVTBP','PWOD','PWRD',
'PWX','PXLW','PZZA','QABA','QADA','QADB','QAT','QBAK','QCCO','QCLN','QCOM','QCRH','QDEL','QGEN','QINC','QIWI','QKLS','QLGC','QLIK','QLTI',
'QLTY','QLYS','QNST','QQEW','QQQ','QQQC','QQQX','QQXT','QRHC','QRVO','QSII','QTEC','QTNT','QTNTW','QTWW','QUIK','QUMU','QUNR','QURE','QVCA',
'QVCB','QYLD','RADA','RAIL','RAND','RARE','RAVE','RAVN','RBCAA','RBCN','RBPAA','RCII','RCKY','RCMT','RCON','RCPI','RCPT','RDCM','RDEN','RDHL',
'RDI','RDIB','RDNT','RDUS','RDVY','RDWR','RECN','REDF','REFR','REGI','REGN','REIS','RELL','RELV','REMY','RENT','REPH','RESN','REXI','REXX',
'RFIL','RGCO','RGDO','RGDX','RGEN','RGLD','RGLS','RGSE','RIBT','RIBTW','RICK','RIGL','RITT','RITTW','RIVR','RJET','RLJE','RLOC','RLOG','RLYP',
'RMBS','RMCF','RMGN','RMTI','RNA','RNET','RNST','RNWK','ROBO','ROCK','ROIA','ROIAK','ROIC','ROIQ','ROIQU','ROIQW','ROKA','ROLL','ROSE','ROSG',
'ROST','ROVI','ROYL','RP','RPRX','RPRXW','RPRXZ','RPTP','RPXC','RRD','RRGB','RRST','RSTI','RSYS','RTGN','RTIX','RTK','RTRX','RUSHA','RUSHB',
'RUTH','RVBD','RVLT','RVNC','RVSB','RWLK','RXDX','RXII','RYAAY','SAAS','SABR','SAEX','SAFM','SAFT','SAGE','SAIA','SAJA','SAL','SALE','SALM',
'SAMG','SANM','SANW','SANWZ','SAPE','SASR','SATS','SAVE','SBAC','SBBX','SBCF','SBCP','SBFG','SBGI','SBLK','SBLKL','SBNY','SBNYW','SBRA','SBRAP',
'SBSA','SBSI','SBUX','SCAI','SCHL','SCHN','SCLN','SCMP','SCOK','SCON','SCOR','SCSC','SCSS','SCTY','SCVL','SCYX','SEAC','SEED','SEIC','SEMI',
'SENEA','SENEB','SEV','SFBC','SFBS','SFLY','SFM','SFNC','SFST','SFXE','SGBK','SGC','SGEN','SGI','SGMA','SGMO','SGMS','SGNL','SGNT','SGOC',
'SGRP','SGYP','SGYPU','SGYPW','SHBI','SHEN','SHIP','SHLD','SHLDW','SHLM','SHLO','SHOO','SHOR','SHOS','SHPG','SIAL','SIBC','SIEB','SIEN','SIFI',
'SIFY','SIGA','SIGI','SIGM','SILC','SIMG','SIMO','SINA','SINO','SIRI','SIRO','SIVB','SIVBO','SIXD','SKBI','SKIS','SKOR','SKUL','SKYS','SKYW',
'SKYY','SLAB','SLCT','SLGN','SLM','SLMAP','SLMBP','SLP','SLRC','SLTC','SLVO','SLXP','SMAC','SMACR','SMACU','SMBC','SMCI','SMED','SMIT','SMLR',
'SMMF','SMPL','SMRT','SMSI','SMT','SMTC','SMTP','SMTX','SNAK','SNBC','SNC','SNCR','SNDK','SNFCA','SNHY','SNMX','SNPS','SNSS','SNTA','SOCB',
'SOCL','SODA','SOFO','SOHO','SOHOL','SOHOM','SOHU','SONA','SONC','SONS','SORL','SOXX','SP','SPAN','SPAR','SPCB','SPDC','SPEX','SPHS','SPIL',
'SPKE','SPLK','SPLS','SPNC','SPNS','SPOK','SPPI','SPPR','SPPRO','SPPRP','SPRO','SPRT','SPSC','SPTN','SPU','SPWH','SPWR','SQBG','SQBK','SQI',
'SQNM','SQQQ','SRCE','SRCL','SRDX','SREV','SRNE','SRPT','SRSC','SSB','SSBI','SSFN','SSH','SSNC','SSRG','SSRI','SSYS','STAA','STB','STBA',
'STBZ','STCK','STEM','STFC','STKL','STLD','STLY','STML','STMP','STNR','STPP','STRA','STRL','STRM','STRN','STRS','STRT','STRZA','STRZB','STX',
'STXS','SUBK','SUMR','SUNS','SUPN','SURG','SUSQ','SUTR','SVA','SVBI','SVVC','SWHC','SWIR','SWKS','SWSH','SYBT','SYKE','SYMC','SYMX','SYNA',
'SYNC','SYNL','SYNT','SYPR','SYRX','SYUT','SZMK','SZYM',
/*
'TACT','TAIT','TAPR','TASR','TAST','TATT','TAX','TAXI','TAYD','TBBK','TBIO','TBK',
'TBNK','TBPH','TCBI','TCBIL','TCBIP','TCBIW','TCBK','TCCO','TCFC','TCPC','TCRD','TCX','TDIV','TEAR','TECD','TECH','TECU','TEDU','TENX','TERP',
'TESO','TESS','TFM','TFSC','TFSCR','TFSCU','TFSCW','TFSL','TGA','TGE','TGEN','TGLS','TGTX','THFF','THLD','THOR','THRM','THRX','THST','THTI',
'TICC','TIGR','TILE','TINY','TIPT','TISA','TITN','TIVO','TKAI','TKMR','TLF','TLMR','TLOG','TNAV','TNDM','TNGO','TNXP','TOPS','TORM','TOUR',
'TOWN','TQQQ','TRAK','TRCB','TRCH','TREE','TRGT','TRIB','TRIL','TRIP','TRIV','TRMB','TRMK','TRNS','TRNX','TROV','TROVU','TROVW','TROW','TRS',
'TRST','TRTL','TRTLU','TRTLW','TRUE','TRVN','TSBK','TSC','TSCO','TSEM','TSLA','TSRA','TSRE','TSRI','TSRO','TST','TSYS','TTEC','TTEK','TTGT',
'TTHI','TTMI','TTOO','TTPH','TTS','TTWO','TUBE','TUES','TUSA','TVIX','TVIZ','TWER','TWIN','TWMC','TWOU','TXN','TXRH','TYPE','TZOO','UACL',
'UAE','UBCP','UBFO','UBIC','UBNK','UBNT','UBOH','UBSH','UBSI','UCBA','UCBI','UCFC','UCTT','UDF','UEIC','UEPS','UFCS','UFPI','UFPT','UG',
'UGLD','UHAL','UIHC','ULBI','ULTA','ULTI','ULTR','UMBF','UMPQ','UNAM','UNB','UNFI','UNIS','UNTD','UNTY','UNXL','UPI','UPIP','UPLD','URBN',
'URRE','USAK','USAP','USAT','USATP','USBI','USCR','USEG','USLM','USLV','USMD','USTR','UTEK','UTHR','UTIW','UTMD','UTSI','UVSP','VA','VALU',
'VALX','VASC','VBFC','VBIV','VBLT','VBND','VBTX','VCEL','VCIT','VCLT','VCSH','VCYT','VDSI','VECO','VGGL','VGIT','VGLT','VGSH','VIA','VIAB',
'VIAS','VICL','VICR','VIDE','VIDI','VIEW','VIIX','VIIZ','VIMC','VIP','VIRC','VISN','VIVO','VLCCF','VLGEA','VLTC','VLYWW','VMBS','VNDA','VNET',
'VNOM','VNQI','VNR','VNRAP','VNRBP','VNRCP','VOD','VOLC','VONE','VONG','VONV','VOXX','VPCO','VRA','VRML','VRNG','VRNGW','VRNS','VRNT','VRSK',
'VRSN','VRTA','VRTB','VRTS','VRTU','VRTX','VSAR','VSAT','VSCI','VSCP','VSEC','VSTM','VTAE','VTHR','VTIP','VTL','VTNR','VTSS','VTWG','VTWO',
'VTWV','VUSE','VVUS','VWOB','VWR','VXUS','VYFC','WABC','WAFD','WAFDW','WASH','WATT','WAVX','WAYN','WB','WBA','WBB','WBKC','WBMD','WDC',
'WDFC','WEBK','WEN','WERN','WETF','WEYS','WFBI','WFD','WFM','WGBS','WHF','WHFBL','WHLM','WHLR','WHLRP','WHLRW','WIBC','WIFI','WILC','WILN',
'WIN','WINA','WIRE','WIX','WLB','WLBPZ','WLDN','WLFC','WLRH','WLRHU','WLRHW','WMAR','WMGI','WMGIZ','WOOD','WOOF','WPCS','WPPGY','WPRT','WRES',
'WRLD','WSBC','WSBF','WSCI','WSFS','WSFSL','WSTC','WSTG','WSTL','WTBA','WTFC','WTFCW','WTSL','WVFC','WVVI','WWD','WWWW','WYNN','XBKS','XCRA',
'XENE','XENT','XGTI','XGTIW','XIV','XLNX','XLRN','XNCR','XNET','XNPT','XOMA','XONE','XOOM','XPLR','XRAY','XTLB','XXIA','YDIV','YDLE','YHOO',
'YNDX','YOD','YORW','YPRO','YRCW','YY','Z','ZAGG','ZAZA','ZBRA','ZEUS','ZFGN','ZGNX','ZHNE','ZINC','ZION','ZIONW','ZIONZ','ZIOP','ZIV',
'ZIXI','ZLTQ','ZN','ZNGA','ZSPH','ZU','ZUMZ',*/

'DUMMYSTOCK' );// EOF CSVs




$slcnt = count ( $stocksList );
 
$symboljb = $sym  ; 
    

    echo "<br /><br />] ATTEMPTING TO CONTACT the JH_MySql server...<br />] PDT = ". date("h:i:sa"). " on ".  date("Y-m-d") ;

    echo "<br />";


// // ALT DBase2
//     $con = mysqli_connect("localhost", "aideeptr_jb_jackabeejohn", "jackabee66", "aideeptr_jb_jackabee_Users2");
//     if (!$con) die('Could not connect to aide***kabee_Users2: ' . mysqli_error($con));
//     mysqli_select_db($con, "aideeptr_jb_jackabee_Users2") or die ("DB select failed - " . mysqli_error($con));
 
// Normal Dbase
    $con = mysqli_connect("localhost", "aideeptr_jb_jackabeejohn", "jackabee66", "aideeptr_jb_jackabee_Users1");
    if (!$con) die('Could not connect to aide***kabee_Users1: ' . mysqli_error($con));
    mysqli_select_db($con, "aideeptr_jb_jackabee_Users1") or die ("DB select failed - " . mysqli_error($con));
 


    echo "<br />] MySql Connection Good!  <br />"; //"] StockList to Process: ";

    echo "<br />] StockList to Process: $slcnt ...<br />";
$p=0;
for($p=0;$p<$slcnt;$p++){
    echo $p. "]".$stocksList[$p]."__";
}

    echo "<br />";
    echo "<br />";






//  **************************************************************************************** LOOP HERE
//  **************************************************************************************** LOOP HERE
$skipped=0;
$skippedSTR="nil";

$alphaVantageNOTfound=0;
$alphaVantageNOTfoundSTR="nil_";

$p=0;
for($p=0;$p<$slcnt;$p++){
 //   echo $p. "]".$stocksList[$p]."__";
    $symboljb      = $stocksList[$p]  ;
	$symboljbUpper = strtoupper( $symboljb ); 

    $tickerFound = 0;







//    *************************
//    *************************  IF   TABLE.symbolIndex  ticker EXISTS, then SKIP INSERT, ELSE 
//    ************************* 

$query5  = "SELECT * FROM symbolIndex   WHERE  ticker LIKE '$symboljbUpper' limit 2";
$result5 = mysqli_query($con, $query5); // or die("query failed ($query5) - " . mysql_error());  

$j = 0;
$id=-1;
while($row = mysqli_fetch_array($result5))
{
    $data_id                 = $row['id'];
    $data_timestamp          = $row['timestamp'];
    $data_datetimepop        = $row['datepopulated']. "_". $row['timepopulated']. " PDT";
    
    if($j==0){
        $id     = $data_id;
        $tStamp = $data_timestamp;
        //echo "  FOUND userName: $toUserNamesCheck1  id=$id    $tStamp\n\n";
    }
    $j++;
}//while

if($id>0){ // we found at least 1 w/ same userName
	   $tickerFound = 1;
       echo "] ticker $symboljb  Exists in symbolIndex! NOT INSERTING ... <br /> ";
}else echo "] ticker $symboljb  DOES NOT Exist in  symbolIndex! CONTINUING TO INSERT ... <br /> ";

//    *************************
//    *************************  IF   TABLE.symbolIndex  ticker EXISTS, then SKIP INSERT, ELSE 
//    ************************* 











//  IF NOT FOUND HERE ... ELSE ALPHA VANTAGE

if(  $tickerFound == 1){   
    //  . $data_datetimepop
		   echo "<br />] $symboljb WAS FOUND {skipping INSERT} at: date time == ". date("h:i:sa"). " PDT on ".  date("Y-m-d") ;
			$skipped++;
			$skippedSTR = $skippedSTR. "__[". $p. "]". $symboljb;

}else if(  $tickerFound == 0){
	
				echo "] $symboljb NOT found at: ". date("h:i:sa"). " PDT on ".  date("Y-m-d") ;
    			echo "<br />] ATTEMPTING TO CONTACT AV server for $symboljb ...<br />". date("h:i:sa"). " PDT on ".  date("Y-m-d") ;
	//}
	echo "<br />";

$urlStrAdjCompact = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=". $symboljbUpper . "&datatype=csv&apikey=XAE6386LR9QZG0HU";
$urlStrAdjFull    = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=". $symboljbUpper . "&outputsize=full&datatype=csv&apikey=XAE6386LR9QZG0HU";
$urlStrAdj        = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=". $symboljbUpper . "&outputsize=full&datatype=csv&apikey=XAE6386LR9QZG0HU";

    $htmljb = file_get_contents( $urlStrAdj );
    $pieces = explode("\n", $htmljb);

$r=0;
$i=0;
$countjb = count( $pieces );
    echo "] count( $symboljb )=". $countjb. "************************************************<br />";


    if( $countjb < $MIN_CANDLE_COUNT ){
    	//$tickerFound = 2;   // alpha vantage ERR: piecies[0] ==  ' "Error Message": "Invalid API call. Please retry or visit the documentation (https://www.alphavantage.co/documentation/) for TIME_SERIES_DAILY_ADJUSTED."'
    	//echo $htmljb. "<br />";
		$alphaVantageNOTfound++;
		 $alphaVantageNOTfoundSTR = $alphaVantageNOTfoundSTR. $symboljb. "{". $countjb."}__" ;
		         echo "] count( $symboljb )=". $countjb. " ERRORS !!!!!!  $alphaVantageNOTfound : $alphaVantageNOTfoundSTR  !!!!!!!!!  <br />";

    }
// for symbolIndex summary table...
    	$dateStart = "nil";
    	$dateEnd  = "nil";

		$fidStart = "nil";
    	$fidEnd  = "nil";

    	$numCandles = "nil";
    	$datepopulated = "nil";
    	$timepopulated = "nil";


   
   
foreach($pieces as $i =>$key) {
    $i > 0;

    $rainkey = $key;
    $pieces1 = explode(",", $rainkey);
    $timestamp1 = $pieces1[0];            //  YYYY-MM-DD unix baby!

    $tt = strtotime( $timestamp1 );
    //    echo $tt. "\n"; 
     // if($i<10 || $i>($countjb-15))      echo $i.') '.$key .'</br>';

    $weekday = date('l', $tt);
    $yearday0 = getdate( $tt);
    $yearday = $yearday0['yday'];

    $weekday1 = strtolower($weekday);
    $myweekday =  substr(  $weekday1 , 0,3);
    $qtrday = ($yearday+1)%(365/4);


if($countjb< $MIN_CANDLE_COUNT ) {
	for($kk=1;$kk<9;$kk++){
		$pieces1[$kk]="nil".$kk;
	}
	
}

if(  ($i<$countjb-1) ){
    $jb_unixdate = $pieces1[0]; 
    $jb_op = $pieces1[1]; 
    $jb_hi = $pieces1[2]; 
    $jb_lo = $pieces1[3]; 
    $jb_cl = $pieces1[4]; 

    $jb_vol = $pieces1[6]; 
    $jb_dv = $pieces1[7]; 
    $jb_sp = $pieces1[8]; 
}


$insertStr = "nil";


//    *************************  IF  $i  is valid  
if( ($i<$countjb-1)  &&  ($i>0))  {    //not 0th zero or last one left blank by alphaVantage...

	$symboljbUpper = strtoupper( $symboljb ); 
    
    $symbolAGMT =  substr(  $symboljb , 0,1);
    $symbolAGMT =  strtoupper( $symbolAGMT );     

//     default
    $symboltable = "symbolsA";  

     switch( $symbolAGMT ){

     	case "A":
			$symboltable = "symbolsA";  
     	break;
    	case "B":
			$symboltable = "symbolsA";  
     	break;
    	case "C":
			$symboltable = "symbolsA";  
     	break;
    	case "D":
			$symboltable = "symbolsA";  
     	break;
    	case "E":
			$symboltable = "symbolsA";  
     	break;
     	case "F":
			$symboltable = "symbolsA";  
     	break;


     	case "G":
			$symboltable = "symbolsG";  
     	break;
    	case "H":
			$symboltable = "symbolsG";  
     	break;
    	case "I":
			$symboltable = "symbolsG";  
     	break;
     	case "J":
			$symboltable = "symbolsG";  
     	break;
    	case "K":
			$symboltable = "symbolsG";  
     	break;
    	case "L":
			$symboltable = "symbolsG";  
     	break;


     	case "M":
			$symboltable = "symbolsM";  
     	break;
    	case "N":
			$symboltable = "symbolsM";  
     	break;
    	case "O":
			$symboltable = "symbolsM";  
     	break;
    	case "P":
			$symboltable = "symbolsM";  
     	break;
    	case "Q":
			$symboltable = "symbolsM";  
     	break;
    	case "R":
			$symboltable = "symbolsM";  
     	break;
    	case "S":
			$symboltable = "symbolsM";  
     	break;


    	case "T":
			$symboltable = "symbolsT";  
     	break;
    	case "U":
			$symboltable = "symbolsT";  
     	break;
     	case "V":
			$symboltable = "symbolsT";  
     	break;
     	case "W":
			$symboltable = "symbolsT";  
     	break;
     	case "X":
			$symboltable = "symbolsT";  
     	break;
     	case "Y":
			$symboltable = "symbolsT";  
     	break;
     	case "Z":
			$symboltable = "symbolsT";  
     	break;

     	default:
			$symboltable = "symbolsA";  
     	break;

     }//sw    

// echo "===>>>>". $symbolsAGMT. "<<>> $symboltable <<===";
   
   // $symboltable = "symbolsA";  

   			$insertStr = "INSERT INTO ". $symboltable. " (id,  ticker, date, day, qtrday, yearday, open, high, low, close, volume, divcoeff, split, timestamp )  VALUES   ( 'NULL' ,  '$symboljbUpper', '$pieces1[0]', '$myweekday','$qtrday', '$yearday', '$jb_op', '$jb_hi', '$jb_lo', '$jb_cl', '$jb_vol', '$jb_dv','$jb_sp', CURRENT_TIMESTAMP )";
   			
            $last_id= $i;   //  tmp init

			if($MASTER_INSERT_FLAG ==1  &&  $countjb>=$MIN_CANDLE_COUNT ){
				$dumb=0;
			    $resultJB1 = mysqli_query($con, $insertStr); 
			    $last_id = mysqli_insert_id($con);
			}

// record 1st one & last one
//
    if($i==1){
    	$dateStart = $jb_unixdate;   // candle Date  ie  == $pieces1[0] 
		$fidStart = $last_id;

    	$numCandles = $countjb-2;

    	$datepopulated = date("Y-m-d") ;
    	$timepopulated = date("h:i:sa") ;

 		$symbolIndexInsertStr = "INSERT INTO symbolIndex (id,  symbolTable, ticker, dateStart, dateEnd, fidStart, fidEnd, numCandles, datepopulated, timepopulated, timestamp )  VALUES   ( 'NULL' , '$symboltable', '$symboljbUpper', '$dateStart', '$dateEnd','$fidStart','$fidEnd','$numCandles', '$datepopulated', '$timepopulated', CURRENT_TIMESTAMP )";  

 	}else if($i== ($countjb-2) ){

    	$dateEnd  = $jb_unixdate;    // candle Date
    	$fidEnd  = $last_id;
     	$timepopulated =    date("h:i:sa"); 		//$timepopulated = $timepopulated. "_".  date("h:i:sa");   //. " PDT";

 		$symbolIndexInsertStr = "INSERT INTO symbolIndex (id,  symbolTable, ticker, dateStart, dateEnd, fidStart, fidEnd, numCandles, datepopulated, timepopulated, timestamp )  VALUES   ( 'NULL' , '$symboltable', '$symboljbUpper', '$dateStart', '$dateEnd','$fidStart','$fidEnd','$numCandles', '$datepopulated', '$timepopulated', CURRENT_TIMESTAMP )";

			$last_Index_id= $i;   //  DELETE

			if($MASTER_INSERT_FLAG ==1  &&  $countjb>=$MIN_CANDLE_COUNT ){
				$dumb=0;
			    $resultJB2 = mysqli_query($con, $symbolIndexInsertStr); 
			    $last_Index_id = mysqli_insert_id($con);
			}


 echo   "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%";
 echo "<br />". "] i== $i, symbolIndexInsertStr ==". $symbolIndexInsertStr ;
 echo "<br />". "<br />";  //. "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%";

	}//if i == START or END  check

}//if( ($i<$countjb-1)  &&  ($i>0))  {         *************************  IF  $i  is valid  



//LINE brk echo's
$stdepth = 3;//44;
$enddepth = 5;//12;
// if(  ($i<$countjb-1) && $i>0 &&  ($i< 100 || $i>($countjb- 50 ))  )   echo  $insertStr."<br />";
if(  ($i<$countjb-1) && $i>0 &&  ($i< $stdepth || $i>($countjb- $enddepth ))  )   echo "] i== $i) ". $insertStr."<br />";
//if($i>100 && $i<(100+2) ) echo "<br />";
if($i>$stdepth && $i<($stdepth+2) ) echo "<br />";



}//foreach()  candle data line in get file contents
// *************************************************************************** foreach




}//  if(tickerFound==0) 
// SKIP POINT


$p1=$p+1;
    echo "<br />] *******>>  $symboljb tickerFound== $tickerFound. <br />] So far: $p1 STOCKs processed, $skipped skipped INSERTing due to SYMBOL-Exists-Already in symbolIndex table.  $alphaVantageNOTfound av-Errors; the
number of alphaVantage Symbols NOT found = $alphaVantageNOTfound= $alphaVantageNOTfoundSTR, p== $p. <br /><br /><br /><br />";
}// for master p loop thru stock LIST

//  **************************************************************************************** LOOP HERE
//  **************************************************************************************** LOOP HERE   p










if($MASTER_INSERT_FLAG ==1){
  echo "****************************************************** INSERTED $symboljb with $p items.<br />";
}else    echo "************************************************<br />";



/*
INSERT INTO symbolIndex 		(id, symbolTable, ticker, dateStart, dateEnd, 			fidStart, fidEnd, numCandles, datepopulated, timepopulated, timestamp ) 
VALUES 							( 'NULL' , 'symbolG', 'GLD', '2020-09-25', '2020-05-06','1','100',		'100', 	'2020-09-27', '09:21:58pm...09:21:58pm PDT', CURRENT_TIMESTAMP )
*/

    echo "******************  EXITING... ******************************<br />";

	echo "<br />] Closing MySql DB... ";

    mysqli_close($con);
    unset($con );

	echo "<br />] DB Closed Successfully. Bye for now JB.<br /><br />EOF.";



?>

