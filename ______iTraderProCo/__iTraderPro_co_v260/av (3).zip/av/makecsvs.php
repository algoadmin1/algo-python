<?php


//Setting up Error Reporting Level
ini_set('display_errors', 1);
error_reporting(E_ALL);
 
date_default_timezone_set("America/Los_Angeles");
  

 $fn_wat =  "wat_csv.csv";  
 $fn_dow =  "dow_csv.csv";  
 $fn_snp =  "snp_csv.csv";  
 $fn_nas =  "nas_csv.csv";  
 


makearray( $fn_wat );
makearray( $fn_dow );
makearray( $fn_snp );
makearray( $fn_nas );


echo "// EOF CSVs <br />";



// ********************************************************


function makearray( $fname ){


$url ="https://aideeptrader.com/av/". $fname;
$url3= substr(  $fname , 0,3);

  $htmljb = file_get_contents( $url );
  $pieces = explode("\n", $htmljb);

$r=0;
$i=0;
$countjb = count( $pieces );

echo "<br /><br />". "   $". "stocksList". "_". $url3." = array( " ;

foreach($pieces as $i =>$key) {
    $i > 0;

    if( ($r%20)==0 ) echo "<br />";

    $rainkey = $key;
    if($rainkey!="")    echo "'". $rainkey. "'," ;
    $r++;
}
echo "<br />". " 'DUMMYSTOCK' );" ;

} 


?>

