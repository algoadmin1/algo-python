<?php

/** 
                    by John Botti 08.20.2020,   10/14/13, 02.07.15
       aiDTregister.php - adapted from: userNewsignup.php    Version __________    - w/ NEW geobytes.com ___                   ver 5.4
//                                                                                 - with returning unique user ID #
* .php - Unity to SQL Database Connection
**/

//date_default_timezone_set("America/New_York");
//$nyTime == date("h:i:sa"). " on ".  date("Y-m-d") ;

//date_default_timezone_set("America/LosAngeles");

//Setting up Error Reporting Level
ini_set('display_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set("America/New_York");
$nyTime = date("h:i:sa"). " on ".  date("Y-m-d") ;
date_default_timezone_set("America/Los_Angeles");
ob_implicit_flush(1);



 if(isset( $_GET['sym'] )){
        $sym = $_GET['sym'] ;
    }else{
        $sym = "BA";
    }
   $sym = strtoupper($sym);

   // echo "] sym = ". $sym ;


$verNo="2.1";
$last_id ="";

// $searchQuery0 = $_POST["useremail"];
// $searchQuery1 = $_POST["pwd"];
// $searchQuery2 = $_POST["name"];

    
    echo "] Reached Server... vers. $verNo <br />] The Time in New York is $nyTime, this system is running on PST. <br />";

    echo "<br />] Connecting...";

/*

aideeptr_jb_jackabee_Users1   //18.69 KB    
aideeptr_jb_aideeptrader    
aideeptr_jb_jackabeejohn    


$cars = array("Volvo", "BMW", "Toyota");
echo count($cars);
*/

// ########################################################################################

// 1 == go do Mysql SELECT to see if it exists IFnot THEN INSERT
// 0 == no insert
$MASTER_INSERT_FLAG = 0;

// ########################################################################################






$stocksListWATCHLIST = array('CCL','LVS','YUM','FCX' );    

$stocksListETFS = array('CCL','LVS','YUM','FCX' );    

$stocksListDOW30 = array('CCL','LVS','YUM','FCX' );    
$stocksListNDX100 = array('CCL','LVS','YUM','FCX' );   
$stocksListSPY100 = array('GLD','VXX','JWN','AMZN', 'HAL', 'TSLA', 'FCX'  );
$stocksListTEST = array('GLD','VXX','JWN','AMZN', 'HAL', 'TSLA', 'FCX'  );



// NAME the array $stocksList to execute those tickers
$stocksList =array('GLD','VXX','JWN','AMZN', 'HAL', 'TSLA', 'FCX' ,'NFLX', 'QQQ' ,'TTWO' );


$stocksListBAK = array('SPY','QQQ','DIA','VXX','VXY','NDX','AAPL','AMZN','FB','TSLA','ROKU','NVDA','SHOP','GOOGL','NFLX','M','JWN','GS','NVAX','SRNE', 'IMMU', 'MRNS','GLD','GBTC','SLV','JWN','SNAP','ZM','AMD','INTC','V','BA','SPCE','SBUX','LULU','AAL','DAL','JBLU','MSFT','KODK','ETSY','LYFT','UBER','SQ','WYNN','TLT','ALB','BABA','C','TCEHY','BIIB','UPS','ILMN','PINS','MGM','LVS','OSTK','TBT','TLT','BIDU','F','X','L','KO','MCD','WMT','DIS','NKE','GOOGL','BAC','AXP','JPM','CANN', 'CCL','LVS','YUM','FCX');

$slcnt = count ( $stocksList );

 
$symboljb = $sym  ; //"BA";
    

    echo "<br /><br />] ATTEMPTING TO CONTACT the JH_MySql server...<br />] PDT = ". date("h:i:sa"). " on ".  date("Y-m-d") ;

    echo "<br />";

    // DOS 05.21.15  OPEN mySqli database
    $con = mysqli_connect("localhost", "aideeptr_jb_jackabeejohn", "jackabee66", "aideeptr_jb_jackabee_Users1");
    if (!$con) die('Could not connect to aide***kabee_Users1: ' . mysqli_error($con));
    mysqli_select_db($con, "aideeptr_jb_jackabee_Users1") or die ("DB select failed - " . mysqli_error($con));
     // DOS 05.21.15


    echo "<br />StockList to Process: ";

$p=0;
for($p=0;$p<$slcnt;$p++){
    echo $p. "]".$stocksList[$p]."__";
}

    echo "<br />";
    echo "<br />";



$MASTER_INSERT_FLAG = 0;




//  **************************************************************************************** LOOP HERE
//  **************************************************************************************** LOOP HERE
//  **************************************************************************************** LOOP HERE

$p=0;
for($p=0;$p<$slcnt;$p++){
 //   echo $p. "]".$stocksList[$p]."__";
    $symboljb    = $stocksList[$p]  ;



    echo "<br /><br />] ATTEMPTING TO CONTACT ALPHA VANTAGE server for $symboljb ...<br />". date("h:i:sa"). " on ".  date("Y-m-d") ;

//ob_flush();
//flush();



// &outputsize=compact
// &outputsize=full
    //
    $urlStrAdj = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=". $symboljb . "&outputsize=full&datatype=csv&apikey=XAE6386LR9QZG0HU";

   // $urlStr = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=". $symboljb . "&outputsize=full&datatype=csv&apikey=XAE6386LR9QZG0HU";

//    $htmljb = file_get_contents( $urlStr );
    $htmljb = file_get_contents( $urlStrAdj );

    $pieces = explode("\n", $htmljb);


// $weekday = date('N', $timestamp);


    



$r=0;
$i=0;
$countjb = count( $pieces );

    echo "count=". $countjb. "************************************************<br />";


foreach($pieces as $i =>$key) {
    $i >0;

    $rainkey = $key;
    $pieces1 = explode(",", $rainkey);
    $timestamp1 = $pieces1[0];            //  YYYY-MM-DD unix baby!

    $tt = strtotime( $timestamp1 );
    //    echo $tt. "\n"; 
     // if($i<10 || $i>($countjb-15))      echo $i.') '.$key .'</br>';

    $weekday = date('l', $tt);
    $yearday0 = getdate( $tt);
    $yearday = $yearday0['yday'];

    $weekday1 = strtolower($weekday);
    $myweekday =  substr(  $weekday1 , 0,3);
    $qtrday = ($yearday+1)%(365/4);

if(  ($i<$countjb-1) ){
    $jb_unixdate = $pieces1[0]; 
    $jb_op = $pieces1[1]; 
    $jb_hi = $pieces1[2]; 
    $jb_lo = $pieces1[3]; 
    $jb_cl = $pieces1[4]; 

    $jb_vol = $pieces1[6]; 
    $jb_dv = $pieces1[7]; 
    $jb_sp = $pieces1[8]; 
}


   // if(    ($i<$countjb-1)   && $i>0 &&  ($i<100 || $i>($countjb-50))     ) echo $i.') '.$pieces1[0]."#".$symboljb."#". $myweekday.":". $yearday. "+".$qtrday."#".  $pieces1[1]. "#".  $pieces1[2]. "#".  $pieces1[3]. "#".  $pieces1[4]."#vl".  $pieces1[6]."#dv".  $pieces1[7]."#sp".  $pieces1[8]. "====]<br />";


$insertStr = "nil";


//    *************************  IF   TABLE.symbolIndex  ticker EXISTS, then SKIP INSERT, ELSE 


if( ($i<$countjb-1)  &&  ($i>0))  {    //not 0th zero or last one left blank by alphaVantage...

    $symbolAGMT =  substr(  $symboljb , 0,1);
     $symbolAGMT =  strtoupper( $symbolAGMT );     

//     default
    $symboltable = "symbolA";  

//cho strnatcmp("Z","T");  ==  1, 
//cho strnatcmp("F","T");  == -1, 

    //ie  strnatcmp( "B",      "G" )  ==-1  ;  // , ==0 "G"=="G", >0 , ==1 "J">"G"
     if ( strnatcmp($symbolAGMT ,"G") < 0 ) {
            $symboltable = "symbolA";  

     }else if ( strnatcmp($symbolAGMT ,"M") < 0 )  {
           $symboltable = "symbolG";  

     }else ( strnatcmp($symbolAGMT ,"T") < 0 ) {
            $symboltable = "symbolM";  

     }else {
            $symboltable = "symbolT";  
     } 

echo "===>>>>". $symbolAGMT. "<<>> $symboltable <<===";
    
   // $symboltable = "symbolA";  


    $insertStr = "INSERT INTO ". $symboltable. " (id,  ticker, date, day, qtrday, yearday, open, high, low, close, volume, divcoeff, split, timestamp )  VALUES   ( 'NULL' ,  '$symboljb', '$pieces1[0]', '$myweekday','$qtrday', '$yearday', '$jb_op', '$jb_hi', '$jb_lo', '$jb_cl', '$jb_vol', '$jb_dv','$jb_sp', CURRENT_TIMESTAMP )";

    // $insertStr = "INSERT INTO symbols1 (id,  ticker, date, day, qtrday, yearday, open, high, low, close, volume, divcoeff, split, timestamp )  VALUES   ( 'NULL' ,  '$symboljb', '$pieces1[0]', '$myweekday','$qtrday', '$yearday', '$jb_op', '$jb_hi', '$jb_lo', '$jb_cl', '$jb_vol', '$jb_dv','$jb_sp', CURRENT_TIMESTAMP )";



if($MASTER_INSERT_FLAG ==1){
   $resultJB1 = mysqli_query($con, $insertStr); 
   $last_id = mysqli_insert_id($con);
}


// record 1st one & last one
//
   //  if $i==1 record $firstone = last_id  , $firstDate
   //  if ($i<$countjb-1) record $lastone = last_id , $lastDate


}//if

$stdepth = 40;
$enddepth = 12;

    if(  ($i<$countjb-1) && $i>0 &&  ($i< $stdepth || $i>($countjb- $enddepth ))  )   echo  $insertStr."<br />";

//if($i>100 && $i<(100+2) ) echo "<br />";
if($i>$stdepth && $i<($stdepth+2) ) echo "<br />";

   

}//foreach


//    *************************  INSERT TABLE.symbolIndex ticker, date st,end, fid st, end.

// SKIP POINT

    echo "************************************************ p == $p <br />";
}// for master p loop





if($MASTER_INSERT_FLAG ==1){
  echo "****************************************************** INSERTED with $p items.<br />";
}
    echo "************************************************<br />";
    echo "************************************************<br />";




 

/*

for($i=$istart ;  $i<$iend  ; $i+=$secondsInADay ){
 
    $mydate=getdate($i);

    $mymonth = "$mydate[mon]";
    if($mymonth<10) $mymonth= "0". "$mydate[mon]";

    $myday  = "$mydate[mday]";
    if($myday<10) $myday= "0". "$mydate[mday]";

    $myweekday = "$mydate[weekday]";
      $myweekday =  substr(  $myweekday , 0,3);

    $dayofyear="$mydate[yday]";
    $dayofyear++;


*/

// echo "] _POST[useremail] = $searchQuery0 <br />";
// echo "] _POST[pwd] = $searchQuery1 <br /> <br />";   
// echo "] _POST[name] = $searchQuery2 <br /> <br />";    

// echo "] Welcome oh, great Creator to aiDeepTrader !<br />";

// $userValid=0;

// $passwordSHA1 = sha1($searchQuery1);
// $lowerEmail = strtolower($searchQuery0);

// $username0  =" ";
// $username0  = strtok($lowerEmail, "@");          // $username0 = jbotti   from jbotti@laskdj.com

// $email0 = $lowerEmail;          // $toUserNamesCheck1

// echo "pwd==". $passwordSHA1. " ". $lowerEmail. " ,  username0==". $username0. ", ". date("h:i:sa"). " on ".  date("Y-m-d"). ".<br />";


// // | aiemail       | varchar(256) | NO   |     | NULL              |                |

// $query5 = "SELECT * FROM users      WHERE    aiemail  LIKE '$lowerEmail'";


// // DOS 05.21.15
// $result5 = mysqli_query($con, $query5); // or die("query failed ($query5) - " . mysql_error());
 
// $j = 0;
// $id=-1;
// $pwd="";
// $tStamp="";

// while($row = mysqli_fetch_array($result5))
// {
//     $data_id                   = $row['id'];
//     $data_pwd                  = $row['pwd'];
//     $data_timeStamp            = $row['timeStamp'];
    
//     if($j==0)
//     {
//         $id = $data_id;
//         $pwd = $data_pwd;  // careful here - unused?  clean up
//         $tStamp = $data_timeStamp;
//         //echo "  FOUND userName: $toUserNamesCheck1  id=$id pwd=$pwd   $tStamp\n\n";
//     }
//     $j++;
    
// }//while

//  //  PASSWORD MATCH !   userName: john,  id=3, pwd= ,so1314==,so1314
// if($id>0)  // we found at least 1 w/ same userName
// {
//     echo "&Username Exists! $id, $pwd, $tStamp <br />] Getting Session ID for Secure Access, $username0...<br /> <br />] Exiting... {54} <br />";
//     $last_id ="userID== $id, no data inserted... ";
  
// }else{
//      // echo "  No User Found - We DO NOT MATCH THAT USER EMAIL [ $lowerEmail ]!!!  - Aborting -   <br />";
//      echo "  No User Found - We HAVE NO MATCH FOR USER's EMAIL[ $lowerEmail ]  - INSERTing...<br />";

// // for now use NO USE EXIST LOGIN --> === REGISTER TEST USERS *****
//  $insertStr = "INSERT INTO users (id,  userName,  pwd,   email, aiUsername, aiemail, timeStamp)   VALUES  ('NULL' ,     '$username0' ,'$passwordSHA1',   '$email0',  '$searchQuery2', '$email0',     CURRENT_TIMESTAMP)";

//    		// DOS 05.21.15
//         $resultJB1 = mysqli_query($con, $insertStr); 
//         $last_id = mysqli_insert_id($con);

// $userValid=1;

//  // $insertStr = "INSERT INTO users (id,  userName,  pwd,   email, IPaddress, lon, lat, alt, instagram_id, city, state, country, gender, device, signupTime, timeStamp )  VALUES ( 'NULL' ,  '$username0' ,  '$passwordSHA1',   '$email0', '$IPaddress', '$IPlong', '$IPlat', '$altInit', '$instagramName', '$city', '$state', '$country',  '$gender',  '$device',  '$signupTime',    CURRENT_TIMESTAMP )";
      

//  }//else


 //EOF PHP script...

 		echo "<br />] Closing MySql DB... ";

        mysqli_close($con);
        unset($con );
        // DOS 05.21.15

//         echo "] last_id = $last_id ; Connection unset.  DataBase Closed at ". date("h:i:sa"). " on ".  date("Y-m-d") ;


// echo "<br /><br /><br />";
// // echo "<h1>aiDeepTrader Gateway open...</h1>";

// if($userValid==1){
// //$href00='"http://www.aideeptrader.com"';
// $href00= '"http://aideeptrader.com/candlesticks.php?sym=aapl"';
// echo "] aiDeepTrader Gateway open... <br /><h1>CLICK for Private Access: <a href=$href00>aiDeepTrader</a></h1>";
// }
// echo "<p>CLICK for Private Access: <a href=$href00>aiDeepTrader</a></p>";
echo "<br />Bye JB.<br /><br />EOF.";

/*

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://api.minetools.eu/ping/play.desnia.net/25565",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

*/


?>

