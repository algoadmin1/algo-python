<?php


//Setting up Error Reporting Level
ini_set('display_errors', 1);
error_reporting(E_ALL);
 
date_default_timezone_set("America/Los_Angeles");
  
 $fn =  "wat_csv.txt";  
$url ="https://aideeptrader.com/av/". $fn ;
$url3= substr(  $fn , 0,3);
 

  $htmljb = file_get_contents( $url );
  $pieces = explode("\n", $htmljb);

$r=0;
$i=0;
$countjb = count( $pieces );

echo "<br />". "   $". "stocksList". "_". $url3." = array( " ;

foreach($pieces as $i =>$key) {
    $i > 0;

    $rainkey = $key;
    echo "'". $rainkey. "'," ;
}
echo "<br />". " 'DUMMYSTOCK' );" ;

 


?>

