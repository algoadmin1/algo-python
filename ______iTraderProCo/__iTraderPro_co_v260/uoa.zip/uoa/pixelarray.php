<?php


	$i=0;
	$iMax= 8 * 1024;
	$imodulo = 64;

	echo "var gPixelArrayStatic =[ <br />";

	for ($i=0 ;  $i< $iMax  ;  $i++){
		echo $i. "," ;
		if($i % $imodulo ==0){
			echo "<br /> //  i=". $i. " <br />"" ;
		}

	}

	echo "  ]; <br />";


?>