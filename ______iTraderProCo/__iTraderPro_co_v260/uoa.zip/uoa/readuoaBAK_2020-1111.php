<?php
    
ini_set('display_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('America/Los_Angeles');
  
    $versionNo="Version 3.5.4";
    $defaultLen = 32;
    // $fname ="symbols.csv";
    //output file
    $fname ="log.txt";

    $stocks="";

 $vowels = array(",");
 $vowels1 = array("-");

$totalSumMoneyBoughtAndSold=0 ;  
$totalSumMoney =0;



//    adapted to receive various WATCHLISTS and create an array in javascript for inclusion 
//    if(isset( $_GET['fn'] )){
//        $fname = $_GET['fn']. ".csv" ;
//    }else{
//        $fname = "dnalib.csv";
//    }
//
//    if(isset( $_GET['max'] )){
//        $defaultLen = $_GET['max'] ;
//    }else{
//        $defaultLen = 32;
//    }
//  echo "usage:   ] readdnacsv.php?fn=dna[.csv]  <br /><br />";
//
    
    
    if( $defaultLen < 1 ||  $defaultLen > 512  )    $defaultLen = 32;

    $alphaSet = "abcdefghijklmnopqrstuvwxyz0123456789*$@#!_-+";
    $aSetCnt  = strlen( $alphaSet );
    
    $strBR= "\n";

    
    // MYSQL CONNECT FUTURE USE
    // 
    // $con = mysqli_connect("localhost", "jb_jackabeejohn", "jackabee66", "jb_SuperTrader");
    // if (!$con) die('Could not connect: '. mysqli_error($con));
    // mysqli_select_db($con, "jb_SuperTrader") or die ("] MySQL: SuperTrader Database connect failed - exiting... " . mysqli_error($con));
    // $data = array();
    
    // echo "] GOT PAST data[] array and MySQL initial connection...<br />";
    
    // $queryStr = "SELECT * FROM tickers ";
    // $result   = mysqli_query($con, $queryStr);
    // $j=0;
    // while($row = mysqli_fetch_assoc( $result )){
    //     $data[] = $row;
    //     $j++; 
    //     echo $j. "]". "  ". $row['id']. "  ". $row['ticker']. "  ". $row['date']. "<br />";
    //     $jsonStr  =  json_encode( $row ) ;

    //     echo $jsonStr. "<br />". "<br />";

    // }
    // $i=0;
    //  // echo json-formatted data back to javascript
    // $newdata =  json_encode($data);
  
    // echo "]  GOT PAST LOOP    AND    json_encode( data )  <br />";

    // echo "newdata =". $newdata . "<br />". "<br />";
   	// echo "newdata[1] =". $newdata[1] . "<br />". "<br />";
    
    
    /*



//   1. take UAO.txt in for processing - this creates      watchlist0.js   [uoa]
//
//   2.  take watchlist.txt in  - this creates      watchlist.js   [ our standard watchlist ]
//        2a. NOTE: This can stay static for a while: FB, AAPL, AMZN , NFLX, NVDA, GOOGL, QQQ, VXX, GS, NIO, etc
//
//   3.  ideally we can merge, various watchlists   [ uoa, ourWatchlist, dynamicDailyWatchlist ]
//
//   4.  take watchlistdynamic.txt in  - this creates watchlistdynamic.js   [ daily * dynamic * watchlist ]
//
//   5. overlaps on watchlists are welcome and tolerated; they will be uniquely filtered upon ingestion to iTraderPro client

    */
    

    
    // open file 
    $currentStock="12349172340981723";    // no ticker would be this so it is  != on first go in loop
    $listofstocks="var stocksForWatchlist = [ ";
    $listofstocks10="";
    
    $numOfStocks=0;
    $file = fopen("uoa.txt", "r");
    $i = 0;
    
    $numOfBullishPositions=0;
    $numOfBearishPositions=0;
         $checknextline= 0;


// FILE OPEN TO WRITE !!! [ here we can write stock/option data into dbase.logv]
    $masterFileName = "watchlist0.txt";
    $handle = fopen($masterFileName, "w");
    

//  OUTPUT LINE TO FILE
    $line1 = "// watchlist0.txt ". $strBR. "// 4th-Generation Code by readuoa.php ; Creator = J. Botti.". $strBR.  $strBR. $strBR ;
         $line1.= $strBR. "//  VERSION NO.: ". $versionNo.". This data converted on " . date("Y-m-d"). " at " . date("h:i:sa"). ".".  $strBR.  $strBR ;
    echo $line1;
    fwrite( $handle, $line1);
    
    




        $checknextline = 0 ;

// loop thru body of incoming text
    while (!feof($file)) {
        

        $line_of_text = fgets($file);
       // $members = explode('\n', $line_of_text);
        echo $i. " == ". $line_of_text. "<br />"  ;
        


/*

HEADING:
[ symbol ] [ Bullish/Bearish ]  [ Position Type ]
NKE Bullish Call Roll

2nd LINE:
Nov 10, 2020 01:00 pm – Posted by: Chris Sykora
[ DATE ] [ TIME EST ] - Posted by: [ MR Trader / Instructor ]


[ # contracts] [ Expiration date] [ strike] [ call/ put ] [bought/sold] for [ price min[..max]] [above/below] open interest of [oi]

[rolled position mimic above # contracts here {optional}]
2,200 January *2022* 125 calls bought for 18.10 to 19.40 above open interest of 885 contracts; 2,400 January *2021* 95 calls sold for 34.20 to 31.95 below open interest of 6,703 contracts. 

Stock [price/range]
Stock 126.64-128.96.




USFD Bearish Put Buying
Nov 11, 2020 02:41 pm – Posted by: Mike Yamamoto
3,600 November 30 puts mostly bought for 1.05 to 1.85 above open interest of 430 contracts. Stock 28.69. EPS *estimated* 2/9 before open.

SIRI Bullish Call Buying
Nov 11, 2020 02:34 pm – Posted by: Mike Yamamoto
4,800 June 7 calls bought for 0.25 to 0.30 above open interest of 200 contracts. Stock 6.21.

GME Bearish Put buying
Nov 11, 2020 02:28 pm – Posted by: Chris Sykora
4,000 December 14 puts bought for 3.95 to 4.01 above open interest of 740 contracts. Stock 11.59-11.66.

AMD Bullish Call Buying
Nov 11, 2020 02:23 pm – Posted by: Chris Sykora
4,500 04December 88 calls bought mostly in one print of 3,689 for 1.17 to 1.27 above open interest of 213 contracts. Stock 80.48-80.79.

MPLN Bearish Put Buying
Nov 11, 2020 02:14 pm – Posted by: Mike Yamamoto
3,300 November 10 puts bought for 1.35 to 2.40 above open interest of 1,749 contracts. Stock 7.66.



155 ==
156 == KO Bullish Call Roll
[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,]
157 == Nov 11, 2020 10:04 am – Posted by: Chris Sykora

[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,]

157-a == Nov 11 2020 10:04 am – Posted by: Chris Sykora

158 == 9,100 February 55 calls bought for 1.52-1.57 mostly in one 8,550 print above open interest of 4,035 contracts; 9,100 November 52.50 calls sold mostly in one print of 8,550 for 1.38 to 1.33 below open interest of 22,568 contracts. Follows...

[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,]

158-b == [9100]9100 February 55 calls bought for 1.52 to 1.57 mostly in one 8550 print above open interest of 4035 contracts; 9100 November 52.50 calls sold mostly in one print of 8550 for 1.38 to 1.33 below open interest of 22568 contracts. Follows...
[ boughtSold= 1 callPut= 1 FOR 1.52 .. 1.57 avg= 1.545 ] ___ [ *TradeMoney $1,405,950 = 9100 * 1.545 * 100 ]
[ boughtSold= -1 callPut= 1 FOR 1.38 .. 1.33 avg= 1.355 ] ___ [ *TradeMoney $1,233,050 = 9100 * 1.355 * 100 ]


159 ==
160 == MU Bullish Call Buying
[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,mu,]
161 == Nov 11, 2020 09:52 am – Posted by: Chris Sykora
[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,mu,]
161-a == Nov 11 2020 09:52 am – Posted by: Chris Sykora
162 == 4,500 December 62.50 calls bought for 0.90 to 0.98 above open interest of 444 contracts. Stock 56.71-56.77.
[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,mu,]
162-b == [4500]4500 December 62.50 calls bought for 0.90 to 0.98 above open interest of 444 contracts. Stock 56.71 to 56.77.
[ boughtSold= 1 callPut= 1 FOR 0.90 .. 0.98 avg= 0.94 ] ___ [ *TradeMoney $423,000 = 4500 * 0.94 * 100 ]
[ stockPrice = $56.71 ]




*/

      if( $line_of_text!="" ){

        $field = explode(' ', $line_of_text);
        $fcnt  = count( $field );



//  i.e. first valid line in Trade Desc Group
// [ symbol ] [ Bullish/Bearish ]  [ Position Type ]
//  NKE Bullish Call Roll
if($fcnt>2){

        $huntedSymbol     = strtolower ($field[0]);
        $huntedStr        = strtolower ($field[1]);
        $huntedPos        = strtolower ($field[2]);
        
        if (isset($field[3] ))   $huntedCallPut    = strtolower ($field[3]);
        if (isset($field[4] ))  $huntedTradeType  = strtolower ($field[4]);
 

        if( $huntedStr =="bullish"){
              $numOfStocks++;
              $numOfBullishPositions++;
               $stocks.= $huntedSymbol. "," ;

        }else if( $huntedStr =="bearish"){
              $numOfStocks++;
              $numOfBearishPositions++;
                $stocks.= $huntedSymbol. "," ;

        }

        echo "[". $stocks . "]<br />";


/*
 https://itraderpro.co/uoa/readuoa.php
*/

// this line is the trade, starting w/ # of contracts
if($checknextline==$i){
 $line_of_text2 = str_replace($vowels, "",  $line_of_text );
 $line_of_text1 = str_replace($vowels1, " to ",  $line_of_text2 );
 

        $field1 = explode(' ', $line_of_text1 );
        $fcnt1  = count( $field1 );
        $huntedTradeSize     = $field1[0] ;
         echo $i. "-b == [". $huntedTradeSize. "]".  $line_of_text1. "<br />"  ;


          $e=0; $boughtSold=0; $callPut=0; $rangelow=0; $rangehi=0;
          $expir="2029-12-31"; $strikePrice=0; $stockPrice=0; $stockAtLow=0; $stockAtHigh=0;

          for($e=1;$e<$fcnt1;$e++){
// 4000 November 68.50 puts bought for 1.30 to 1.50 above open interest of 2 contracts. Stock 69.01-69.29.

               $huntedTok     = strtolower ( $field1[$e+0] );
               
                if (isset($field1[$e+1] ))  $huntedTok1    = strtolower ( $field1[$e+1] );
                  else $huntedTok1="";
                if (isset($field1[$e+2] ))  $huntedTok2    = strtolower ( $field1[$e+2] );
                  else $huntedTok2="";
              if (isset($field1[$e+3] ))  $huntedTok3    = strtolower ( $field1[$e+3] );
                  else $huntedTok3="";

              switch ($huntedTok) {
                case 'bought':
                  $boughtSold=1;
                  break;
                case 'sold':
                  $boughtSold=-1;
                  break;
                case 'for':
                  $rangelow  = $huntedTok1 ; //$field1[$e+1];
                  $rangehi   = $rangelow ; //$field1[$e+1];

                  if($huntedTok2=="to")  $rangehi   =$huntedTok3; // $field1[$e+3];

                  $avgPrice = ($rangelow+$rangehi)/2;
                  echo "[ boughtSold= $boughtSold  callPut= $callPut  FOR $rangelow .. $rangehi avg= $avgPrice ] ___ ";
                  $TradeMoney  =  $huntedTradeSize * $avgPrice * 100;
                  $totalSumMoneyBoughtAndSold += $TradeMoney; 

                  $TradeMoney1 = $boughtSold * $TradeMoney;
                 $totalSumMoney += $TradeMoney1; 

                  $TradeMoney11 = number_format($TradeMoney1);

                  echo "[ *TradeMoney $". $TradeMoney11. " =  $huntedTradeSize * $avgPrice * 100 ]  <br />" ;

                  break;
                case 'puts':
                  $callPut=-1;
                  break;
                case 'calls':
                  $callPut=1;
                  break;
                 case 'stock':
                  $stockPrice = $huntedTok1;
                   echo "[ stockPrice = $". $stockPrice . " ]<br /><br />" ; 
                  break;
                
                 
              }//sw

          }//for


          $checknextline = 0 ;

}//if


// test for 2nd line

                switch ($huntedSymbol) {
                  case 'jan':
                  case 'feb':
                  case 'mar':
                  case 'apr':
                  case 'may':
                  case 'jun':

                  case 'jul':
                  case 'aug':
                  case 'sep':
                  case 'oct':
                  case 'nov':
                  case 'dec':
 
                    $d=0;
                    $line_of_text1="";
               
                      // Provides: Hll Wrld f PHP
// $vowels = array("a", "e", "i", "o", "u", "A", "E", "I", "O", "U");
         $line_of_text1 = str_replace($vowels, "",  $line_of_text );
 
         echo $i. "-a == ". $line_of_text1. "<br />"  ;

         $jbdate= $huntedSymbol." ". $huntedStr ." ". $huntedPos;

        echo "{". date( "Y-m-d", strtotime( $jbdate ) ) . "}"; 
        echo "{=". date( "ymd", strtotime( $jbdate ) ) . "=}"; 
         $checknextline = $i+1;
                    


                     break;
                  


                  default:
                    ;
                    break;

                }//sw




}// if fcnt





       }//if new $line_of_text!=""







// if( $line_of_text!="" ){
       
//         $field = explode(',', $line_of_text);
//         $fcnt = count( $field );


//         // replace
//         //
//         //   echo str_replace(".","_",$field[9]);
//         //
//         //

//         // JMB 2019-02-10
//         //
//         //  here we should replacd $field[9] with a var like 'symbol'
//         //
//         //
//         $fstr  = $field[9];
//         $fstr9 = $field[9];
//         $fstr  = str_replace(".", "_", $fstr );

// // ie RDS.A RDS_A
//         $line_of_text1 = str_replace($fstr9, $fstr, $line_of_text );
//        // echo $i. " )  fstr==". $fstr ."  | ". $line_of_text1. "<br />"  ;


//        $newstock=0;
//        if( $fcnt >=9 ){  //[9] is our ticker
//          //  if( $field[ 9 ]  != $currentStock){
//          //    $currentStock =   $field[ 9 ]  ;

//            if( $fstr  != $currentStock){
//                $currentStock =   $fstr  ;
//                $numOfStocks++;
//                $newstock=1;

               
//                $line2="";

//            if($numOfStocks>1) $line2 = "];".  $strBR.  $strBR ;
//                 else $line2 = $strBR. $strBR ;
           
               
//            $currentStock1 = substr( $currentStock, 1, -1 );
//                // substr 1, strlen( $currentStock )-1;
//                $line2a= $line2;
//                $line2.= "var candles".$currentStock1." = [ ". $strBR. $strBR ;
//                $line2a.= "  <br />var candles".$currentStock1." = [ ". $strBR. $strBR ;
               
//                echo $line2a; //
//                fwrite( $handle, $line2);

//            }
           
           
//           // echo "[". $numOfStocks.".". $currentStock. "].". $i. ") "   ;
//            if( $newstock == 1 ){
               
//                $line3 = "//  ";   // ie comment out 1st line
//                fwrite( $handle, $line3);
//                echo $line3;
               
//                //$line4 =   $line_of_text. $strBR  ;
//                $line4 =   $line_of_text1. $strBR  ;
//                fwrite( $handle, $line4);
//                echo $line4;
               
//                $listofstocks10 .= $currentStock1. ",";
//                $listofstocks .= $currentStock. ",";
//            }else{
               
//                $line4 =   $line_of_text1;   //.  $strBR  ;
//                fwrite( $handle, $line4);

//               // echo $line4;
//            }
           
           
//        }//if
//    }//if $line_of_text!=""

        












   // still in while loop
    $i++;

  }//while


echo " totalSumMoneyBoughtAndSold = ". number_format($totalSumMoneyBoughtAndSold). " ;  totalSumMoney = ". number_format($totalSumMoney). "  <br />";
    // CLOSE INPUT TEXT FILE - DONE READING IT !
  fclose($file);
    
 


    $endofstream = $strBR. " ".  $strBR.  $strBR;
    


    $numLinesRead = $i;
    $listofstocks1 = substr( $listofstocks, 0, -1);
    $listofstocks1 .= "];".  $strBR.  $strBR ;
    
    $endofstream .= "//". $listofstocks1. "// var watchliststocksMax = ". $numOfStocks . "; ".$strBR.  $strBR. " // num stocks read = ". $numOfStocks .", num Lines Read = ". $numLinesRead;
    
    $endofstream .=   $strBR. "//  VERSION NO.: ". $versionNo.". This data converted on " . date("Y-m-d"). " at " . date("h:i:sa"). ".".  $strBR ;
    
    
    echo $endofstream;

    fwrite($handle, $endofstream);
    fwrite($handle, $stocks );
    


    
    
  // // Nov 30th 2018
  //   $computeandrender =" ". $strBR. $strBR. "function ComputeAndRenderCandlesticks1( stockNum ){ ". $strBR. "  if(stockNum < 0  || stockNum > stocksMax ) return(-1); ". $strBR. $strBR;
    
  //   $computeandrender.=  "   switch( stockNum ){ ". $strBR. "//  $listofstocks10 ". $strBR;
  //   $stockslist10 = explode( "," , $listofstocks10 );
  //   $scnt = count( $stockslist10 );
    
  //   for($y=0;$y < ($scnt-1); $y++){
  //       $symxyz= str_replace( ",", "", $stockslist10[ $y ] );
        
  //       $computeandrender.= "     case  ". $y. ":". $strBR. "       ComputeAndRenderCandles( ". "candles".$symxyz . " );". $strBR. "     break;". $strBR ;
        
  //   }//for
  //   $computeandrender.= "    }//sw".$strBR  ." return( stockNum );  ". $strBR. "}//fn";
  //   fwrite($handle, $computeandrender );
 





// CLOSE MYSQL

    // mysqli_close( $con );
    // unset( $con );


   fclose($handle);


?>
