<?php
    
ini_set('display_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('America/Los_Angeles');
  
    $versionNo="Version 3.5.4";
    $defaultLen = 32;
    // $fname ="symbols.csv";
    //output file
    $fname ="log.txt";

    $delim = "<br />";

    $totalNumStocks=0;

    $START_SYMBOLS_DYNAMIC_0a="[START_SYMBOLS_DYNAMIC]";
    $START_SYMBOLS_DYNAMIC_0="=".strtolower($START_SYMBOLS_DYNAMIC_0a);

    $START_SYMBOLS_STANDARD ="=".strtolower("[START_SYMBOLS_STANDARD]");
    $END_SYMBOLS            =strtolower("[END_SYMBOLS_"). "|". $totalNumStocks."|]";


/*

 https://itraderpro.co/uoa/readuoa.php?msgs=1        

*/


    $stocks="";

 $vowels = array(",");
 $vowels1 = array("-");




$stocksList_watchlist = array(

  'SPY','DIA','QQQ','VXX','GLD','SLV','USO','TBT','TLT','GBTC','AAPL','AMZN','BYND','F','X','ROKU','FB','BA','M','MSFT',

'TSLA','PTON','SHOP','NVAX','NFLX','SRNE','AAL','NKLA','SBUX','LULU','RCL','SPCE','MRNA','SPOT','ADT','NVDA','AMD','NKE','MRNS','IMMU','PFE','ALB',

'UBER','LYFT','L','K','KO','MCD','YUM','GS','BAC','C','WFC','JPM','AXP','V','T','HAL','PBR','XOM','U','SNAP',

// add more here...
  );
 
$stocksList_watchlistLen  = count( $stocksList_watchlist);






$totalSumMoneyBoughtAndSold=0 ;  
$totalSumMoney =0;
$commaInclude=0;
       $msgs = 0;


//    adapted to receive various WATCHLISTS and create an array in javascript for inclusion 
//    if(isset( $_GET['fn'] )){
//        $fname = $_GET['fn']. ".csv" ;
//    }else{
//        $fname = "dnalib.csv";
//    }
//

   if(isset( $_GET['msgs'] )){
       $msgs = $_GET['msgs'] ;
   }else{
       $msgs = 0;
   }

   if(isset( $_GET['comma'] )){
       $commaInclude = $_GET['comma'] ;
   }else{
       $commaInclude = 0;
   } 
 
    

    if( $defaultLen < 1 ||  $defaultLen > 512  )    $defaultLen = 32;

    $alphaSet = "abcdefghijklmnopqrstuvwxyz0123456789*$@#!_-+";
    $aSetCnt  = strlen( $alphaSet );
    
    $strBR= "\n";

    
    // MYSQL CONNECT FUTURE USE
    // 
    // $con = mysqli_connect("localhost", "jb_jackabeejohn", "jackabee66", "jb_SuperTrader");
    // if (!$con) die('Could not connect: '. mysqli_error($con));
    // mysqli_select_db($con, "jb_SuperTrader") or die ("] MySQL: SuperTrader Database connect failed - exiting... " . mysqli_error($con));
    // $data = array();
    
    // echo "] GOT PAST data[] array and MySQL initial connection...<br />";
    
    // $queryStr = "SELECT * FROM tickers ";
    // $result   = mysqli_query($con, $queryStr);
    // $j=0;
    // while($row = mysqli_fetch_assoc( $result )){
    //     $data[] = $row;
    //     $j++; 
    //     echo $j. "]". "  ". $row['id']. "  ". $row['ticker']. "  ". $row['date']. "<br />";
    //     $jsonStr  =  json_encode( $row ) ;

    //     echo $jsonStr. "<br />". "<br />";

    // }
    // $i=0;
    //  // echo json-formatted data back to javascript
    // $newdata =  json_encode($data);
  
    // echo "]  GOT PAST LOOP    AND    json_encode( data )  <br />";

    // echo "newdata =". $newdata . "<br />". "<br />";
   	// echo "newdata[1] =". $newdata[1] . "<br />". "<br />";
    
    
    /*



//   1. take UAO.txt in for processing - this creates      watchlist0.js   [uoa]
//
//   2.  take watchlist.txt in  - this creates      watchlist.js   [ our standard watchlist ]
//        2a. NOTE: This can stay static for a while: FB, AAPL, AMZN , NFLX, NVDA, GOOGL, QQQ, VXX, GS, NIO, etc
//
//   3.  ideally we can merge, various watchlists   [ uoa, ourWatchlist, dynamicDailyWatchlist ]
//
//   4.  take watchlistdynamic.txt in  - this creates watchlistdynamic.js   [ daily * dynamic * watchlist ]
//
//   5. overlaps on watchlists are welcome and tolerated; they will be uniquely filtered upon ingestion to iTraderPro client

    */
    

    
    // open file 
    $currentStock="12349172340981723";    // no ticker would be this so it is  != on first go in loop
    $listofstocks="var stocksForWatchlist = [ ";
    $listofstocks10="";
    
    $numOfStocks=0;
    $file = fopen("uoa.txt", "r");
    $i = 0;
    
    $numOfBullishPositions=0;
    $numOfBearishPositions=0;
         $checknextline= 0;


// FILE OPEN TO WRITE !!! [ here we can write stock/option data into dbase.logv]
    $masterFileName = "watchlistdyamic.txt";
    $handle = fopen($masterFileName, "w");
    

//  OUTPUT LINE TO FILE
    $line1 = "// watchlist0.txt ". $strBR. "// 4th-Generation Code by readuoa.php ; Creator = J. Botti.". $strBR.  $strBR. $strBR ;
         $line1.= $strBR. "//  VERSION NO.: ". $versionNo.". This data converted on " . date("Y-m-d"). " at " . date("h:i:sa"). ".".  $strBR.  $strBR ;
    //echo $line1;
   // fwrite( $handle, $line1);
    
    




        $checknextline = 0 ;

// loop thru body of incoming text
    while (!feof($file)) {
        

        $line_of_text = fgets($file);
       // $members = explode('\n', $line_of_text);
      if($msgs==1)      echo $i. " == ". $line_of_text. "<br />"  ;
        


/*
$totalNumStocks

HEADING:
[ symbol ] [ Bullish/Bearish ]  [ Position Type ]
NKE Bullish Call Roll

2nd LINE:
Nov 10, 2020 01:00 pm – Posted by: Chris Sykora
[ DATE ] [ TIME EST ] - Posted by: [ MR Trader / Instructor ]


[ # contracts] [ Expiration date] [ strike] [ call/ put ] [bought/sold] for [ price min[..max]] [above/below] open interest of [oi]

[rolled position mimic above # contracts here {optional}]
2,200 January *2022* 125 calls bought for 18.10 to 19.40 above open interest of 885 contracts; 2,400 January *2021* 95 calls sold for 34.20 to 31.95 below open interest of 6,703 contracts. 

Stock [price/range]
Stock 126.64-128.96.




USFD Bearish Put Buying
Nov 11, 2020 02:41 pm – Posted by: Mike Yamamoto
3,600 November 30 puts mostly bought for 1.05 to 1.85 above open interest of 430 contracts. Stock 28.69. EPS *estimated* 2/9 before open.

SIRI Bullish Call Buying
Nov 11, 2020 02:34 pm – Posted by: Mike Yamamoto
4,800 June 7 calls bought for 0.25 to 0.30 above open interest of 200 contracts. Stock 6.21.

GME Bearish Put buying
Nov 11, 2020 02:28 pm – Posted by: Chris Sykora
4,000 December 14 puts bought for 3.95 to 4.01 above open interest of 740 contracts. Stock 11.59-11.66.

AMD Bullish Call Buying
Nov 11, 2020 02:23 pm – Posted by: Chris Sykora
4,500 04December 88 calls bought mostly in one print of 3,689 for 1.17 to 1.27 above open interest of 213 contracts. Stock 80.48-80.79.

MPLN Bearish Put Buying
Nov 11, 2020 02:14 pm – Posted by: Mike Yamamoto
3,300 November 10 puts bought for 1.35 to 2.40 above open interest of 1,749 contracts. Stock 7.66.



155 ==
156 == KO Bullish Call Roll
[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,]
157 == Nov 11, 2020 10:04 am – Posted by: Chris Sykora

[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,]

157-a == Nov 11 2020 10:04 am – Posted by: Chris Sykora

158 == 9,100 February 55 calls bought for 1.52-1.57 mostly in one 8,550 print above open interest of 4,035 contracts; 9,100 November 52.50 calls sold mostly in one print of 8,550 for 1.38 to 1.33 below open interest of 22,568 contracts. Follows...

[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,]

158-b == [9100]9100 February 55 calls bought for 1.52 to 1.57 mostly in one 8550 print above open interest of 4035 contracts; 9100 November 52.50 calls sold mostly in one print of 8550 for 1.38 to 1.33 below open interest of 22568 contracts. Follows...
[ boughtSold= 1 callPut= 1 FOR 1.52 .. 1.57 avg= 1.545 ] ___ [ *TradeMoney $1,405,950 = 9100 * 1.545 * 100 ]
[ boughtSold= -1 callPut= 1 FOR 1.38 .. 1.33 avg= 1.355 ] ___ [ *TradeMoney $1,233,050 = 9100 * 1.355 * 100 ]


159 ==
160 == MU Bullish Call Buying
[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,mu,]
161 == Nov 11, 2020 09:52 am – Posted by: Chris Sykora
[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,mu,]
161-a == Nov 11 2020 09:52 am – Posted by: Chris Sykora
162 == 4,500 December 62.50 calls bought for 0.90 to 0.98 above open interest of 444 contracts. Stock 56.71-56.77.
[cstm,cog,czr,dvy,dks,flex,viac,hst,ms,usfd,siri,gme,amd,mpln,syy,fcx,uber,dbx,mgm,kr,c,spy,nee,dvn,bby,gm,nlok,jets,ddog,twtr,cnx,csco,aes,cf,momo,nvta,spce,plug,ko,mu,]
162-b == [4500]4500 December 62.50 calls bought for 0.90 to 0.98 above open interest of 444 contracts. Stock 56.71 to 56.77.
[ boughtSold= 1 callPut= 1 FOR 0.90 .. 0.98 avg= 0.94 ] ___ [ *TradeMoney $423,000 = 4500 * 0.94 * 100 ]
[ stockPrice = $56.71 ]




*/

      if( $line_of_text!="" ){

        $field = explode(' ', $line_of_text);
        $fcnt  = count( $field );



//  i.e. first valid line in Trade Desc Group
// [ symbol ] [ Bullish/Bearish ]  [ Position Type ]
//  NKE Bullish Call Roll
if($fcnt>2){

        $huntedSymbol     = strtolower ($field[0]);
        $huntedStr        = strtolower ($field[1]);
        $huntedPos        = strtolower ($field[2]);
        
        if (isset($field[3] ))   $huntedCallPut    = strtolower ($field[3]);
        if (isset($field[4] ))  $huntedTradeType  = strtolower ($field[4]);
 



  if($commaInclude==0){
    $delim = "<br />";

  }else if($commaInclude==1){
    $delim = ",<br />";

  }else if($commaInclude==2){
    $delim = "\n";

  }else if($commaInclude==3){
    $delim = ",\n";

  } 

        if( $huntedStr =="bullish"){
              $numOfStocks++;
              $numOfBullishPositions++;

              if($numOfStocks==1) $stocks.= $START_SYMBOLS_DYNAMIC_0 ;// .  "|0|". $delim ;
                else $stocks.= "=$".$huntedSymbol. "$"; //. "|0|". $delim ;


        }else if( $huntedStr =="bearish"){
              $numOfStocks++;
              $numOfBearishPositions++;

              if($numOfStocks==1) $stocks.= $START_SYMBOLS_DYNAMIC_0  ;// .   "|0|". $delim ;
                else $stocks.= "=$".$huntedSymbol. "$"; //. "|0|". $delim ;

 
        }

       // echo "[". $stocks . "]<br />";


/*
 
 https://itraderpro.co/uoa/readuoa.php?msgs=0&comma=0

*/


// default
$line_of_text3="|0|". $delim ;


// this line is the trade, starting w/ # of contracts
if($checknextline==$i){
 $line_of_text2 = str_replace($vowels, "",  $line_of_text );
 $line_of_text1 = str_replace($vowels1, " to ",  $line_of_text2 );

 $line_of_text3 = "|". $line_of_text1. "|". $delim ;   // "|"

        $field1 = explode(' ', $line_of_text1 );
        $fcnt1  = count( $field1 );
        $huntedTradeSize     = $field1[0] ;
    

        if($msgs==1)          echo $i. "-b == [". $huntedTradeSize. "]".  $line_of_text1. "<br />"  ;


          $e=0; $boughtSold=0; $callPut=0; $rangelow=0; $rangehi=0;
          $expir="2031-03-17"; $strikePrice=0; $stockPrice=0; $stockAtLow=0; $stockAtHigh=0;

          for($e=1;$e<$fcnt1;$e++){
// 4000 November 68.50 puts bought for 1.30 to 1.50 above open interest of 2 contracts. Stock 69.01-69.29.

               $huntedTok     = strtolower ( $field1[$e+0] );
               
                if (isset($field1[$e+1] ))  $huntedTok1    = strtolower ( $field1[$e+1] );
                  else $huntedTok1="00";
                if (isset($field1[$e+2] ))  $huntedTok2    = strtolower ( $field1[$e+2] );
                  else $huntedTok2="00";
              if (isset($field1[$e+3] ))  $huntedTok3    = strtolower ( $field1[$e+3] );
                  else $huntedTok3="00";

      
/*

 https://itraderpro.co/uoa/readuoa.php?msgs=1        

*/
              switch ($huntedTok) {
                case 'bought':
                  $boughtSold=1;
                  break;
                case 'sold':
                  $boughtSold=-1;
                  break;
                case 'for':
                  $rangelow  = $huntedTok1 ; //$field1[$e+1];
                  $rangehi   = $rangelow ; //$field1[$e+1];

                  if($huntedTok2=="to")  $rangehi   =$huntedTok3; // $field1[$e+3];

// ** BUG NOT WELL FORMED
                  $avgPrice = ($rangelow+$rangehi)/2;

            // if($msgs==1)           echo "[ boughtSold= $boughtSold  callPut= $callPut  FOR $rangelow .. $rangehi avg= $avgPrice ] ___ ";

                  $TradeMoney  =  $huntedTradeSize * $avgPrice * 100;
                  $totalSumMoneyBoughtAndSold += $TradeMoney; 

                  $TradeMoney1 = $boughtSold * $TradeMoney;   // 1 buy -1 sold * $huntedTradeSize * $avgPrice * 100;
                 $totalSumMoney += $TradeMoney1; 

                  $TradeMoney11 = number_format($TradeMoney1);

  if($msgs==1)          echo "[ *TradeMoney $". $TradeMoney11. " =  $huntedTradeSize * $avgPrice * 100 ]  <br />" ;

                  break;
                case 'puts':
                  $callPut=-1;
                  break;
                case 'calls':
                  $callPut=1;
                  break;
                 case 'stock':
                  $stockPrice = $huntedTok1;
  if($msgs==1)           echo "[ stockPrice = $". $stockPrice . " ]<br /><br />" ; 
                  break;
                
                 
              }//sw

          }//for

  if($numOfStocks!=1) $stocks.="|".$TradeMoney1  .   $line_of_text3;
    else $stocks.="|0|".$delim;

          $checknextline = 0 ;

}//if 

// append |0| or |<specialty data strings| . $delim after  =$fb for example

 
/*

 https://itraderpro.co/uoa/readuoa.php?msgs=0

 https://itraderpro.co/uoa/readuoa.php?msgs=1        

*/
// test for 2nd line

                switch ($huntedSymbol) {
                  case 'jan':
                  case 'feb':
                  case 'mar':
                  case 'apr':
                  case 'may':
                  case 'jun':

                  case 'jul':
                  case 'aug':
                  case 'sep':
                  case 'oct':
                  case 'nov':
                  case 'dec':
 
                    $d=0;
                    $line_of_text1="";
               
                      // Provides: Hll Wrld f PHP
// $vowels = array("a", "e", "i", "o", "u", "A", "E", "I", "O", "U");
         $line_of_text1 = str_replace($vowels, "",  $line_of_text );
 
  if($msgs==1)      echo $i. "-a == ". $line_of_text1. "<br />"  ;

         $jbdate = $huntedSymbol." ". $huntedStr ." ". $huntedPos;

         $date_unix = date( "Y-m-d", strtotime( $jbdate ) );
         $date_options = date( "ymd", strtotime( $jbdate ) );

  if($msgs==1)         echo "{". $date_unix . "}"; 
  if($msgs==1)         echo "{=". $date_options . "=}"; 
        
           $checknextline = $i+1;
                    


                     break;
                  


                  default:
                    ;
                    break;

                }//sw
 

          }// if fcnt

 
       }//if new $line_of_text!=""
 

   // still in while loop
    $i++;

  }//while

//
// ********************************************** END OF WHILE LOOP




if($msgs==1)     echo " totalSumMoneyBoughtAndSold = ". number_format($totalSumMoneyBoughtAndSold). " ;  totalSumMoney = ". number_format($totalSumMoney). "  <br />";
    // CLOSE INPUT TEXT FILE - DONE READING IT !
  fclose($file);
    
 $totalNumStocks= $i ; //stocks;


    $endofstream = $strBR. " ".  $strBR.  $strBR;
    


    $numLinesRead = $i;
    $listofstocks1 = substr( $listofstocks, 0, -1);
    $listofstocks1 .= "];".  $strBR.  $strBR ;
    
    $endofstream .= "//". $listofstocks1. "// var watchliststocksMax = ". $numOfStocks . "; ".$strBR.  $strBR. " // num stocks read = ". $numOfStocks .", num Lines Read = ". $numLinesRead;
    
    $endofstream .=   $strBR. "//  VERSION NO.: ". $versionNo.". This data converted on " . date("Y-m-d"). " at " . date("h:i:sa"). ".".  $strBR ;
    
    

  //  echo $endofstream;
   // fwrite($handle, $endofstream);

//OUTPUT FOR aync call from candlestix.js

    // DYANMIC0
    echo   $stocks;
    fwrite($handle, $stocks );
    


      $stocksList_watchlistDynamic = "";
      $stocksList_watchlistDynamic .=  $START_SYMBOLS_STANDARD. $delim ;

      for($w=0;$w<$stocksList_watchlistLen; $w++){

           $stocksList_watchlistDynamic .= "=$".strtolower( $stocksList_watchlist[ $w ] ). "$|0|".  $delim ; 

      }//for

      
     $stocksList_watchlistDynamic .= "=[end_symbols#". ( $stocksList_watchlistLen -2 + $totalNumStocks ) . "#]".  $delim ;
    
     $stocksList_watchlistDynamic .= "=[uoa_date#". $date_unix."#]". $delim;

$t=time();
     $stocksList_watchlistDynamic .= "=[todays_date#". date("Y-m-d",$t) ."#]". $delim;
 
 
     echo   $stocksList_watchlistDynamic;  
     fwrite($handle, $stocksList_watchlistDynamic );
    

/*

 https://itraderpro.co/uoa/readuoa.php?msgs=1        



Notice: A non well formed numeric value encountered in /home1/itraderp/public_html/uoa/readuoa.php on line 383

Notice: A non well formed numeric value encountered in /home1/itraderp/public_html/uoa/readuoa.php on line 383
=[start_symbols_dynamic]|13500 31December 335 puts bought for 6.53 above open interest of 5693 contracts; 13500 31December 320 puts sold for 4.05 below open interest of 19105 contracts. Vertical put spread bought or long put roll to up bearish either way. Stock 352.01. |
=$fe|10668 April 30 calls bought for 2.10 to 2.15 above open interest of 503 contracts; 2436 April 35 calls sold for 0.55 above open interest of 460 contracts; 10668 April 28 puts sold for 2.05 above open interest of 308 contracts. Ratio... |
=$ibkr|4500 March 65 calls bought for 0.35 to 0.60 above open interest of 206 contracts. Stock 51.38. EPS *estimated* 1/19 after close. |
=$ebay|2000 February 50 calls bought for 2.19 to 2.21 above open interest of 1031 contracts; 3000 February 60 calls sold for 0.51 below open interest of 15831 contracts. Ratio call spread bought or long call roll to down bullish either way. Stock... |
=$cpri|3000 December 27.50 puts bought for 1.80 to 2.10 above open interest of 67 contracts. Stock 27.75 to 28.04. |
=$schw|5250 March 60 calls bought for 0.37 to 0.40 above open interest of 4 contracts. Stock 44.42 to 44.43. |
=$ashr|3250 04December 36.50 puts bought for 0.44 to 0.47 against no open interest. Unrelated to the April 44 calls on Log earlier. Stock 37.70. |
=$vg|2250 December 14 calls bought for 0.25 to 0.35 above open interest of 81 contracts. Stock 12.47 to 12.52. |
=$usfd|5000 January *2022* 30 calls bought for 4.00 to 4.60 above open interest of 198 contracts; 5000 January *2022* 45 calls sold for 2.15 to 0.50 above open interest of 1 contract; 5000 January *2022* 20 puts sold for 2.75... |
=$ccep|3000 November 40 calls bought for 0.95 to 1.15 above open interest of 456 contracts. Stock 40.57. First time on Log. |
=$bbby|5800 January 20 puts bought for 2.72 to 2.84 above open interest of 3133 contracts. Stock 19.69 to 19.82. |
=$ftch|3800 November 55 calls bought in mostly two 1000 lot prints for 1.03 to 1.15 above open interest of 83 contracts. Stock 44.42 to 45.40 to EPS *today* 11/12 after close. |
=$viac|9900 March 29 puts bought for 3.05 to 3.15 above open interest of 5729 contracts. Adds to trade on Log yesterday. Stock 30.20. |
=$gpn|3189 February 190 calls bought for 10.60 above open interest of 94 contracts 3189 February 220 calls sold for 2.20 above open interest of 22 contracts 3189 February 155 puts sold for 3.40 above open interest of 309. Stock 184.74.... |
=$pk|10000 September 15 calls bought for 2.80 above open interest of 43 contracts; 10000 September 25 calls sold for 0.80 above open interest of 3 contracts. Stock 13.15. EPS *estimated* 02/24. |
=$qqq|9550 31December 270 puts bought for 5.32 above open interest of 3293 contracts; 8400 31December 255 puts sold for 2.89 above open interest of 7851 contracts. Ratio spread. Rolled to out from an 11500/9889 contract put ratio spread in 27November 273/260 strikes.... |
=$aeo|3600 December 14 puts bought for 0.65 to 0.69 above open interest of 81 contracts 3600 December 12 puts sold for 0.18 to 0.25 above open interest of 529 contracts 3600 December 17 calls sold for 0.40 to 0.50 above... |
=$plug|17700 November 25 calls mostly bought for 0.65 to 1.09 above open interest of 5171 contracts. Stock 23.92. Follows 13November 22 call buying in previous session. |
=$prsp|5000 January 22.50 calls bought for 1.25 against no open interest; 5000 December 22.50 calls sold for 0.70 below open interest of 5718 contracts. First time on Log since 2018. Stock 21.86. |
=$xbi|5000 January 115 puts bought for 3.05 above open interest of 531 contracts; 5000 January 100 puts sold for 0.52 below open interest of 6274 contracts. Vertical put spread bought or long put roll to up bearish either way. Follows December 120... |
=$aes|10000 December 22 calls bought for 0.55 above open interest of 1421 contracts; 10000 November 20 calls sold for 0.95 below open interest of 14101 contracts. Rolls trade on Log 10/08 as the second of a series. Stock 20.76. ***Update... |
=$momo|2100 27November 16.50 calls mostly bought for 0.45 to 0.58 above open interest of 718 contracts. Stock 15.99. Third bullish entry on Log in two sessions. |
=$nio|4500 January 55 calls bought in one print for 5.90 above open interest of 3738 contracts. Stock 46.60. |
=$jd|5600 January 87.50 calls mostly bought for 6.68 to 8.70 above open interest of 590 contracts. Stock 86.67 to 88.15. EPS 11/16 before open. Follows December 82.50 call buying on Log in previous session. |
=$spwr|4500 November 20 calls bought for 0.63 to 0.81 above open interest of 3168 contracts. Stock 18.87 to 19.17. |
=$vips|2500 November 22.50 calls bought for 1.40 to 1.42 above open interest of 724 contracts 2500 November 26 calls sold for 0.32 to 0.35 below open interest of 3079. Stock 22.41. EPS *tomorrow* (11/13) before open. Roll to down or vertical spread. |
=$lqd|23750 January 126 puts bought mostly in two prints for 0.39 to 0.43 above open interest of 14770 contracts. Stock 135.16 to 135.23. |
=$xpev|5500 November 45 calls mostly bought in smaller prints for 0.75 to 2.45 above open interest of 2572 contracts. Stock 36.04 to 41.00. |
=$fcx|16000 February 22 calls bought for 1.28 to 1.32 above open interest of 1301 contracts 16000 January 17 calls sold for 3.54 to 3.60 below open interest of 30325. Stock 20.09. EPS *estimated* 1/21 before open. Appears to continue roll... |
=$xbi|4200 December 120 puts bought for 3.05 above open interest of 2343 contracts; 2100 December 105 puts sold for 0.50 below open interest of 4985 contracts; 2100 December 135 calls sold for 1.30 below open interest of 6999 contracts. Ratio... |
=$ashr|2700 April 44 calls bought for 0.52 against no open interest. Stock 37.91 to 37.92. |
=$rkt|6000 November 23.50 calls mostly bought for 0.26 to 0.35 above open interest of 1776 contracts. Stock 21.55. Follows December 17 call buying on Log 11/6. |
=$cgc|4400 December 27.50 calls bought for 1.14 to 1.22 above open interest of 1158 contracts 4400 December 32.50 calls sold for 0.39 to 0.47 above open interest of 318. Stock 24.34. |
=$chrw|2000 December 92.50 puts bought for 3.19 to 3.20 above open interest of 91 contracts; 2000 December 87.50 puts sold for 1.27 to 1.26 above open interest of 17 contracts; 2000 December 97.50 calls sold for 0.92 to 0.91 above open interest of 284 contracts. Vertical... |
=$pton|4400 13November 110 calls mostly bought for 1.93 to 3.60 above open interest of 3197 contracts. Stock 111.35. |
=$hog|5400 13November 33.50 puts bought for 0.40 to 0.65 above open interest of 167 contracts. Stock 33.42 to 33.62. |
=$gluu|2500 December 9 calls bought mostly for 0.30 above open interest of 1657 contracts. Stock 8.48. |
=$roku|2700 13November 235 calls mostly bought for 2.30 to 4.00 above open interest of 1374 contracts. Stock 233.03. |
=$pdd|3000 04December 160 calls bought for 1.57 to 1.84 in three prints against no open interest; 3000 November 125 calls sold in three prints for 11.46 to 9.74 below open interest of 4653 contracts. Stock 131.08 to 132.54. |
=$ibm|5200 December 130 calls bought for 0.28 to 0.30 above open interest of 4935 contracts 5200 December 135 calls sold for 0.09 to 0.12 above open interest of 2639. Stock 115.58. |
=$aal|29500 November 11 puts sold mostly in one 26896 print for 0.19 to 0.15 above open interest of 19975 contracts. Stock 11.81 to 11.90. |
=$snap|2500 November 40.50 calls mostly bought for 1.07 to 1.36 above open interest of 1378 contracts. Stock 39.90. |
=$ps|4000 December 17.50 calls mostly bought for 0.35 to 0.75 above open interest of 3253 contracts. Stock 15.38. |
=$solo|4300 December 4 calls bought for 0.50 to 0.70 above open interest of 3363 contracts. Stock 3.94. Follows November 3 call buying on Log 10/14. |
=$pltr|2100 January 30 calls bought for 0.55 to 0.60 above open interest of 324 contracts. Third bullish trade on Log in the past week. Stock 16.59 to 16.84. EPS 11/12 after close. |
|Pre to market Movers 11/12/2020 HIGHER – Acco Brands ($ACCO) up 7% after KeyBanc analyst Bradley Thomas upgraded shares to Overweight from Sector Weight with a $12 price target UP AFTER EARNINGS – Pinduoduo ($PDD) up 23% Xpeng ($XPEV) up 6% Axcella... |
|These pivot points are calculated using the DeMark method. It is generally believed to be bullish when price breaks out above the pivot high or bearish when price breaks down below the pivot low. SPX: Pivot High: 3588.99 –... |
=$cstm|2500 May 13 calls bought for 1.51 to 1.70 2500 May 20 calls sold for 0.20 to 0.30 volume against no open interest in both strikes. Stock 11.24. EPS *estimated* 2/18 before open. Vertical spread appears partly rolled from January... |
=$cog|3000 24December 19 calls bought in one print for 0.35 against no open interest. Stock 17.19. EPS *estimated* 2/18 after close. |
=$czr|5000 March 50 calls bought itm for 13.80 to 14.20 above open interest of 879 contracts. Stock 58.28. |
=[start_symbols_standard]
=$spy|0|
=$dia|0|
=$qqq|0|
=$vxx|0|
=$gld|0|
=$slv|0|
=$uso|0|
=$tbt|0|
=$tlt|0|
=$gbtc|0|
=$aapl|0|
=$amzn|0|
=$bynd|0|
=$f|0|
=$x|0|
=$roku|0|
=$fb|0|
=$ba|0|
=$m|0|
=$msft|0|
=$tsla|0|
=$pton|0|
=$shop|0|
=$nvax|0|
=$nflx|0|
=$srne|0|
=$aal|0|
=$nkla|0|
=$sbux|0|
=$lulu|0|
=$rcl|0|
=$spce|0|
=$mrna|0|
=$spot|0|
=$adt|0|
=$nvda|0|
=$amd|0|
=$nke|0|
=$mrns|0|
=$immu|0|
=$pfe|0|
=$alb|0|
=$uber|0|
=$lyft|0|
=$l|0|
=$k|0|
=$ko|0|
=$mcd|0|
=$yum|0|
=$gs|0|
=$bac|0|
=$c|0|
=$wfc|0|
=$jpm|0|
=$axp|0|
=$v|0|
=$t|0|
=$hal|0|
=$pbr|0|
=$xom|0|
=$u|0|
=$snap|0|
=[end_symbols#266]
*/
     

// CLOSE MYSQL

    // mysqli_close( $con );
    // unset( $con );


   fclose($handle);


?>
