<?php
// Keep your Stripe API key protected by including it as an environment variable
// or in a private script that does not publicly expose the source code.

// This is your test secret API key.
$stripeSecretKey = 'sk_test_51NRqA2EJfZ5xbPiBTrS8vIap45s8j8R8I2AcUkdl3CnoboX94rylI3zIWkUwEITEI0Rwf7tdubrGR7KiNFuWL2fH00M51C8NIp';