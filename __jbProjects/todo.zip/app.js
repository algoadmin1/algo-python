const scoreDisplay = document.getElementById('score-display')
const questionDisplay = document.getElementById('question-display')

const questions = [
  {
    correct: 2,
    option: ['sun', 'mon'],
    quiz: ['A.[_]reDrawCurrentChart AFTER All initial data is displayed ', ' ', ' '],
  },
  {
    correct: 2,
    option: ['mon', 'tue'],
    quiz: ['B.[_] REAL-TIME quote - last price stocks/crypto', ' ', ' '],
  },
  {
    correct: 2,
    option: ['mon', 'tue'],
    quiz: ['0. [_] BAD INPUT  = NO STOCK, redraw last Stock', ' ', ' '],
  },
  {
    correct: 2,
    option: ['tue', 'wed'],
    quiz: ['1.  [_]Switches: disable other switches if( gDrawSw==0 )', ' ', ' '],
  },
  {
    correct: 2,
    option: ['wed', 'thu'],
    quiz: ['2.  [_]Switches  Buy/Sell: draw minor IFF prev. non-MINOR xOver', ' ', ' '],
  },
  {
    correct: 1,
    option: ['thu', 'fri'],
    quiz: ['3. [_]Switches SupRes: Monthly #’s inaccurate BUG', ' ', ' '],
  },
  {
    correct: 2,
    option: ['fri', 'sat'],
    quiz: ['4.  [_]Switches:  LongTerm: Show SupRes for Mo / Wk, data BUG', 'doodler', ' '],
  },{
    correct: 2,
    option: ['fri', 'sat'],
    quiz: ['aniaTutorial', 'doodler', ' '],
  },{
    correct: 2,
    option: ['sat', 'sun'],
    quiz: ['5.  [_]Switches MovAvg - improve 200day', 'NFT', 'dalE-2ai'],
  },{
    correct: 2,
    option: ['sun', 'mon'],
    quiz: ['5a  [_] VWAP - draw VWAP', ' ', ' '],
  },{
    correct: 2,
    option: ['sun', 'mon'],
    quiz: ['5b  [_] RSI - draw RSI', ' ', ' '],
  },{
    correct: 2,
    option: ['mon', 'tue'],
    quiz: ['6.  [_]Switches  Run PnL #s need to be accurate', ' ', ' '],
  },{
    correct: 2,
    option: ['mon', 'tue'],
    quiz: ['7. [_]Switches  Gaps Dojis - Gap prices are slightly off', ' ', ' '],
  },{
    correct: 2,
    option: ['wed', 'wed'],
    quiz: ['8.  [_]Switches  Earnings Bug - it writes over itself', ' ', ' '],
  },{
    correct: 2,
    option: ['wed', 'wed'],
    quiz: ['8a.  [_]GRAHAMS FORMULA', ' ', ' '],
  },{
    correct: 2,
    option: ['thu', 'thu'],
    quiz: ['9.  [_]keyStr InputBox:  Write to the Dom’s <div> ala ptLarry', ' ', ' '],
  },{
    correct: 2,
    option: ['fri', 'fri'],
    quiz: ['11.  [_]Switches  Crypto:any Debuging', ' ', ' '],
  },{
    correct: 2,
    option: ['sat', 'sat'],
    quiz: ['12.  [_]Switches  Watchlist - entry of watchlist {how/input?}', ' ', ' '],
  },{
    correct: 2,
    option: ['sun', 'sun'],
    quiz: ['13.  [_]Switches  Run Algo Investor - format email better ; write JSON', ' ', ' '],
  },{
    correct: 2,
    option: ['sun', 'mon'],
    quiz: ['13a.  [_] 10yr Treasury Graph ', ' ', ' '],
  },{
    correct: 2,
    option: ['mon', 'mon'],
    quiz: ['13b.  [_] Fed FundsRate', ' ', ' '],
  },{
    correct: 2,
    option: ['mon', 'tue'],
    quiz: ['14.  [_]LocalStorage—>Server Storage: Switches ', ' ', ' '],
  },{
    correct: 2,
    option: ['tue', 'tue'],
    quiz: ['15.  [_] —>  upgrade CSS a bit entry box, button, DOM mods', ' ', ' '],
  },{
    correct: 2,
    option: ['wed', 'wed'],
    quiz: ['16.  [_]Switches  Extras [ off in commercial version ]', ' ', ' '],
  },{
    correct: 2,
    option: ['thu', 'thu'],
    quiz: ['17. [_]—> 2 tiers of service: basic and algoRun', ' ', ' '],
  },{
    correct: 2,
    option: ['fri', 'fri'],
    quiz: ['Z.  [_]GET PRIVATE KEY for user, database POST', ' ', ' '],
  },{
    correct: 2,
    option: ['sat', 'sat'],
    quiz: ['QA TESTING', ' ', ' '],
  },{
    correct: 2,
    option: ['sun', 'mon'],
    quiz: ['MARKETING Plan AUG/SEP 2022', ' ', ' '],
  }, 
]

let clicked = []
let score = 0

scoreDisplay.textContent = score


function populateQuestions() {
  questions.forEach((question) => {
    const questionBox = document.createElement('div')
    questionBox.classList.add('question-box')

    const logoDisplay = document.createElement('h1')
    logoDisplay.textContent = '✒'
    questionBox.append(logoDisplay)

    question.quiz.forEach((tip) => {
      const tipText = document.createElement('p')
      tipText.textContent = tip
      questionBox.append(tipText)
    })

    const questionButtons = document.createElement('div')
    questionButtons.classList.add('question-buttons')
    questionBox.append(questionButtons)

    question.option.forEach((option, optionIndex) => {
      const questionButton = document.createElement('button')
      questionButton.classList.add('question-button')
      questionButton.textContent = option
      questionButton.addEventListener('click', () =>
        checkAnswer(
          questionBox,
          questionButton,
          option,
          optionIndex + 1,
          question.correct
        )
      )
      questionButtons.append(questionButton)
    })
    const answerDisplay = document.createElement('div')
    answerDisplay.classList.add('answer-display')

    questionBox.append(answerDisplay)
    questionDisplay.append(questionBox)
  })
}

populateQuestions()

function checkAnswer(
  questionBox,
  questionButton,
  option,
  optionIndex,
  correctAnswer
) {
  if (optionIndex === correctAnswer) {
    score++
    scoreDisplay.textContent = score
    addResult(questionBox, 'Good Job!', 'correct')
  } else {
    score--
    scoreDisplay.textContent = score
    addResult(questionBox, 'Keep Going!', 'wrong')
  }
  clicked.push(option)
  questionButton.disabled = clicked.includes(option)
}

function addResult(questionBox, answer, className) {
  const answerDisplay = questionBox.querySelector('.answer-display')
  answerDisplay.classList.remove('wrong')
  answerDisplay.classList.remove('correct')
  answerDisplay.classList.add(className)
  answerDisplay.textContent = answer
}
