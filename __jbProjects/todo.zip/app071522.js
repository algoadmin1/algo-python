const scoreDisplay = document.getElementById('score-display')
const questionDisplay = document.getElementById('question-display')

const questions = [
  {
    correct: 2,
    option: ['sun', 'mon'],
    quiz: ['WeekChart', 'renderOO()', 'viewport'],
  },
  {
    correct: 2,
    option: ['mon', 'tue'],
    quiz: ['10yrChart', 'JSON', 'FedFunds'],
  },
  {
    correct: 2,
    option: ['mon', 'tue'],
    quiz: ['prep4MoData', 'json', 'render'],
  },
  {
    correct: 2,
    option: ['tue', 'wed'],
    quiz: ['4moData', 'render', 'next'],
  },
  {
    correct: 2,
    option: ['wed', 'thu'],
    quiz: ['WeekChart', 'renderOO()', 'candLines'],
  },
  {
    correct: 1,
    option: ['thu', 'fri'],
    quiz: ['endpoint', 'rsi', 'cryptoBug'],
  },
  {
    correct: 2,
    option: ['fri', 'sat'],
    quiz: ['aniaTutorial', 'doodler', 'finishPlan'],
  },{
    correct: 2,
    option: ['fri', 'sat'],
    quiz: ['aniaTutorial', 'event', 'WeekChart'],
  },{
    correct: 2,
    option: ['sat', 'sun'],
    quiz: ['buglist', 'rest', 'dalEai'],
  },{
    correct: 2,
    option: ['sun', 'mon'],
    quiz: ['weekly', 'renderOO()', 'debug'],
  },
]

let clicked = []
let score = 0

scoreDisplay.textContent = score


function populateQuestions() {
  questions.forEach((question) => {
    const questionBox = document.createElement('div')
    questionBox.classList.add('question-box')

    const logoDisplay = document.createElement('h1')
    logoDisplay.textContent = '✒'
    questionBox.append(logoDisplay)

    question.quiz.forEach((tip) => {
      const tipText = document.createElement('p')
      tipText.textContent = tip
      questionBox.append(tipText)
    })

    const questionButtons = document.createElement('div')
    questionButtons.classList.add('question-buttons')
    questionBox.append(questionButtons)

    question.option.forEach((option, optionIndex) => {
      const questionButton = document.createElement('button')
      questionButton.classList.add('question-button')
      questionButton.textContent = option
      questionButton.addEventListener('click', () =>
        checkAnswer(
          questionBox,
          questionButton,
          option,
          optionIndex + 1,
          question.correct
        )
      )
      questionButtons.append(questionButton)
    })
    const answerDisplay = document.createElement('div')
    answerDisplay.classList.add('answer-display')

    questionBox.append(answerDisplay)
    questionDisplay.append(questionBox)
  })
}

populateQuestions()

function checkAnswer(
  questionBox,
  questionButton,
  option,
  optionIndex,
  correctAnswer
) {
  if (optionIndex === correctAnswer) {
    score++
    scoreDisplay.textContent = score
    addResult(questionBox, 'Correct!', 'correct')
  } else {
    score--
    scoreDisplay.textContent = score
    addResult(questionBox, 'Wrong!', 'wrong')
  }
  clicked.push(option)
  questionButton.disabled = clicked.includes(option)
}

function addResult(questionBox, answer, className) {
  const answerDisplay = questionBox.querySelector('.answer-display')
  answerDisplay.classList.remove('wrong')
  answerDisplay.classList.remove('correct')
  answerDisplay.classList.add(className)
  answerDisplay.textContent = answer
}
